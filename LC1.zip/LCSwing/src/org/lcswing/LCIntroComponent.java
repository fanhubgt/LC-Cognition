package org.lcswing;

import com.sun.java.swing.plaf.motif.MotifLookAndFeel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.io.IOException;
import java.util.Random;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.MatteBorder;
import org.openide.util.Exceptions;
import org.openide.windows.TopComponent;

/**
 *
 * @author appiah
 */
public class LCIntroComponent extends TopComponent {

    private JTextPane tp;

    public LCIntroComponent() {
        try {
            setName("LC Intro");
            setDisplayName("LC Intro");
            setSize(new Dimension(350, 400));
            setLayout(new BorderLayout());
            setBackground(new Color(Color.HSBtoRGB(0.987654f, 0.592349910f, 1.0f)));
            setForeground(new Color(Color.HSBtoRGB(0.987654f, 0.592349910f, 1.0f)));
            setToolTipText("LC Introduction");
            setBorder(new MatteBorder(new Insets(5, 5, 5, 5), new Color(Color.HSBtoRGB(0.7f, 0.989f, 1.0f))));
            UIManager.setLookAndFeel(new MotifLookAndFeel());
            add(createOutput(), BorderLayout.CENTER);
        } catch (UnsupportedLookAndFeelException ex) {
            Exceptions.printStackTrace(ex);
        }
    }

    @Override
    public int getPersistenceType() {
        return PERSISTENCE_NEVER;
    }

    public JScrollPane createOutput() {
        tp = new JTextPane();
        tp.setBackground(new Color(Color.HSBtoRGB(0.6888888f, 0.77777666f, 0.833333f), true));
        tp.setForeground(new Color(Color.HSBtoRGB(0.6521222f, 0.1972f, 0.94567f)));
       // tp.setContentType("text/html");
       // tp.setEditorKit(new HTMLEditorKit());
        Random ra = new Random();
        switch (ra.nextInt(8)) {
            case 1:
                tp.setFont(new Font("Courier 10 Pitch", Font.PLAIN, 16));
                break;
            case 2:
                tp.setFont(new Font("Arial", Font.PLAIN, 23));
                break;
            case 3:
                tp.setFont(new Font("New Times Roman", Font.PLAIN, 21));
                break;
            case 4:
                tp.setFont(new Font("Serif", Font.PLAIN, 21));
                break;

            case 5:
                tp.setFont(new Font("Nimbus Serif", Font.PLAIN, 22));

                break;
            case 6:
                tp.setFont(new Font("Nimbus Mono", Font.BOLD, 18));
                break;
            case 7:
                tp.setFont(new Font("URW Bookman L", Font.PLAIN, 19));
                break;
            case 8:
                tp.setFont(new Font("URW Gothic L", Font.PLAIN, 22));
                break;
        }

        tp.setText("Letter Combinatorics:Intro");
        tp.setPreferredSize(new Dimension(500, 190));
        tp.setMinimumSize(new Dimension(500, 100));
        JScrollPane textpane = new JScrollPane(tp, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        return textpane;
    }

    public void readIntro() {
        try {
            tp.setPage(this.getClass().getResource("files/lcintro.txt"));
            
        } catch (IOException ex) {
            Exceptions.printStackTrace(ex);
        }
    }
    
}
