
package org.lcswing;

import org.openide.util.HelpCtx;
import org.openide.util.NbBundle;
import org.openide.util.actions.CallableSystemAction;

public final class DataAction extends CallableSystemAction {

    public void performAction() {
        DataTopComponent top = new DataTopComponent();
        top.open();
        top.requestActive();
    }

    public String getName() {
        return NbBundle.getMessage(DataAction.class, "CTL_DataAction");
    }

    @Override
    protected String iconResource() {
        return "org/lcswing/images/diadat.png";
    }

    public HelpCtx getHelpCtx() {
        return HelpCtx.DEFAULT_HELP;
    }

    @Override
    protected boolean asynchronous() {
        return false;
    }
}
