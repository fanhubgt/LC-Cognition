
package org.lcswing;

import org.openide.util.HelpCtx;
import org.openide.util.NbBundle;
import org.openide.util.actions.CallableSystemAction;

public final class LCIntroAction extends CallableSystemAction {

    public void performAction() {
    LCIntroComponent lcic=new LCIntroComponent();
    lcic.readIntro();
    lcic.open();
    lcic.requestActive();
    }

    public String getName() {
        return NbBundle.getMessage(LCIntroAction.class, "CTL_LCIntroAction");
    }

    @Override
    protected String iconResource() {
        return "org/lcswing/images/icon.png";
    }

    public HelpCtx getHelpCtx() {
        return HelpCtx.DEFAULT_HELP;
    }

    @Override
    protected boolean asynchronous() {
        return false;
    }
}
