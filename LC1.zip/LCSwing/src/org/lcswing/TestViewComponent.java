package org.lcswing;

import com.sun.java.swing.plaf.motif.MotifLookAndFeel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import org.openide.util.Exceptions;
import org.openide.util.NbBundle;
import org.openide.windows.TopComponent;

/**
 *
 * @author appiah
 */
public class TestViewComponent extends TopComponent implements ActionListener {

    private TestViewComponent view = null;

    public TestViewComponent(int view) {
        try {
            setLayout(new BorderLayout(10, 10));
            setName(NbBundle.getMessage(LCTopComponent.class, "CTL_TestViewAction"));
            setDisplayName(NbBundle.getMessage(LCTopComponent.class, "CTL_TestViewAction"));
            add(createPopmenu(), BorderLayout.WEST);

            JScrollPane imagepane = null;
            if (view == 1) {
                imagepane = new JScrollPane(createODImages(), JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            } else {
                imagepane = new JScrollPane(createSDImages(), JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            }
            add(imagepane, BorderLayout.CENTER);
            UIManager.setLookAndFeel(new MotifLookAndFeel());
        } catch (UnsupportedLookAndFeelException ex) {
            Exceptions.printStackTrace(ex);
        }
    }

    private JPopupMenu createPopmenu() {

        JPopupMenu menu = new JPopupMenu("Test View Menu");
        ImageIcon icn = new ImageIcon(this.getClass().getResource("images/diadat.png"));
        JMenuItem item = new JMenuItem(NbBundle.getMessage(LCTopComponent.class, "CTL_TestOrthoViewAction"), icn);
        item.setMnemonic(KeyEvent.VK_O);
        item.setActionCommand(NbBundle.getMessage(LCTopComponent.class, "CTL_TestOrthoViewAction"));
        item.addActionListener(this);
        item.setBackground(new Color(Color.HSBtoRGB(0.692002f, 0.998112f, 1.0f)));
        menu.add(item);
        item = new JMenuItem(NbBundle.getMessage(LCTopComponent.class, "CTL_TestSymmViewAction"), icn);
        item.setMnemonic(KeyEvent.VK_S);
        item.setActionCommand(NbBundle.getMessage(LCTopComponent.class, "CTL_TestSymmViewAction"));
        item.addActionListener(this);
        item.setBackground(new Color(Color.HSBtoRGB(0.392002f, 0.8112f, 1.0f)));
        menu.add(item);

        menu.setVisible(true);
        return menu;
    }

    public JPanel createSDImages() {
        JPanel pane = new JPanel(new GridLayout(1, 1, 15, 10));
        pane.setBackground(Color.getHSBColor(0.749929f, 0.4568f, 0.95555f));
        int w = 800, h = 600;

        JLabel labelcen = new JLabel("Symmetrical Diagram", SwingConstants.CENTER);
        ImageIcon icon = new ImageIcon(this.getClass().getResource("images/LCTestDia-symlay.jpg"));
        labelcen.setIcon(new ImageIcon(icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH)));
        pane.add(labelcen);

        return pane;
    }

    private JPanel createODImages() {
        JPanel pane = new JPanel(new GridLayout(2, 1, 15, 10));
        pane.setBackground(Color.getHSBColor(0.749929f, 0.4568f, 0.95555f));

        int w = 800, h = 600;
        JLabel labelcen = new JLabel("Orthogonal Diagram", SwingConstants.CENTER);
        ImageIcon icon = new ImageIcon(this.getClass().getResource("images/LCTestDia-ortholay.jpg"));
        labelcen.setIcon(new ImageIcon(icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH)));
        pane.add(labelcen);

        return pane;
    }

    @Override
    public int getPersistenceType() {
        return PERSISTENCE_NEVER;
    }

    public void actionPerformed(ActionEvent e) {
        String action = e.getActionCommand();
        if (action.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "CTL_TestSymmViewAction"))) {
            if (view != null) {
                view.close();
            }
            view = new TestViewComponent(0);
            view.setName(NbBundle.getMessage(LCTopComponent.class, "CTL_TestSymmViewAction"));
            view.setDisplayName(NbBundle.getMessage(LCTopComponent.class, "CTL_TestSymmViewAction"));
            view.open();
            view.requestActive();
        } else if (action.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "CTL_TestOrthoViewAction"))) {
            if (view != null) {
                view.close();
            }
            view = new TestViewComponent(1);
            view.setName(NbBundle.getMessage(LCTopComponent.class, "CTL_TestOrthoViewAction"));
            view.setDisplayName(NbBundle.getMessage(LCTopComponent.class, "CTL_TestOrthoViewAction"));
            view.open();
            view.requestActive();
        }
    }
}
