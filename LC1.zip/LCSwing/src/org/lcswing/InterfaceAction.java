
package org.lcswing;

import org.openide.util.HelpCtx;
import org.openide.util.NbBundle;
import org.openide.util.actions.CallableSystemAction;

public final class InterfaceAction extends CallableSystemAction {

    public void performAction() {
        InterfaceTopComponent top = new InterfaceTopComponent();
        top.open();
        top.requestActive();
    }

    public String getName() {
        return NbBundle.getMessage(InterfaceAction.class, "CTL_InterfaceAction");
    }

    @Override
    protected String iconResource() {
        return "org/lcswing/images/diainter.png";
    }

    public HelpCtx getHelpCtx() {
        return HelpCtx.DEFAULT_HELP;
    }

    @Override
    protected boolean asynchronous() {
        return false;
    }

}
