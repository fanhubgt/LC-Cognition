package org.lcswing;

import org.openide.util.HelpCtx;
import org.openide.util.NbBundle;
import org.openide.util.actions.CallableSystemAction;

public final class TestAction extends CallableSystemAction {

    public void performAction() {
        TestTopComponent top = new TestTopComponent();
        top.open();
        top.requestActive();
    }

    public String getName() {
        return NbBundle.getMessage(TestAction.class, "CTL_TestAction");
    }

    @Override
    protected String iconResource() {
        return "org/lcswing/images/icontes.png";
    }

    public HelpCtx getHelpCtx() {
        return HelpCtx.DEFAULT_HELP;
    }

    @Override
    protected boolean asynchronous() {
        return false;
    }
}
