package org.lcswing;

import com.sun.java.swing.plaf.motif.MotifLookAndFeel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import org.openide.util.Exceptions;
import org.openide.util.NbBundle;
import org.openide.windows.TopComponent;

/**
 *
 * @author appiah
 */
public class DataViewComponent extends TopComponent implements ActionListener {

    private DataViewComponent view = null;

    public DataViewComponent(int view) {

        setLayout(new BorderLayout(10, 10));
        setName(NbBundle.getMessage(LCTopComponent.class, "CTL_DataViewAction"));
        setDisplayName(NbBundle.getMessage(LCTopComponent.class, "CTL_DataViewAction"));
        add(createPopmenu(), BorderLayout.WEST);

        JScrollPane imagepane = null;
        if (view == 0) {
            imagepane = new JScrollPane(createODImages(), JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        } else if (view == 1) {
            imagepane = new JScrollPane(createSDImages(), JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        } else if (view == 2) {
            imagepane = new JScrollPane(createHDImages(), JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        } else if (view == 3) {
            imagepane = new JScrollPane(createIDImages(), JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        }
        add(imagepane, BorderLayout.CENTER);
    }

    public DataViewComponent(JPanel panel) {
        try {

            setLayout(new BorderLayout(10, 10));
            setName(NbBundle.getMessage(LCTopComponent.class, "CTL_DataViewAction"));
            setDisplayName(NbBundle.getMessage(LCTopComponent.class, "CTL_DataViewAction"));
            add(createPopmenu(), BorderLayout.WEST);

            JScrollPane imagepane = new JScrollPane(panel, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            add(imagepane, BorderLayout.CENTER);
            UIManager.setLookAndFeel(new MotifLookAndFeel());
        } catch (UnsupportedLookAndFeelException ex) {
            Exceptions.printStackTrace(ex);
        }
    }

    private JPopupMenu createPopmenu() {

        JPopupMenu menu = new JPopupMenu("Data View Menu");
        ImageIcon icn = new ImageIcon(this.getClass().getResource("images/diadat.png"));
        JMenuItem item = new JMenuItem(NbBundle.getMessage(LCTopComponent.class, "CTL_DataOrthoViewAction"), icn);
        item.setMnemonic(KeyEvent.VK_O);
        item.setActionCommand(NbBundle.getMessage(LCTopComponent.class, "CTL_DataOrthoViewAction"));
        item.addActionListener(this);
        item.setBackground(new Color(Color.HSBtoRGB(0.692002f, 0.998112f, 1.0f)));
        menu.add(item);
        item = new JMenuItem(NbBundle.getMessage(LCTopComponent.class, "CTL_DataSymmViewAction"), icn);
        item.setMnemonic(KeyEvent.VK_S);
        item.setActionCommand(NbBundle.getMessage(LCTopComponent.class, "CTL_DataSymmViewAction"));
        item.addActionListener(this);
        item.setBackground(new Color(Color.HSBtoRGB(0.92002f, 0.8888112f, 1.0f)));
        menu.add(item);
        item = new JMenuItem(NbBundle.getMessage(LCTopComponent.class, "CTL_DataIncViewAction"), icn);
        item.setMnemonic(KeyEvent.VK_I);
        item.setActionCommand(NbBundle.getMessage(LCTopComponent.class, "CTL_DataIncViewAction"));
        item.addActionListener(this);
        item.setBackground(new Color(Color.HSBtoRGB(0.32002f, 0.879992f, 0.98880f)));
        menu.add(item);
        item = new JMenuItem(NbBundle.getMessage(LCTopComponent.class, "CTL_DataHierViewAction"), icn);
        item.setMnemonic(KeyEvent.VK_H);
        item.setActionCommand(NbBundle.getMessage(LCTopComponent.class, "CTL_DataHierViewAction"));
        item.addActionListener(this);
        item.setBackground(new Color(Color.HSBtoRGB(0.4552002f, 0.668112f, 1.0f)));
        menu.add(item);
        menu.setVisible(true);
        return menu;
    }

    public JPanel createSDImages() {
        JPanel pane = new JPanel(new GridLayout(1, 1, 15, 10));
        pane.setBackground(Color.getHSBColor(0.749929f, 0.4568f, 0.95555f));
        int w = 800, h = 600;

        JLabel labelcen = new JLabel("Symmetrical Diagram", SwingConstants.CENTER);
        ImageIcon icon = new ImageIcon(this.getClass().getResource("images/LCDD-symlay.jpg"));

        labelcen.setIcon(new ImageIcon(icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH)));

        pane.add(labelcen);

        return pane;
    }

    public JPanel createIDImages() {
        JPanel pane = new JPanel(new GridLayout(1, 1, 15, 10));
        pane.setBackground(Color.getHSBColor(0.49929f, 0.468f, 0.5555f));
        int w = 800, h = 600;

        JLabel labelcen = new JLabel("Incremental Diagram", SwingConstants.CENTER);
        ImageIcon icon = new ImageIcon(this.getClass().getResource("images/LCDD-increlay.jpg"));

        labelcen.setIcon(new ImageIcon(icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH)));

        pane.add(labelcen);

        return pane;
    }

    public JPanel createHDImages() {
        JPanel pane = new JPanel(new GridLayout(1, 1, 15, 10));
        pane.setBackground(Color.getHSBColor(0.9929f, 0.68f, 0.9555f));
        int w = 800, h = 600;

        JLabel labelcen = new JLabel("Hierarchical Diagram", SwingConstants.CENTER);
        ImageIcon icon = new ImageIcon(this.getClass().getResource("images/LCDD-hielay.jpg"));

        labelcen.setIcon(new ImageIcon(icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH)));

        pane.add(labelcen);

        return pane;
    }

    private JPanel createODImages() {
        JPanel pane = new JPanel(new GridLayout(2, 1, 15, 10));
        pane.setBackground(Color.getHSBColor(0.49929f, 0.68f, 0.95555f));

        int w = 800, h = 600;
        JLabel labelcen = new JLabel("Orthogonal Diagram", SwingConstants.CENTER);
        ImageIcon icon = new ImageIcon(this.getClass().getResource("images/LCDDia.jpg"));

        labelcen.setIcon(new ImageIcon(icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH)));

        pane.add(labelcen);

        return pane;
    }

    @Override
    public int getPersistenceType() {
        return PERSISTENCE_NEVER;
    }

    public void actionPerformed(ActionEvent e) {
        String action = e.getActionCommand();
        if (action.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "CTL_DataSymmViewAction"))) {
            if (view != null) {
                view.close();
            }
            view = new DataViewComponent(1);
            view.setName(NbBundle.getMessage(LCTopComponent.class, "CTL_DataSymmViewAction"));
            view.setDisplayName(NbBundle.getMessage(LCTopComponent.class, "CTL_DataSymmViewAction"));
            view.open();
            view.requestActive();
        } else if (action.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "CTL_DataOrthoViewAction"))) {
            if (view != null) {
                view.close();
            }
            view = new DataViewComponent(0);
            view.setName(NbBundle.getMessage(LCTopComponent.class, "CTL_DataOrthoViewAction"));
            view.setDisplayName(NbBundle.getMessage(LCTopComponent.class, "CTL_DataOrthoViewAction"));
            view.open();
            view.requestActive();
        } else if (action.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "CTL_DataHierViewAction"))) {
            if (view != null) {
                view.close();
            }
            view = new DataViewComponent(2);
            view.setName(NbBundle.getMessage(LCTopComponent.class, "CTL_DataHierViewAction"));
            view.setDisplayName(NbBundle.getMessage(LCTopComponent.class, "CTL_DataHierViewAction"));
            view.open();
            view.requestActive();
        } else if (action.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "CTL_DataIncViewAction"))) {
            if (view != null) {
                view.close();
            }
            view = new DataViewComponent(3);
            view.setName(NbBundle.getMessage(LCTopComponent.class, "CTL_DataIncViewAction"));
            view.setDisplayName(NbBundle.getMessage(LCTopComponent.class, "CTL_DataIncViewAction"));
            view.open();
            view.requestActive();
        }
    }
}
