package org.lcswing;

import com.sun.java.swing.plaf.motif.MotifLookAndFeel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import org.openide.util.Exceptions;
import org.openide.util.NbBundle;
import org.openide.windows.TopComponent;

/**
 *
 * @author appiah
 */
public class InterfaceViewComponent extends TopComponent implements ActionListener {

    private InterfaceViewComponent view = null;
    private ImageIcon icon=null;
    public InterfaceViewComponent(int view) {
        try {

            setLayout(new BorderLayout(10, 10));
            add(createPopmenu(), BorderLayout.WEST);

            JScrollPane imagepane = null;
            if (view == 0) {
                imagepane = new JScrollPane(createODImages(), JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            } else if (view == 1) {
                imagepane = new JScrollPane(createIDImages(), JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            } else if (view == 2) {
                imagepane = new JScrollPane(createHDImages(), JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            } else if (view == 3) {
                imagepane = new JScrollPane(createSDImages(), JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            }
            add(imagepane, BorderLayout.CENTER);
            UIManager.setLookAndFeel(new MotifLookAndFeel());
        } catch (UnsupportedLookAndFeelException ex) {
            Exceptions.printStackTrace(ex);
        }
    }

    public InterfaceViewComponent(JPanel panel) {

        setLayout(new BorderLayout(10, 10));
        add(createPopmenu(), BorderLayout.WEST);

        JScrollPane imagepane = new JScrollPane(panel, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        add(imagepane, BorderLayout.CENTER);
    }

    private JPopupMenu createPopmenu() {

        JPopupMenu menu = new JPopupMenu("Interface View Menu");
        ImageIcon icn = new ImageIcon(this.getClass().getResource("images/diainter.png"));

        JMenuItem item = new JMenuItem("Orthogonal Diagram", icn);
        item.setActionCommand("Orthogonal Diagram");
        item.addActionListener(this);
        item.setBackground(new Color(Color.HSBtoRGB(0.92002f, 0.498112f, 1.0f)));
        menu.add(item);
        item = new JMenuItem("Incremental Diagram", icn);
        item.setActionCommand("Incremental Diagram");
        item.addActionListener(this);
        item.setBackground(new Color(Color.HSBtoRGB(0.692002f, 0.298112f, 1.0f)));
        menu.add(item);
        item = new JMenuItem("Hierarchical Diagram", icn);
        item.setActionCommand("Hierarchical Diagram");
        item.addActionListener(this);
        item.setBackground(new Color(Color.HSBtoRGB(0.2002f, 0.8112f, 1.0f)));
        menu.add(item);
        item = new JMenuItem("Symmetrical Diagram", icn);
        item.setActionCommand("Symmetrical Diagram");
        item.addActionListener(this);
        item.setBackground(new Color(Color.HSBtoRGB(0.92002f, 0.112f, 1.0f)));
        menu.add(item);

        menu.setVisible(true);
        return menu;
    }

    public JPanel createSDImages() {
        JPanel pane = new JPanel(new GridLayout(1, 1, 15, 10));
        pane.setBackground(Color.getHSBColor(0.749929f, 0.64568f, 0.95555f));
        int w = 800, h = 600;

        JLabel labelcen = new JLabel("Symmetrical Diagram", SwingConstants.CENTER);
        icon = new ImageIcon(this.getClass().getResource("images/LCID-symmlay.jpg"));
        labelcen.setIcon(new ImageIcon(icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH)));
        pane.add(labelcen);

        return pane;
    }

    public JPanel createHDImages() {
        JPanel pane = new JPanel(new GridLayout(1, 1, 15, 10));
        pane.setBackground(Color.getHSBColor(0.9929f, 0.4568f, 0.95555f));
        int w = 800, h = 600;

        JLabel labelcen = new JLabel("Hierarchical Diagram", SwingConstants.CENTER);
        icon = new ImageIcon(this.getClass().getResource("images/LCID-hielays.jpg"));
        labelcen.setIcon(new ImageIcon(icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH)));
        
        pane.add(labelcen);

        return pane;
    }

    public JPanel createIDImages() {
        JPanel pane = new JPanel(new GridLayout(1, 1, 15, 10));
        pane.setBackground(Color.getHSBColor(0.19929f, 0.84568f, 0.95555f));
        int w = 800, h = 600;

        JLabel labelcen = new JLabel("Incremental Diagram", SwingConstants.CENTER);
        icon = new ImageIcon(this.getClass().getResource("images/LCID-increlay.jpg"));
        labelcen.setIcon(new ImageIcon(icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH)));
        
        pane.add(labelcen);

        return pane;
    }

    private JPanel createODImages() {
        JPanel pane = new JPanel(new GridLayout(2, 1, 15, 10));
        pane.setBackground(Color.getHSBColor(0.49929f, 0.4568f, 0.95555f));

        int w = 800, h = 600;

        JLabel labelcen = new JLabel("Orthogonal Diagram", SwingConstants.CENTER);
        icon = new ImageIcon(this.getClass().getResource("images/LCID-orth.jpg"));
        labelcen.setIcon(new ImageIcon(icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH)));
        
        pane.add(labelcen);

        return pane;
    }

    @Override
    public int getPersistenceType() {
        return PERSISTENCE_NEVER;
    }

    public void actionPerformed(ActionEvent e) {
        String action = e.getActionCommand();
        if (action.equalsIgnoreCase("Orthogonal Diagram")) {
            if (view != null) {
                view.close();
            }
            view = new InterfaceViewComponent(0);
            view.setName("View Orthogonal Diagram");
            view.setDisplayName("View Orthogonal Diagram");
            view.open();
            view.requestActive();
        } else if (action.equalsIgnoreCase("Incremental Diagram")) {
            if (view != null) {
                view.close();
            }
            view = new InterfaceViewComponent(1);
            view.setName("View Incremental Diagram");
            view.setDisplayName("View Incremental Diagram");
            view.open();
            view.requestActive();
        } else if (action.equalsIgnoreCase("Hierarchical Diagram")) {
            if (view != null) {
                view.close();
            }
            view = new InterfaceViewComponent(2);
            view.setName("View Hierarchical Diagram");
            view.setDisplayName("View Hierarchical Diagram");
            view.open();
            view.requestActive();
        } else if (action.equalsIgnoreCase("Symmetrical Diagram")) {
            if (view != null) {
                view.close();
            }
            view = new InterfaceViewComponent(3);
            view.setName("View Symmetrical Diagram");
            view.setDisplayName("View Symmetrical Diagram");
            view.open();
            view.requestActive();
        }
    }
}
