
package org.lcswing;

import org.openide.util.HelpCtx;
import org.openide.util.NbBundle;
import org.openide.util.actions.CallableSystemAction;

public final class DiagramAction extends CallableSystemAction {

    public DiagramAction() {
    }

    public void performAction() {
        ClassTopComponent dtc = new ClassTopComponent();
        dtc.open();
        dtc.requestActive();
    }

    public String getName() {
        return NbBundle.getMessage(DiagramAction.class, "CTL_DiagramAction");
    }

    @Override
    protected String iconResource() {
        return "org/lcswing/images/diaicon.png";
    }

    public HelpCtx getHelpCtx() {
        return new HelpCtx(NbBundle.getMessage(StartLCComputeAction.class, "HelpCtx-Diagram"));
    }

    @Override
    protected boolean asynchronous() {
        return false;
    }
}
