/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.lcswing;

import javax.swing.LookAndFeel;

/**
 *
 * @author appiah
 */
public class LCLookAndFeel extends LookAndFeel{

    @Override
    public String getName() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public String getID() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public String getDescription() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean isNativeLookAndFeel() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean isSupportedLookAndFeel() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
