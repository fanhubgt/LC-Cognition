/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.lcswing;

import org.openide.util.HelpCtx;
import org.openide.util.NbBundle;
import org.openide.util.actions.CallableSystemAction;

/**
 *
 * @author appiah
 */
public class StartLCComputeAction extends CallableSystemAction {

    public StartLCComputeAction() {

    }

    @Override
    public void performAction() {
        LCTopComponent component = new LCTopComponent();
        component.open();
        component.requestActive();
    }

    @Override
    public String getName() {
        return NbBundle.getMessage(StartLCComputeAction.class, "Button-Window-StartCompute");
    }

    @Override
    protected String iconResource() {
        return "org/lcswing/images/icon.png";
    }

    @Override
    public HelpCtx getHelpCtx() {
        return new HelpCtx(NbBundle.getMessage(StartLCComputeAction.class, "HelpCtx-StartCompute"));
    }

    protected boolean asynchronous() {
        return false;
    }
}
