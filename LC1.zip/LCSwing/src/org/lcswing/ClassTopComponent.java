package org.lcswing;

import com.sun.java.swing.plaf.motif.MotifLookAndFeel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import org.openide.util.Exceptions;
import org.openide.util.NbBundle;
import org.openide.windows.TopComponent;

/**
 *
 * @author appiah
 */
public class ClassTopComponent extends TopComponent implements ActionListener {

    private ClassViewComponent view = null;

    public ClassTopComponent() {
        try {
            setLayout(new BorderLayout(10, 10));
            setName(NbBundle.getMessage(LCTopComponent.class, "HelpCtx-Diagram"));
            setDisplayName(NbBundle.getMessage(LCTopComponent.class, "HelpCtx-Diagram"));
            add(createPopmenu(), BorderLayout.WEST);

            JScrollPane imagepane = new JScrollPane(createCDImages(), JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            add(imagepane, BorderLayout.CENTER);
            UIManager.setLookAndFeel(new MotifLookAndFeel());
        } catch (UnsupportedLookAndFeelException ex) {
            Exceptions.printStackTrace(ex);
        }
    }

    @Override
    public int getPersistenceType() {
        return PERSISTENCE_NEVER;
    }

    private JPopupMenu createPopmenu() {
        JPopupMenu menu = new JPopupMenu("Class View Menu");
        ImageIcon icn = new ImageIcon(this.getClass().getResource("images/icon.png"));
        JMenuItem item = new JMenuItem(NbBundle.getMessage(LCTopComponent.class, "CTL_ClassOrthoViewAction"), icn);
        item.setMnemonic(KeyEvent.VK_O);
        item.setActionCommand(NbBundle.getMessage(LCTopComponent.class, "CTL_ClassOrthoViewAction"));
        item.addActionListener(this);
        item.setBackground(new Color(Color.HSBtoRGB(0.692002f, 0.998112f, 1.0f)));
        menu.add(item);
        item = new JMenuItem(NbBundle.getMessage(LCTopComponent.class, "CTL_ClassSymmViewAction"), icn);
        item.setMnemonic(KeyEvent.VK_S);
        item.setActionCommand(NbBundle.getMessage(LCTopComponent.class, "CTL_ClassSymmViewAction"));
        item.addActionListener(this);
        item.setBackground(new Color(Color.HSBtoRGB(0.392002f, 0.998112f, 1.0f)));
        menu.add(item);
        item = new JMenuItem(NbBundle.getMessage(LCTopComponent.class, "CTL_ClassIncViewAction"), icn);
        item.setMnemonic(KeyEvent.VK_S);
        item.setActionCommand(NbBundle.getMessage(LCTopComponent.class, "CTL_ClassIncViewAction"));
        item.addActionListener(this);
        item.setBackground(new Color(Color.HSBtoRGB(0.662002f, 0.68812f, 0.880f)));
        menu.add(item);
        item = new JMenuItem(NbBundle.getMessage(LCTopComponent.class, "CTL_ClassHierViewAction"), icn);
        item.setMnemonic(KeyEvent.VK_S);
        item.setActionCommand(NbBundle.getMessage(LCTopComponent.class, "CTL_ClassHierViewAction"));
        item.addActionListener(this);
        item.setBackground(new Color(Color.HSBtoRGB(0.772002f, 0.8112f, 0.7862280f)));
        menu.add(item);
        menu.setVisible(true);
        return menu;
    }

    public JPanel createCDImages() {
        JPanel pane = new JPanel(new GridLayout(4, 1, 15, 10));

        int w = 300, h = 130;

        JLabel labelcen = new JLabel("Orthogonal Diagram", SwingConstants.CENTER);
        ImageIcon icon = new ImageIcon(this.getClass().getResource("images/LCCD-ortho.jpg"));
        labelcen.setIcon(new ImageIcon(icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH)));
        pane.add(labelcen);

        labelcen = new JLabel("Symmetrical Diagram", SwingConstants.CENTER);
        icon = new ImageIcon(this.getClass().getResource("images/LCCD-symlay.jpg"));
        labelcen.setIcon(new ImageIcon(icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH)));
        pane.add(labelcen);

        labelcen = new JLabel("Hierarchical Diagram", SwingConstants.CENTER);
        icon = new ImageIcon(this.getClass().getResource("images/LCCD-hielay.jpg"));
        labelcen.setIcon(new ImageIcon(icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH)));
        pane.add(labelcen);

        labelcen = new JLabel("Incremental Diagram", SwingConstants.CENTER);
        icon = new ImageIcon(this.getClass().getResource("images/LCCD-incre.jpg"));
        labelcen.setIcon(new ImageIcon(icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH)));
        pane.add(labelcen);

        return pane;
    }

    public void actionPerformed(ActionEvent e) {
        String action = e.getActionCommand();
        if (action.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "CTL_ClassSymmViewAction"))) {
            if (view != null) {
                view.close();
            }
            view = new ClassViewComponent(0);
            view.setName(NbBundle.getMessage(LCTopComponent.class, "CTL_ClassSymmViewAction"));
            view.setDisplayName(NbBundle.getMessage(LCTopComponent.class, "CTL_ClassSymmViewAction"));
            view.open();
            view.requestActive();
        } else if (action.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "CTL_ClassOrthoViewAction"))) {
            if (view != null) {
                view.close();
            }
            view = new ClassViewComponent(1);
            view.setName(NbBundle.getMessage(LCTopComponent.class, "CTL_ClassOrthoViewAction"));
            view.setDisplayName(NbBundle.getMessage(LCTopComponent.class, "CTL_ClassOrthoViewAction"));
            view.open();
            view.requestActive();
        } else if (action.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "CTL_ClassIncViewAction"))) {
            if (view != null) {
                view.close();
            }
            view = new ClassViewComponent(2);
            view.setName(NbBundle.getMessage(LCTopComponent.class, "CTL_ClassIncViewAction"));
            view.setDisplayName(NbBundle.getMessage(LCTopComponent.class, "CTL_ClassIncViewAction"));
            view.open();
            view.requestActive();
        } else if (action.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "CTL_ClassHierViewAction"))) {
            if (view != null) {
                view.close();
            }
            view = new ClassViewComponent(3);
            view.setName(NbBundle.getMessage(LCTopComponent.class, "CTL_ClassHierViewAction"));
            view.setDisplayName(NbBundle.getMessage(LCTopComponent.class, "CTL_ClassHierViewAction"));
            view.open();
            view.requestActive();
        }
    }
}
