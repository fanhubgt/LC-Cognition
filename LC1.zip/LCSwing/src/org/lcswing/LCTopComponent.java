package org.lcswing;

import com.sun.java.swing.plaf.motif.MotifLookAndFeel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.StringTokenizer;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.MatteBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.MenuKeyEvent;
import javax.swing.event.MenuKeyListener;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import lcprogram.AlphaLabel;
import lcprogram.IAlphanumeric;
import lcprogram.ILCProblem;
import lcprogram.LCProgram;
import lcprogram.Sentence;
import org.openide.util.Exceptions;
import org.openide.util.NbBundle;
import org.openide.windows.TopComponent;

/**
 *
 * @author appiah
 */
public class LCTopComponent extends TopComponent implements ActionListener, KeyListener, ChangeListener, MouseListener, PopupMenuListener, MenuKeyListener {

    private static int tcCount = 0; //A counter to limit number of simultaneously existing images
    private static int ct = 0; //A counter we use to provide names for new images
    private JTextPane tp;
    private LCProgram program = new LCProgram();
    private ILCProblem problem = program.getProblem();
    boolean boolsentinel = true;

    static int getLCTCCount() {
        return tcCount;
    }

    public LCTopComponent() {
        try {
            setName(NbBundle.getMessage(LCTopComponent.class, "Window-Name"));
            setDisplayName(NbBundle.getMessage(LCTopComponent.class, "Window-DisplayName"));
            tcCount++;
            setSize(new Dimension(350, 400));
            setLayout(new BorderLayout());
            setBackground(new Color(Color.HSBtoRGB(0.987654f, 0.592349910f, 1.0f)));
            setForeground(new Color(Color.HSBtoRGB(0.987654f, 0.592349910f, 1.0f)));
            setToolTipText("LCCompute User Interface");
            setBorder(new MatteBorder(new Insets(5, 5, 5, 5), new Color(Color.HSBtoRGB(0.7f, 0.989f, 1.0f))));
            UIManager.setLookAndFeel(new MotifLookAndFeel());
            // UIManager.setLookAndFeel(new MetalLookAndFeel());

            if (boolsentinel) {
                program.MPSentences();
            }
            JScrollPane btnpane = new JScrollPane(createButtons(), JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            btnpane.setPreferredSize(new Dimension(500, 200));
            // imagepane.setMaximumSize(new Dimension(300, 200));
            btnpane.setMinimumSize(new Dimension(500, 200));
            JScrollPane imagepane = new JScrollPane(createScrollImages(), JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            imagepane.setPreferredSize(new Dimension(300, 200));
            // imagepane.setMaximumSize(new Dimension(300, 200));
            imagepane.setMinimumSize(new Dimension(300, 200));
            JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
            splitPane.setDividerLocation(470);
            splitPane.setLastDividerLocation(70);
            splitPane.setOneTouchExpandable(true);
            //splitPane.setDividerSize();splitPane
            splitPane.add(btnpane);
            splitPane.add(imagepane);
            add(splitPane, BorderLayout.CENTER);
            splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
            splitPane.setDividerLocation(470);
            splitPane.setLastDividerLocation(80);
            splitPane.setOneTouchExpandable(true);
            splitPane.add(createOutput());
            splitPane.add(createProblemButtons());
            add(splitPane, BorderLayout.SOUTH);
            setTPFont();
        } catch (UnsupportedLookAndFeelException ex) {
            Exceptions.printStackTrace(ex);
        }
    }

    public void setTPFont() {
        Random ra = new Random();
        switch (ra.nextInt(8)) {
            case 1:
                tp.setFont(new Font("Courier 10 Pitch", Font.PLAIN, 12));
                break;
            case 2:
                tp.setFont(new Font("Arial", Font.PLAIN, 12));
                break;
            case 3:
                tp.setFont(new Font("New Times Roman", Font.PLAIN, 12));
                break;
            case 4:
                tp.setFont(new Font("Serif", Font.PLAIN, 12));
                break;

            case 5:
                tp.setFont(new Font("Nimbus Serif", Font.PLAIN, 12));

                break;
            case 6:
                tp.setFont(new Font("Nimbus Mono", Font.BOLD, 12));
                break;
            case 7:
                tp.setFont(new Font("URW Bookman L", Font.PLAIN, 12));
                break;
            case 8:
                tp.setFont(new Font("URW Gothic L", Font.PLAIN, 12));
                break;
        }
    }

    @Override
    public int getPersistenceType() {
        return PERSISTENCE_NEVER;
    }

    public JScrollPane createOutput() {
        tp = new JTextPane();
        tp.setBackground(new Color(Color.HSBtoRGB(0.5888888f, 0.66666f, 0.333333f), true));
        tp.setForeground(new Color(Color.HSBtoRGB(0.1921222f, 0.1970f, 0.31234567f)));
        tp.setFont(new Font(Font.SERIF, Font.BOLD, 12));

        tp.setText("Result Output:");
        tp.setPreferredSize(new Dimension(500, 190));
        tp.setMinimumSize(new Dimension(500, 100));
        tp.setEditable(false);

        JScrollPane textpane = new JScrollPane(tp, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        return textpane;
    }

    public JPanel createScrollImages() {
        JPanel pane = new JPanel(new GridLayout(5, 1, 15, 10));
        pane.setBackground(Color.WHITE);
        int w = 300, h = 130;
        //pane.setPreferredSize(new Dimension(w, h));
        // pane.setMaximumSize(new Dimension(w, h));
        // pane.setMinimumSize(new Dimension(w, h));

        JPopupMenu menu = new JPopupMenu(NbBundle.getMessage(LCTopComponent.class, "Popmenu-System"));
        ImageIcon icn = new ImageIcon(this.getClass().getResource("images/icon.png"));
        menu.add(new JMenuItem("Sentence 1", icn));
        menu.add(new JMenuItem("Sentence 2", icn));
        menu.add(new JMenuItem("Sentence 3", icn));
        menu.add(new JMenuItem("Sentence 4", icn));
        menu.add(new JMenuItem("Sentence 5", icn));
        menu.addMenuKeyListener(this);
        menu.setVisible(false);
        //  pane.add(menu);

        JLabel labelcen = new JLabel("Sentence Structure [1]", SwingConstants.CENTER);
        ImageIcon icon = new ImageIcon(this.getClass().getResource("images/wordcount(1).png"));
        labelcen.setIcon(new ImageIcon(icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH)));
        pane.add(labelcen);

        labelcen = new JLabel("Sentence Structure [2]", SwingConstants.CENTER);
        icon = new ImageIcon(this.getClass().getResource("images/wordcount(2).png"));
        labelcen.setIcon(new ImageIcon(icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH)));
        pane.add(labelcen);

        labelcen = new JLabel("Sentence Structure [3]", SwingConstants.CENTER);
        icon = new ImageIcon(this.getClass().getResource("images/wordcount(3).png"));
        labelcen.setIcon(new ImageIcon(icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH)));
        pane.add(labelcen);

        labelcen = new JLabel("Sentence Structure [4]", SwingConstants.CENTER);
        icon = new ImageIcon(this.getClass().getResource("images/wordcount(4).png"));
        labelcen.setIcon(new ImageIcon(icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH)));
        pane.add(labelcen);

        labelcen = new JLabel("Sentence Structure [5]", SwingConstants.CENTER);
        icon = new ImageIcon(this.getClass().getResource("images/wordcount.png"));
        labelcen.setIcon(new ImageIcon(icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH)));
        pane.add(labelcen);


        return pane;
    }

    public JPanel createProblemButtons() {
        JPanel pane = new JPanel(new GridLayout(6, 1));
        pane.setMaximumSize(new Dimension(140, 100));
        pane.setPreferredSize(new Dimension(50, 50));

        JLabel title = new JLabel("LC PROBLEMS", SwingConstants.CENTER);
        pane.setBackground(Color.getHSBColor(.29999f, 0.73839933f, .09f));
        title.setForeground(Color.ORANGE);
        pane.add(title);
        String label = NbBundle.getMessage(LCTopComponent.class, "Moon-Sun-Go-Problem");
        JButton button = new JButton();
        button.setToolTipText(NbBundle.getMessage(LCTopComponent.class, "Moon-Sun-Go-Tooltiptext"));
        button.setBackground(new Color(Color.HSBtoRGB(0.900389019f, 0.6789f, 0.9900988f)));
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg7.png")));
        button.setSelectedIcon(new ImageIcon(this.getClass().getResource("images/btnimg7.png")));

        button.setForeground(Color.WHITE);
        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Family-Vision-Problem");
        button = new JButton();
        button.setToolTipText(NbBundle.getMessage(LCTopComponent.class, "Family-Vision-Tooltiptext"));
        button.setBackground(new Color(Color.HSBtoRGB(0.55811389019f, 0.6990056099f, 0.91188f)));
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg2.png")));
        button.setSelectedIcon(new ImageIcon(this.getClass().getResource("images/btnimg2.png")));

        button.setActionCommand(label);
        button.setForeground(Color.WHITE);
        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Hand-Wall-Problem");
        button = new JButton();
        button.setToolTipText(NbBundle.getMessage(LCTopComponent.class, "Hand-Wall-Tooltiptext"));
        button.setBackground(new Color(Color.HSBtoRGB(0.7055008092019f, 0.5004356789f, 0.900088f)));
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));
        button.setSelectedIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));

        button.setForeground(Color.WHITE);
        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "School-Sing-Problem");
        button = new JButton();
        button.setToolTipText(NbBundle.getMessage(LCTopComponent.class, "School-Sing-Tooltiptext"));
        button.setBackground(new Color(Color.HSBtoRGB(0.800500389019f, 0.811114356789f, 0.588f)));
        button.setForeground(Color.WHITE);
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg2.png")));
        button.setSelectedIcon(new ImageIcon(this.getClass().getResource("images/btnimg2.png")));

        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);

        label = NbBundle.getMessage(LCTopComponent.class, "Love-Dear-Problem");
        button = new JButton();
        button.setToolTipText(NbBundle.getMessage(LCTopComponent.class, "Love-Dear-Tooltiptext"));
        button.setBackground(new Color(Color.HSBtoRGB(0.6522251100019f, 0.911114000f, 0.4008f)));
        button.setForeground(Color.WHITE);
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg.png")));
        button.setSelectedIcon(new ImageIcon(this.getClass().getResource("images/btnimg7.png")));

        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);

        return pane;
    }

    public JPanel createButtons() {
        JPanel pane = new JPanel(new GridLayout(8, 3));
        // pane.setMinimumSize(new Dimension(getWidth() / 4, getHeight() / 4));
        // pane.setMaximumSize(new Dimension(getWidth() / 3, getHeight() / 3));
        // pane.setPreferredSize(new Dimension(getWidth() / 2, getHeight() / 2));

        pane.setToolTipText(NbBundle.getMessage(LCTopComponent.class, "Button-Pane-ToolTipText"));
        String label = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-Problem");
        JButton button = new JButton("  " + label);
        button.setBackground(new Color(Color.HSBtoRGB(0.12345667f, 0.3456789f, 0.9999999999f)));
        button.setActionCommand(label);
        button.addActionListener(this);
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));

        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-Menu");
        button = new JButton("  " + label);
        button.setBackground(new Color(Color.HSBtoRGB(0.24689f, 0.12346789f, 0.9945679999f)));
        button.setActionCommand(label);
        button.addActionListener(this);
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));

        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-Sentence");
        button = new JButton(label);
        button.setBackground(new Color(Color.HSBtoRGB(0.422227f, 0.3222789f, 0.99111999f)));
        button.setActionCommand(label);
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));

        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-MPPrinciples");
        button = new JButton(label);
        button.setBackground(new Color(Color.HSBtoRGB(0.12333367f, 0.93456789f, 0.9999999999f)));
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));

        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-AlphaSize");
        button = new JButton(label);
        button.setBackground(new Color(Color.HSBtoRGB(0.2358145667f, 0.3456789f, 0.9999999999f)));
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));

        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-PartitonInt");
        button = new JButton(label);
        button.setBackground(new Color(Color.HSBtoRGB(0.45667f, 0.3556789f, 0.999992222f)));
        button.setActionCommand(label);
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));

        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-CountMethod");
        button = new JButton(label);
        button.setBackground(new Color(Color.HSBtoRGB(0.667f, 0.789f, 0.9999999999f)));
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));

        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-Alphalabel");
        button = new JButton(label);
        button.setBackground(new Color(Color.HSBtoRGB(0.5667f, 0.6789f, 0.9999922f)));
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));

        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-Sets");
        button = new JButton("  " + label);
        button.setBackground(new Color(Color.HSBtoRGB(0.7f, 0.789f, 0.9999999f)));
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));

        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-RMPPrinciple");
        button = new JButton("  " + label);
        button.setBackground(new Color(Color.HSBtoRGB(0.345667f, 0.56789f, 0.999999f)));
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));
        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-Alphanumerics");
        button = new JButton(label);
        button.setActionCommand(label);
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));

        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-MetaOp");
        button = new JButton(label);
        button.setBackground(new Color(Color.HSBtoRGB(0.2566f, 0.3456789f, 0.9999999999f)));
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));

        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-LMPSet");
        button = new JButton(label);
        button.setBackground(new Color(Color.HSBtoRGB(0.4234444f, 0.9456789f, 0.9999999999f)));
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));

        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-FileStream");
        button = new JButton(label);
        button.setBackground(new Color(Color.HSBtoRGB(0.934444f, 0.9456789f, 0.9999999999f)));
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));
        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-ChangeProblemSize");
        button = new JButton(label);
        button.setBackground(new Color(Color.HSBtoRGB(0.5555f, 0.55555f, 0.9999999999f)));
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));

        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-SentenceEntry");
        button = new JButton(label);
        button.setBackground(new Color(Color.HSBtoRGB(0.4006666f, 0.666777f, 0.99999f)));
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));

        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-LCTable");
        button = new JButton("  " + label);
        button.setBackground(new Color(Color.HSBtoRGB(0.1277777f, 0.579f, 0.79999f)));
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));

        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-PartitionRow");
        button = new JButton("  " + label);
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));

        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-Equality");
        button = new JButton("  " + label);
        button.setBackground(new Color(Color.HSBtoRGB(0.5554444f, 0.9456789f, 0.9999999999f)));
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));

        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-Ferrers");
        button = new JButton(label);
        button.setBackground(new Color(Color.HSBtoRGB(0.6664444f, 0.68049f, 0.90999f)));
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));

        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-CombInfo");
        button = new JButton(label);
        button.setBackground(new Color(Color.HSBtoRGB(0.666f, 0.7046669f, 0.99999999f)));
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));

        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-CorrInfo");
        button = new JButton(label);
        button.setBackground(new Color(Color.HSBtoRGB(0.14444f, 0.9456789f, 0.9999999999f)));
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));

        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-NoOrders");
        button = new JButton(label);
        button.setBackground(new Color(Color.HSBtoRGB(0.9994444f, 0.9456789f, 0.9999999999f)));
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));

        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-Pascal");
        button = new JButton(label);
        button.setBackground(new Color(Color.HSBtoRGB(0.888834444f, 0.9456789f, 0.9999999999f)));
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg3.png")));

        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);
        label = NbBundle.getMessage(LCTopComponent.class, "Appiah-Test");
        button = new JButton(label);
        button.setToolTipText(NbBundle.getMessage(LCTopComponent.class, "Appiah-Test-Tooltiptext"));
        button.setBackground(new Color(Color.HSBtoRGB(0.700389019f, 0.654356789f, 0.9900988f)));
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg2.png")));

        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);

        label = NbBundle.getMessage(LCTopComponent.class, "Button-Window-StartCompute");
        button = new JButton(label);
        button.setBackground(new Color(Color.HSBtoRGB(0.2389019f, 0.9456789f, 0.9999999999f)));
        button.setIcon(new ImageIcon(this.getClass().getResource("images/btnimg5.png")));

        button.setActionCommand(label);
        button.addActionListener(this);
        pane.add(button);

        return pane;
    }

    private void LCmenu() {
        {
            String text = tp.getText();
            text += "\n\nLCProgram Menu\nExplicit Count Methods\n==========================\n";
            text += "\n01:     Problem Size";
            text += "\n02:     MP Sentences";
            text += "\n03:     Principle Values (MPSet)";
            text += "\n04:     Alpha Sizes";
            text += "\n05:     Partition Sets";
            text += "\n06:     Count Problems";
            text += "\n07:     Alpha Label Tokens";
            text += "\n08:     MP Sets";
            text += "\n09:     Principle Values (RMPSet)";
            text += "\n10:     Alphanumerics";
            text += "\n11:     Meta-Operation";
            text += "\n12:     Principle Values (LMPSet)";
            text += "\n13:     File MP Reader";
            text += "\n14:     Change Problem Size";
            text += "\n15:     Change LC Problems[Interactive]";
            text += "\n16:     LCTable View";
            text += "\n17:     Partition of Integers";
            text += "\n18:     Equality Principles";
            text += "\n19:     Show Ferrers Diagrams";
            text += "\n20:     Permutation and Combination";
            text += "\n21:     One-to-One Correspondence";
            text += "\n22:     Possible Number of Orders";
            text += "\n23:     Show Pascal Triangle";
            text += "\n24:     Moon-sun Problem";
            text += "\n25:     Family-Vision Problem";
            text += "\n26:     Appiah Test";
            text += "\nPress Ctrl+C: Quit LCProgram";
            text += "\n==========================\n";
            tp.setForeground(new Color(Color.HSBtoRGB(0.1221222f, 0.1970f, 0.94567f)));
            tp.setText(text);
        }
    }

    public void actionPerformed(ActionEvent e) {
        String actionCom = e.getActionCommand();
        String actionCase = NbBundle.getMessage(LCTopComponent.class, "Button-Pane-Problem");
        if (actionCom.equalsIgnoreCase(actionCase)) {
            problem = program.getProblem();
            String text = tp.getText();
            text += "\n\nProblem Size Information\n=======================\n";
            text += "Problem size:" + problem.getProblemSize();
            tp.setForeground(new Color(Color.HSBtoRGB(0.1321222f, 0.1970f, 0.934567f)));
            tp.setText(text);
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Button-Pane-Menu"))) {
            LCmenu();
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Button-Pane-Sentence"))) {
            String text = tp.getText();
            text += "\n\nSentence System Information\n==========================\n";
            problem = program.getProblem();
            for (int i = 0; i < program.getProblem().getProblemSize(); i++) {
                text += "\nSentence Structure (" + (i + 1) + ")::" + problem.getSentences().get(i).toString();
            }
            tp.setForeground(new Color(Color.HSBtoRGB(0.2921222f, 0.1970f, 0.931234567f)));
            tp.setText(text);
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Button-Pane-MPPrinciples"))) {
            String text = tp.getText();
            text += "\n\nMP(Set) Principle Values\n=============================\n";
            text += "\nAddition Principle Value(MP):=" + program.add();
            text += "\nSubstraction Principle Value(MP):=" + program.substract();
            text += "\nMultiplication Principle Value(MP):=" + program.multiply();
            text += "\nAddition Principle Value(MPSet):=" + program.addMPSet();
            text += "\nSubstraction Principle Value(MPSet):=" + program.subMPSet();
            text += "\nMultiplication Principle Value(MPSet):=" + program.mulMPSet();
            tp.setForeground(new Color(Color.HSBtoRGB(0.1521222f, 0.1970f, 0.931234567f)));
            tp.setText(text);
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Button-Pane-AlphaSize"))) {
            String text = tp.getText();
            problem = program.getProblem();
            text += ("\n\nAlpha Sizes Information\n===========================\n");
            for (int i = 0; i < program.getProblem().getProblemSize(); i++) {
                text += ("\n(" + (1 + i) + ") Word size:" + problem.getSentences().get(i).getAlphaLabels().size());
            }
            tp.setForeground(new Color(Color.HSBtoRGB(0.1321222f, 0.18970f, 0.933123f)));
            tp.setText(text);
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Button-Pane-PartitonInt"))) {
            String text = tp.getText();
            text += ("\n\nPartition of Integers\n=============================\n");
            text += (program.partition().toString());
            tp.setForeground(new Color(Color.HSBtoRGB(0.6521222f, 0.1970f, 0.931234567f)));
            tp.setText(text);
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Button-Pane-CountMethod"))) {
            String text = tp.getText();
            problem = program.getProblem();
            text += ("\n\nCount Method Information\n==============================\n");
            for (int i = 0; i < program.getProblem().getProblemSize(); i++) {
                text += ("\nCount MP(" + (1 + i) + "):" + problem.getSentences().get(i).getCount());
            }
            tp.setForeground(new Color(Color.HSBtoRGB(0.1521222f, 0.1970f, 0.931234567f)));
            tp.setText(text);
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Button-Pane-Alphalabel"))) {
            String text = tp.getText();
            problem = program.getProblem();
            text += ("\n\nAlpha-Label Information\n======================================\n");
            for (int i = 0; i < program.getProblem().getProblemSize(); i++) {
                ArrayList<AlphaLabel> labs = problem.getSentences().get(i).getAlphaLabels();
                text += ("\nAlphalabel " + (i + 1) + ":[");
                String words = "";
                for (int k = 0; k < labs.size(); k++) {
                    words += labs.get(k).getWord() + ", ";
                }
                words = words.substring(0, words.length() - 2);
                text += (words.trim() + "]");
                text += ("");
            }
            tp.setForeground(new Color(Color.HSBtoRGB(0.222f, 0.89070f, 0.93121237f)));
            tp.setText(text);
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Button-Pane-Sets"))) {
            String text = tp.getText();
            text += ("\n\nMP Sets Information\n===============================\n");
            text += ("\nMP:=" + program.MPOrder());
            text += ("\nMPset:=" + program.MPSetOrder());
            text += ("\nRMPset:=" + program.RMPSetOrder());
            text += ("\nLMPset:=" + program.LMPSetOrder());
            tp.setForeground(new Color(Color.HSBtoRGB(0.11121222f, 0.67970f, 0.91237f)));
            tp.setText(text);
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Button-Pane-RMPPrinciple"))) {
            String text = tp.getText();
            text += ("\n\nPrinciple Values for RMPSet\n======================================\n");
            text += ("\nAddition Principle Value(RMPSet):=" + program.addRMP());
            text += ("\nSubstraction Principle Value(RMPSet):=" + program.subRMP());
            text += ("\nMultiplication Principle Value(RMPSet):=" + program.mulRMP());
            tp.setForeground(new Color(Color.HSBtoRGB(0.5552545556f, 0.1987f, 0.957357f)));
            tp.setText(text);
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Button-Pane-Alphanumerics"))) {
            String text = tp.getText();
            problem = program.getProblem();
            text += ("\n\nAlphanumerics Information\n=======================================\n");
            ArrayList<Sentence> sentences = problem.getSentences();
            for (int i = 0; i < sentences.size(); i++) {
                Sentence s = sentences.get(i);
                text += ("\nSentence MP(" + (i + 1) + "): ");
                List<IAlphanumeric> als = s.getAlphanumeric();
                for (int k = 0; k < als.size(); k++) {
                    IAlphanumeric ia = als.get(k);
                    String leyy = (ia.getLetter() + "(" + ia.getSize() + ")  ");
                    text += leyy;
                }
                text += ("");
            }
            tp.setForeground(new Color(Color.HSBtoRGB(0.1521222f, 0.970f, 0.89234567f)));
            tp.setText(text);
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Button-Pane-MetaOp"))) {
            String text = tp.getText();
            text += ("\n\nMeta-sentential Operations\n====================================\n");
            program.metaSententialOperation();
            text += (program.getOperations());
            tp.setForeground(new Color(Color.HSBtoRGB(0.231233f, 0.912131415f, 0.9654321f)));
            tp.setText(text);
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Button-Pane-LMPSet"))) {
            String text = tp.getText();
            text += ("\n\nPrinciple values for LMPSet\n==================================\n");
            text += ("\nAddition Principle Value(LMPSet):=" + program.addLMP());
            text += ("\nSubstraction Principle Value(LMPSet):=" + program.subLMP());
            text += ("\nMultiplication Principle Value(LMPSet):=" + program.mulLMP());
            tp.setForeground(new Color(Color.HSBtoRGB(0.9521222f, 0.1970f, 0.91234567f)));
            tp.setText(text);
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Button-Pane-FileStream"))) {
            String text = tp.getText();
            text += ("\n\nFile Sentence Stream\n=======================\n");
            program.getProblem().clearMPSentinels();

            try {
                JFileChooser jfc = new JFileChooser();
                FileNameExtensionFilter filter = new FileNameExtensionFilter("Select sentence file to be read", "txt");
                jfc.setFileFilter(filter);
                int approve = jfc.showOpenDialog(this);
                if (approve == JFileChooser.APPROVE_OPTION) {
                    BufferedReader br = new BufferedReader(new FileReader(jfc.getSelectedFile()));
                    String data;
                    int i = 1;
                    while ((data = br.readLine()) != null) {
                        program.getProblem().getSentences().add(new Sentence(new String(data), i));
                        text += "\nRead(" + i + ")" + (new String(data));
                        i++;
                    }
                }
            } catch (IOException ex) {
                tp.setForeground(Color.RED);
                text += ex.getMessage();
            }
            tp.setForeground(new Color(Color.HSBtoRGB(0.4521222f, 0.1970f, 0.98234567f)));
            tp.setText(text);
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Button-Pane-ChangeProblemSize"))) {
            String text = tp.getText();
            text += ("\n\nChange Problem Size\n=======================\n");
            String v = JOptionPane.showInputDialog("Enter the size of counting problem:", "Format=001 to 999");
            program.getProblem().setProblemSize(Integer.valueOf(v));
            text += "The size of counting problem:" + v;
            tp.setForeground(new Color(Color.HSBtoRGB(0.7521222f, 0.1970f, 0.981234567f)));
            tp.setText(text);
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Button-Pane-SentenceEntry"))) {
            String text = tp.getText();
            text += ("\n====================================\n");
            program.getProblem().clearMPSentinels();
            text += ("CP Sentences");

            for (int i = 0; i < program.getProblem().getProblemSize(); i++) {
                String sentence = JOptionPane.showInputDialog("Enter your sentence[" + (i + 1) + "] for counting", "max:27 letters");
                program.getProblem().getSentences().add(new Sentence(sentence.trim(), i + 1));
                text += ("\nSentence[" + i + "]:") + sentence;
            }
            tp.setForeground(new Color(Color.HSBtoRGB(0.332345678f, 0.708090f, 0.91234567f)));
            tp.setText(text);
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Button-Pane-LCTable"))) {
            String text = tp.getText();
            text += ("\n\nLCTable Columns View");
            text += ("\nIndex  Position  Size         Word");
            text += ("\n==========================================");
            problem = program.getProblem();
            for (int k = 0; k < problem.getSentences().size(); k++) {
                Sentence s = problem.getSentences().get(k);
                for (int l = 0; l < s.getAlphaLabels().size(); l++) {
                    AlphaLabel al = s.getAlphaLabels().get(l);
                    text += "\n" + (al.toString());
                }
            }
            tp.setForeground(new Color(Color.HSBtoRGB(0.523987f, 0.190070f, 0.9246867f)));
            tp.setText(text);
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Button-Pane-PartitionRow"))) {
            String text = tp.getText();
            text += ("\n\nPartition of Integers");
            text += ("\n==========================================");
            text += ("");
            String value = JOptionPane.showInputDialog("Enter the reduce value of partition of integers", "0 to 9");
            String value1 = JOptionPane.showInputDialog("Enter the partition type Values:\n(1)MP partition\n(2)MPSet partition\n(3)RMPSet partition\n(4)LMPSet partition", "0-4");
            text += ("\n");
            HashMap<Integer, String> parts = program.partitionInteger(Integer.valueOf(value), Integer.valueOf(value1));
            Set<Integer> keys = parts.keySet();
            for (int p = 0; p < parts.keySet().size(); p++) {

                Integer va = (Integer) keys.toArray()[p];
                text += ("\n######################");
                text += ("\nPartition of " + va);
                text += ("\n######################");
                text += "\n" + (parts.get(va));
                text += ("\n");
            }
            tp.setForeground(new Color(Color.HSBtoRGB(0.1521222f, 0.1970f, 0.91234567f)));
            tp.setText(text);
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Button-Pane-Equality"))) {
            String text = tp.getText();
            text += ("\n\n    Equality Principles");
            text += ("\n===========================");
            String value = JOptionPane.showInputDialog("Enter the [set1,set2] of sets\n\nSet Values:\n(1)MP partition\n(2)MPSet partition\n(3)RMPSet partition\n(4)LMPSet partition\n(Enter values[Format:1,2])>>>");
            String[] sp = value.split(",");
            int v = Integer.valueOf(sp[0]);
            int tye = Integer.valueOf(sp[1]);

            String[] type = {"MP", "MPSet", "RMPSet", "LMPSet"};
            text += ("\n");
            text += ("\nCount Equality Principle Value(" + type[v - 1] + ":" + type[tye - 1] + "):=" + program.getEqualityPrincpleCV(v, tye));
            text += ("\nEquality Principle Value(" + type[v - 1] + ":" + type[tye - 1] + "):=" + program.getEqualityPrincpleValues(v, tye));

            tp.setForeground(new Color(Color.HSBtoRGB(0.1521222f, 0.1970f, 0.831234567f)));
            tp.setText(text);
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Button-Pane-Ferrers"))) {
            String text = tp.getText();
            text += ("\n\nFerrers Diagram: Dot Display");
            text += ("\n==============================");
            String pardiaSize = JOptionPane.showInputDialog("Enter the type of sets\n\nSet Values:\n(1)MP partition\n(2)MPSet partition\n(3)RMPSet partition\n(4)LMPSet partition\n(Enter value)>>>");
            int diaval = Integer.valueOf(pardiaSize);

            String[] typeSet = {"MP", "MPSet", "RMPSet", "LMPSet"};
            text += ("\nPartition Set:= " + typeSet[diaval - 1]);

            text += ("\n");
            tp.setForeground(new Color(Color.HSBtoRGB(0.1521222f, 0.1970f, 0.91234567f)));
            tp.setText(text);
            showferrersdiagram(diaval);
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Button-Pane-CombInfo"))) {
            String text = tp.getText();
            text += ("\n\nBasic Combinatorial Information (n,r)");
            text += ("\n==========================================");
            String s = JOptionPane.showInputDialog("\nEnter the type of sets\n\nSet Values:\n(1)MP partition\n(2)MPSet partition\n(3)RMPSet partition\n(4)LMPSet partition\n(Enter value)>>>", "1-4");


            int rpmSetValue = Integer.valueOf(s);

            text += ("\n");
            String[] typeSet = {"MP", "MPSet", "RMPSet", "LMPSet"};
            text += ("\nPartition Set(" + typeSet[rpmSetValue - 1] + ")\n#####################");
            text += ("\nPermutation-1 Word Arrangement:=");
            List<Long> p1 = program.rpermuteList(rpmSetValue);
            text += "\n" + (p1.toString());
            text += ("\nPermutation-2 of Word Arrangements:=");

            List<Integer> p2 = program.rpermute2List(rpmSetValue);
            text += "\n" + (p2.toString());
            int count = 0;
            for (int l = 0; l < p2.size(); l++) {
                if (p2.get(l) == 2139095040) {
                    count += 1;
                }
            }
            if (count > (p2.size() / 3)) {
                text += ("\nProblem permutation-2 is an infinite count process.");
            }
            text += ("\nCombination-1 of Word Selection:=");
            List<Long> cwm = program.rcombinantList(rpmSetValue);
            text += "\n" + (cwm.toString());
            text += ("\nCombination-2 of Word Selection:=");
            List<Integer> cwm2 = program.rcombinant2List(rpmSetValue);
            text += "\n" + (cwm2.toString());
            tp.setForeground(new Color(Color.HSBtoRGB(0.1529812f, 0.1970f, 0.9213111f)));
            tp.setText(text);
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Button-Pane-CorrInfo"))) {
            String text = tp.getText();
            text += ("\n\nOne-to-One Correspondence Information");
            text += ("\n========================================");
            text += ("\nINFO: After digit 9 is a double digit value.");
            text += ("\nLetter(s)------>Digit(s)\n");
            tp.setForeground(new Color(Color.HSBtoRGB(0.1521222f, 0.1979f, 0.91234567f)));
            tp.setText(text);
            problem = program.getProblem();
            OnetoOneCorrespondence(problem);
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Button-Pane-NoOrders"))) {
            String text = tp.getText();
            text += ("\n\n  Possible Number of Orders(PO) ");
            text += ("\n==================================");
            String[] typeSet = {"MP", "MPSet", "RMPSet", "LMPSet"};
            List<String> po = program.orderList();
            text += "\n" + (po.toString());
            tp.setForeground(new Color(Color.HSBtoRGB(0.1521222f, 0.1970f, 0.91234567f)));
            tp.setText(text);
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Button-Pane-Pascal"))) {
            String text = tp.getText();
            text += ("\n\n     Pascal Triangles");
            text += ("\n==============================");
            String value = JOptionPane.showInputDialog("Enter the [reduce-by,type] of partition of integers\n(Reduce-by Values=0 to 9)\nType Values:\n(1)MP partition\n(2)MPSet partition\n(3)RMPSet partition\n(4)LMPSet partition\n(Enter values[Format:1,2])>>>");
            String[] sp = value.split(",");
            int pascval = Integer.valueOf(sp[0]);
            int pascaltye = Integer.valueOf(sp[1]);
            text += ("\n");
            HashMap<Integer, String> parts = program.pascalTriangle(pascval, pascaltye);
            Set<Integer> keys = parts.keySet();
            for (int p = 0; p < parts.keySet().size(); p++) {

                Integer va = (Integer) keys.toArray()[p];
                text += ("\n##########################");
                text += ("\nPascal Triangle of " + va);
                text += ("\n##########################");
                text += "\n" + (parts.get(va));
                text += ("\n");
            }
            tp.setForeground(new Color(Color.HSBtoRGB(0.7521222f, 0.1979f, 0.9567f)));
            tp.setText(text);
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Moon-Sun-Go-Problem"))) {
            program.getProblem().clearMPSentinels();
            program.getProblem().setProblemSize(6);
            Random r = new Random();
            if (r.nextInt(3) == 1) {
                program.getProblem().addSentence(new Sentence("Go away", 1));
            } else if (r.nextInt(2) == 2) {
                program.getProblem().addSentence(new Sentence("Go moon", 1));
            } else {
                program.getProblem().addSentence(new Sentence("A sun go", 1));
            }
            program.getProblem().addSentence(new Sentence("Go away moon", 2));
            program.getProblem().addSentence(new Sentence("Go away moon-sun", 3));
            program.getProblem().addSentence(new Sentence("The sun is go away thing", 4));
            program.getProblem().addSentence(new Sentence("The moon is go away thing", 5));

            if (r.nextInt(4) == 1) {
                program.getProblem().addSentence(new Sentence("The sun and moon goes upto the sky", 6));
            } else if (r.nextInt(3) == 2) {
                program.getProblem().addSentence(new Sentence("The sun and moon go upto the skies", 6));
            } else if (r.nextInt(3) == 3) {
                program.getProblem().addSentence(new Sentence("A sun and moon gone upto the skies", 6));
            } else {
                program.getProblem().addSentence(new Sentence("Sun and moon gone upto the clouds", 6));
            }

            tp.setText(tp.getText() + "\nMoon-Sun-Go Problem(MSGP) is build into the sentence system!!!!\nThere are possible solutions in nature too.\n");
            problem = program.getProblem();
            tp.setText(tp.getText() + "\n" + problem.getSentences());
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Family-Vision-Problem"))) {
            program.getProblem().clearMPSentinels();
            program.getProblem().setProblemSize(6);

            program.getProblem().addSentence(new Sentence("At home", 1));
            program.getProblem().addSentence(new Sentence("We are close", 2));
            program.getProblem().addSentence(new Sentence("We live in a house", 3));
            program.getProblem().addSentence(new Sentence("We are family business", 4));
            program.getProblem().addSentence(new Sentence("It has family set in home", 5));
            program.getProblem().addSentence(new Sentence("We have family computer in a home", 6));

            tp.setText(tp.getText() + "\nFamily-Vision Problem(FVP) is build into the sentence system!!!!\nThere are possible solutions in family too.\n");
            problem = program.getProblem();
            tp.setText(tp.getText() + "\n" + problem.getSentences());
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Hand-Wall-Problem"))) {
            program.getProblem().clearMPSentinels();
            program.getProblem().setProblemSize(6);

            program.getProblem().addSentence(new Sentence("At wall", 1));
            program.getProblem().addSentence(new Sentence("Hand at wall", 2));
            program.getProblem().addSentence(new Sentence("I want touch wall", 3));
            program.getProblem().addSentence(new Sentence("We do touch wall by hand", 4));
            program.getProblem().addSentence(new Sentence("Do not want to touch wall", 5));
            program.getProblem().addSentence(new Sentence("At top of a wall and I can not touch", 6));

            tp.setText(tp.getText() + "\nHand-Wall-Problem(HWP) is build into the sentence system!!!!\nThere are possible solutions in hand-wall interaction too.\n");
            problem = program.getProblem();
            tp.setText(tp.getText() + "\n" + problem.getSentences());
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "School-Sing-Problem"))) {
            program.getProblem().clearMPSentinels();
            program.getProblem().setProblemSize(6);

            program.getProblem().addSentence(new Sentence("He song", 1));
            program.getProblem().addSentence(new Sentence("School song", 2));
            program.getProblem().addSentence(new Sentence("Sing school song", 3));
            program.getProblem().addSentence(new Sentence("I do sing song at school", 4));
            program.getProblem().addSentence(new Sentence("We do sing song at school", 5));
            program.getProblem().addSentence(new Sentence("There is no school without a song", 6));

            tp.setText(tp.getText() + "\nSchool-Sing-Problem(SSP) is build into the sentence system!!!!\nThere are possible solutions in SCHOOL too.\n");
            problem = program.getProblem();
            tp.setText(tp.getText() + "\n" + problem.getSentences());
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Love-Dear-Problem"))) {
            program.getProblem().clearMPSentinels();
            program.getProblem().setProblemSize(6);

            program.getProblem().addSentence(new Sentence("Love me", 1));
            program.getProblem().addSentence(new Sentence("I do love you", 2));
            program.getProblem().addSentence(new Sentence("Will love me back", 3));
            program.getProblem().addSentence(new Sentence("Will be your lover dear", 4));
            program.getProblem().addSentence(new Sentence("Will always love me back", 5));
            program.getProblem().addSentence(new Sentence("I will be your lover believe in me", 6));

            tp.setText(tp.getText() + "\nLove-Dear-Problem(LDP) is build into the sentence system!!!!\nThere are possible solutions in intercourse too.\n");
            problem = program.getProblem();
            tp.setText(tp.getText() + "\n" + problem.getSentences());
        } else if (actionCom.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "Appiah-Test"))) {
            List<Integer> lmpset = program.LMPSetOrder();
            if (lmpset.size() >= 6) {
                testSet(0);
            } else if (lmpset.size() == 5) {
                testSet(1);
            } else if (lmpset.size() == 4) {
                testSet(2);
            }
            tp.setForeground(new Color(Color.HSBtoRGB(0.521222f, 0.88972f, 0.74567f)));
        } else {
            program.getProblem().clearMPSentinels();
            program.getProblem().setProblemSize(5);
            program.MPSentences();
            tp.setForeground(new Color(Color.HSBtoRGB(0.6521222f, 0.1972f, 0.94567f)));
            tp.setText("");
        }
    }

    private void testSet(int leng) {
        int[] appiahtestset = {6, 10, 14, 19, 20, 27};
        boolean[] member = {Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE};
        List<Integer> lmpset = program.LMPSetOrder();
        int count = 0;
        String text = tp.getText();
        for (int i = 0; i < appiahtestset.length - leng; i++) {
            if (lmpset.contains(appiahtestset[i])) {
                count++;
                member[i] = Boolean.TRUE;
            }
        }
        text += ("\n\n         Appiah Test\n");
        text += ("==============================\n");
        text += ("Member Value        Complete Info\n");
        text += ("==============================\n");
        text += (appiahtestset[0] + "                             " + member[0] + "\n");
        text += (appiahtestset[1] + "                           " + member[1] + "\n");
        text += (appiahtestset[2] + "                           " + member[2] + "\n");
        text += (appiahtestset[3] + "                           " + member[3] + "\n");
        text += (appiahtestset[4] + "                           " + member[4] + "\n");
        text += (appiahtestset[5] + "                           " + member[5] + "\n");
        text += ("=============================\n");
        text += ("Test Count:=" + count + "\n");
        problem = program.getProblem();
        for (int i = 0; i < program.getProblem().getProblemSize(); i++) {
            text += "\nSentence Structure " + "::" + problem.getSentences().get(i).toString();
        }
        text += "\n";
        if (count == 6) {
            boolean test = member[0] & member[1] & member[2] & member[3] & member[4] & member[5];
            if (test) {
                text += "Appiah Test is complete with sentence information.\n";
            } else {
                text += "Appiah Test is not complete.\n";
            }
        } else if (count == 5) {
            boolean test = member[0] & member[1] & member[2] & member[3] & member[4];
            if (test) {
                text += "Appiah Test is complete with sentence information.\n";
            } else {
                text += "Appiah Test is not complete.\n";
            }
        } else if (count == 4) {
            boolean test = member[0] & member[1] & member[2] & member[3];
            if (test) {
                text += "Appiah Test is complete with sentence information.\n";
            } else {
                text += "Appiah Test is not complete.\n";
            }
        }
        tp.setText(text);
    }

    private void OnetoOneCorrespondence(ILCProblem problem) {
        String text = tp.getText();
        ArrayList<Sentence> sentences = problem.getSentences();
        for (int i = 0; i < problem.getProblemSize(); i++) {
            Sentence s = sentences.get(i);
            String sizes = "";
            text += ("\nSentence MP(" + (i + 1) + "):");
            List<IAlphanumeric> als = s.getAlphanumeric();
            for (int k = 0; k < als.size(); k++) {
                IAlphanumeric ia = als.get(k);
                text += (ia.getLetter());
                sizes += ia.getSize();
            }
            text += ("--------->");
            text += (sizes);
            text += ("");
        }
        tp.setText(text);
    }

    private void showferrersdiagram(int type) {
        Random r = new Random(5);
        int rand = r.nextInt(5);
        String text = tp.getText();
        text += ("\n\nPartition Random Reducer:=" + rand);
        HashMap<Integer, String> parts = program.partitionInteger(rand, type);
        text += ("\nPartition Size:" + parts.size());
        Integer[] kvalues = getSetIntegers(type);
        String[] disp = {"$", "O", "o", ".", "x", "#"};
        for (int i = 0; i <
                kvalues.length; i++) {
            String spartint = parts.get(kvalues[i]);
            text += ("\n\n##################\nPartition of " + kvalues[i] + "\n##################");
            String[] partsint = spartint.split("\n");
            for (int k = 0; k <
                    partsint.length; k++) {
                text += ("\nPartition of Integers: " + partsint[k]);
                String partvalue = partsint[k];
                partvalue =
                        partvalue.trim();

                if (k > 0) {
                    text += ("\n$$Dot Partition: Conjugate Ferrers Diagram$$\n");
                } else {
                    text += ("\n$$Dot Partition$$\n");
                }

                text += ("\n------------------------\n");
                StringTokenizer tokenizer = new StringTokenizer(partvalue);
                while (tokenizer.hasMoreElements()) {
                    String partok = tokenizer.nextToken();
                    if (!partok.equalsIgnoreCase("+")) {
                        Integer dotcount = Integer.valueOf(partok);
                        for (int m = 0; m <
                                dotcount; m++) {
                            text += ("" + disp[rand] + "");
                        }
                    }
                    text += ("\n");
                }
                text += ("\n------------------------");
                text += ("");
            }
        }
        tp.setText(text);
    }

    private Integer[] getSetIntegers(int settype) {

        switch (settype) {
            case 1:
                return program.MPOrder().toArray(new Integer[0]);
            case 2:
                return program.MPSetOrder().toArray(new Integer[0]);
            case 3:
                return program.RMPSetOrder().toArray(new Integer[0]);
            case 4:
                return program.LMPSetOrder().toArray(new Integer[0]);
        }
        return null;
    }

    public void stateChanged(ChangeEvent e) {

    }

    public void mouseClicked(MouseEvent e) {

    }

    public void mousePressed(MouseEvent e) {

    }

    public void mouseReleased(MouseEvent e) {

    }

    public void mouseEntered(MouseEvent e) {

    }

    public void mouseExited(MouseEvent e) {

    }

    public void keyTyped(KeyEvent e) {

    }

    public void keyPressed(KeyEvent e) {

    }

    public void keyReleased(KeyEvent e) {

    }

    protected void componentClosed() {
        super.componentClosed();
        tcCount--;
    }

    public void popupMenuWillBecomeVisible(PopupMenuEvent e) {

    }

    public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void popupMenuCanceled(PopupMenuEvent e) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void menuKeyTyped(MenuKeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void menuKeyPressed(MenuKeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void menuKeyReleased(MenuKeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
