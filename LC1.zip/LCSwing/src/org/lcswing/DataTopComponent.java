package org.lcswing;

import com.sun.java.swing.plaf.motif.MotifLookAndFeel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import org.openide.util.Exceptions;
import org.openide.util.NbBundle;
import org.openide.windows.TopComponent;

/**
 *
 * @author appiah
 */
public class DataTopComponent extends TopComponent implements ActionListener {

    private DataViewComponent view = null;

    public DataTopComponent() {
        try {

            setLayout(new BorderLayout(10, 10));
            setName(NbBundle.getMessage(LCTopComponent.class, "CTL_DataViewAction"));
            setDisplayName(NbBundle.getMessage(LCTopComponent.class, "CTL_DataViewAction"));
            add(createPopmenu(), BorderLayout.WEST);

            JScrollPane imagepane = new JScrollPane(createTDImages(), JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            add(imagepane, BorderLayout.CENTER);
            UIManager.setLookAndFeel(new MotifLookAndFeel());
        } catch (UnsupportedLookAndFeelException ex) {
            Exceptions.printStackTrace(ex);
        }
    }

    public DataTopComponent(JPanel panel) {

        setLayout(new BorderLayout(10, 10));
        setName(NbBundle.getMessage(LCTopComponent.class, "CTL_DataViewAction"));
        setDisplayName(NbBundle.getMessage(LCTopComponent.class, "CTL_DataViewAction"));
        add(createPopmenu(), BorderLayout.WEST);

        JScrollPane imagepane = new JScrollPane(panel, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        add(imagepane, BorderLayout.CENTER);
    }

    private JPopupMenu createPopmenu() {

        
        JPopupMenu menu = new JPopupMenu("Data View Menu");
        ImageIcon icn = new ImageIcon(this.getClass().getResource("images/diadat.png"));
        JMenuItem item = new JMenuItem(NbBundle.getMessage(LCTopComponent.class, "CTL_DataOrthoViewAction"), icn);
        item.setMnemonic(KeyEvent.VK_O);
        item.setActionCommand(NbBundle.getMessage(LCTopComponent.class, "CTL_DataOrthoViewAction"));
        item.addActionListener(this);
        item.setBackground(new Color(Color.HSBtoRGB(0.692002f, 0.998112f, 1.0f)));
        menu.add(item);
        item = new JMenuItem(NbBundle.getMessage(LCTopComponent.class, "CTL_DataSymmViewAction"), icn);
        item.setMnemonic(KeyEvent.VK_S);
        item.setActionCommand(NbBundle.getMessage(LCTopComponent.class, "CTL_DataSymmViewAction"));
        item.addActionListener(this);
        item.setBackground(new Color(Color.HSBtoRGB(0.92002f, 0.8888112f, 1.0f)));
        menu.add(item);
        item = new JMenuItem(NbBundle.getMessage(LCTopComponent.class, "CTL_DataIncViewAction"), icn);
        item.setMnemonic(KeyEvent.VK_I);
        item.setActionCommand(NbBundle.getMessage(LCTopComponent.class, "CTL_DataIncViewAction"));
        item.addActionListener(this);
        item.setBackground(new Color(Color.HSBtoRGB(0.32002f, 0.879992f, 0.98880f)));
        menu.add(item);
        item = new JMenuItem(NbBundle.getMessage(LCTopComponent.class, "CTL_DataHierViewAction"), icn);
        item.setMnemonic(KeyEvent.VK_H);
        item.setActionCommand(NbBundle.getMessage(LCTopComponent.class, "CTL_DataHierViewAction"));
        item.addActionListener(this);
        item.setBackground(new Color(Color.HSBtoRGB(0.4552002f, 0.668112f, 1.0f)));
        menu.add(item);
        menu.setVisible(true);
        return menu;
    }

    public JPanel createTDImages() {
        JPanel pane = new JPanel(new GridLayout(4, 1, 15, 10));

        int w = 300, h = 200;

        JLabel labelcen = new JLabel("Symmetrical Diagram", SwingConstants.CENTER);
        ImageIcon icon = new ImageIcon(this.getClass().getResource("images/LCDD-symlay.jpg"));
        labelcen.setIcon(new ImageIcon(icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH)));
        pane.add(labelcen);
        
        labelcen = new JLabel("Incremental Diagram", SwingConstants.CENTER);
        icon = new ImageIcon(this.getClass().getResource("images/LCDD-increlay.jpg"));

        labelcen.setIcon(new ImageIcon(icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH)));
        pane.add(labelcen);
        labelcen = new JLabel("Hierarchical Diagram", SwingConstants.CENTER);
        icon = new ImageIcon(this.getClass().getResource("images/LCDD-hielay.jpg"));
        labelcen.setIcon(new ImageIcon(icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH)));

        pane.add(labelcen);
        labelcen = new JLabel("Orthogonal Diagram", SwingConstants.CENTER);
        icon = new ImageIcon(this.getClass().getResource("images/LCDDia.jpg"));
        labelcen.setIcon(new ImageIcon(icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH)));
        pane.add(labelcen);

        return pane;
    }

    @Override
    public int getPersistenceType() {
        return PERSISTENCE_NEVER;
    }

    public void actionPerformed(ActionEvent e) {
       String action = e.getActionCommand();
        if (action.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "CTL_DataSymmViewAction"))) {
            if (view != null) {
                view.close();
            }
            view = new DataViewComponent(1);
            view.setName(NbBundle.getMessage(LCTopComponent.class, "CTL_DataSymmViewAction"));
            view.setDisplayName(NbBundle.getMessage(LCTopComponent.class, "CTL_DataSymmViewAction"));
            view.open();
            view.requestActive();
        } else if (action.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "CTL_DataOrthoViewAction"))) {
            if (view != null) {
                view.close();
            }
            view = new DataViewComponent(0);
            view.setName(NbBundle.getMessage(LCTopComponent.class, "CTL_DataOrthoViewAction"));
            view.setDisplayName(NbBundle.getMessage(LCTopComponent.class, "CTL_DataOrthoViewAction"));
            view.open();
            view.requestActive();
        } else if (action.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "CTL_DataHierViewAction"))) {
            if (view != null) {
                view.close();
            }
            view = new DataViewComponent(2);
            view.setName(NbBundle.getMessage(LCTopComponent.class, "CTL_DataHierViewAction"));
            view.setDisplayName(NbBundle.getMessage(LCTopComponent.class, "CTL_DataHierViewAction"));
            view.open();
            view.requestActive();
        } else if (action.equalsIgnoreCase(NbBundle.getMessage(LCTopComponent.class, "CTL_DataIncViewAction"))) {
            if (view != null) {
                view.close();
            }
            view = new DataViewComponent(3);
            view.setName(NbBundle.getMessage(LCTopComponent.class, "CTL_DataIncViewAction"));
            view.setDisplayName(NbBundle.getMessage(LCTopComponent.class, "CTL_DataIncViewAction"));
            view.open();
            view.requestActive();
        }
    }
    
}
