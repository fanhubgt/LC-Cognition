package lcprogram;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import static java.lang.System.out;
import static java.lang.System.in;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Main execution program for LC.
 * 
 * @author appiah
 */
public class LCMainSystem {

    static LCProgram program = new LCProgram();
    static ILCProblem problem = program.getProblem();

    public static void main(String[] args) {
        try {
            boolean boolsentinel = true;
            if (boolsentinel) {
                program.MPSentences();
            }
            byte[] menu = new byte[2];//size=99 (2 digits, 10^2-1values) for integers.
            while (true) {
                out.println("\nSelect an item from menu(00: Menu Items)>>>");
                int value = 1;
                try {
                    int v = in.read(menu);
                    String s = new String(menu);
                    value = Integer.valueOf(s);
                } catch (NumberFormatException e) {
                    int v = in.read(menu);
                    String s = new String(menu);
                    value = Integer.valueOf(s);
                }
                out.println("\n");
                switch (value) {
                    case 0:
                        LCmenu();
                        continue;
                    case 1:
                        out.println("Problem Size Information\n=======================\n");
                        out.println("Problem size:" + problem.getProblemSize());
                        continue;
                    case 2:
                        out.println("Sentence Information\n==========================\n");
                        for (int i = 0; i < program.getProblem().getProblemSize(); i++) {
                            out.println("LCP Sentence " + (i + 1) + ":" + problem.getSentences().get(i).toString());
                        }
                        continue;
                    case 3:
                        out.println("MP(Set) Principle Values\n=============================\n");
                        out.println("Addition Principle Value(MP):=" + program.add());
                        out.println("Substraction Principle Value(MP):=" + program.substract());
                        out.println("Multiplication Principle Value(MP):=" + program.multiply());
                        out.println("Addition Principle Value(MPSet):=" + program.addMPSet());
                        out.println("Substraction Principle Value(MPSet):=" + program.subMPSet());
                        out.println("Multiplication Principle Value(MPSet):=" + program.mulMPSet());
                        continue;
                    case 4:
                        out.println("Alpha Sizes Information\n===========================\n");
                        for (int i = 0; i < program.getProblem().getProblemSize(); i++) {
                            out.println("(" + (1 + i) + ") Alpha size:" + problem.getSentences().get(i).getAlphaLabels().size());
                        }
                        continue;
                    case 5:
                        out.println("Partition of Integers\n=============================\n");
                        out.println(program.partition().toString());
                        continue;
                    case 6:
                        out.println("Count Method Information\n==============================\n");
                        for (int i = 0; i < program.getProblem().getProblemSize(); i++) {
                            out.println("Count MP(" + (1 + i) + "):" + problem.getSentences().get(i).getCount());
                        }
                        continue;
                    case 7:
                        out.println("Alpha-Label Information\n======================================\n");
                        for (int i = 0; i < program.getProblem().getProblemSize(); i++) {
                            ArrayList<AlphaLabel> labs = problem.getSentences().get(i).getAlphaLabels();
                            out.print("Alphalabel " + (i + 1) + ":[");
                            String words = "";
                            for (int k = 0; k < labs.size(); k++) {
                                words += labs.get(k).getWord() + ", ";
                            }
                            words = words.substring(0, words.length() - 2);
                            out.print(words.trim() + "]");
                            out.println("");
                        }
                        continue;
                    case 8:
                        out.println("MP Sets Information\n===============================\n");
                        out.println("MP:=" + program.MPOrder());
                        out.println("MPset:=" + program.MPSetOrder());
                        out.println("RMPset:=" + program.RMPSetOrder());
                        out.println("LMPset:=" + program.LMPSetOrder());
                        continue;
                    case 9:
                        out.println("Principle Values for RMPSet\n======================================\n");
                        out.println("Addition Principle Value(RMPSet):=" + program.addRMP());
                        out.println("Substraction Principle Value(RMPSet):=" + program.subRMP());
                        out.println("Multiplication Principle Value(RMPSet):=" + program.mulRMP());
                        continue;
                    case 10:
                         {
                            out.println("Alphanumerics Information\n=======================================\n");
                            program.getProblem().clearMPSentinels();
                            program.MPSentences();
                            LCalphanumerics(program.getProblem());
                        }
                        continue;
                    case 11:
                        out.println("Meta-sentential Operations\n====================================\n");
                        program.metaSententialOperation();
                        out.println(program.getOperations());
                        continue;
                    case 12:
                        out.println("Principle values for LMPSet\n==================================\n");
                        out.println("Addition Principle Value(LMPSet):=" + program.addLMP());
                        out.println("Substraction Principle Value(LMPSet):=" + program.subLMP());
                        out.println("Multiplication Principle Value(LMPSet):=" + program.mulLMP());
                        continue;
                    case 13:
                        out.print("File Sentence Stream\n=======================\n");
                        readFileSentence(problem);
                        continue;
                    case 14:
                        out.print("Change Problem Size\n=======================\n");
                        out.print("Enter the size of counting problem(Format=001 to 999):");
                        byte[] size = new byte[3];
                        try {
                            int v = in.read(size);
                            String s = new String(size);
                            v = Integer.valueOf(s);
                            program.getProblem().setProblemSize(v);
                        } catch (NumberFormatException e) {
                            int v = in.read(size);
                            String s = new String(size);
                            v = Integer.valueOf(s);
                            program.getProblem().setProblemSize(v);
                        }
                        continue;
                    case 15:
                        out.print("Key-Input Problems Entry. \nChange the problem size (Item:14) if it is necessary.\nDefault is 5." +
                                "\n========================================================\n");

                        problem.clearMPSentinels();
                        out.println("CP Sentences");
                        try {
                            for (int i = 0; i < program.getProblem().getProblemSize() + 1; i++) {
                                constraintMP1(problem, boolsentinel, i);
                            }

                        } catch (Exception e) {
                            for (int i = 0; i < program.getProblem().getProblemSize(); i++) {
                                constraintMP1(problem, boolsentinel, i);
                            }
                        }
                        program.getProblem().getSentences().remove(0);
                        continue;
                    case 16:
                        out.println("LCTable Columns View");
                        out.println("Index      Position      Size        Word");
                        out.println("==========================================");

                        for (int k = 0; k < problem.getSentences().size(); k++) {
                            Sentence s = problem.getSentences().get(k);
                            for (int l = 0; l < s.getAlphaLabels().size(); l++) {
                                AlphaLabel al = s.getAlphaLabels().get(l);
                                out.println(al);
                            }
                        }
                        continue;
                    case 17: {
                        out.println("Partition of Integers");
                        out.println("==========================================");
                        out.print("Enter the [reduce,type] of partition of integers\n(Reduce Values=0 to 9)\nType Values:\n(1)MP partition\n(2)MPSet partition\n(3)RMPSet partition\n(4)LMPSet partition\n(Enter values[Format:1,2])>>>");
                        byte[] parSize = new byte[3];
                        int v = 1;
                        int tye = 1;
                        try {
                            v = in.read(parSize);
                            String s = new String(parSize);
                            String[] sp = s.split(",");
                            v = Integer.valueOf(sp[0]);
                            tye = Integer.valueOf(sp[1]);
                        } catch (NumberFormatException e) {
                            v = in.read(parSize);
                            String s = new String(parSize);
                            String[] sp = s.split(",");
                            v = Integer.valueOf(sp[0]);
                            tye = Integer.valueOf(sp[1]);
                        }
                        out.print("\n");
                        HashMap<Integer, String> parts = program.partitionInteger(v, tye);
                        Set<Integer> keys = parts.keySet();
                        for (int p = 0; p < parts.keySet().size(); p++) {

                            Integer va = (Integer) keys.toArray()[p];
                            out.println("######################");
                            out.println("Partition of " + va);
                            out.println("######################");
                            out.println(parts.get(va));
                            out.print("\n");
                        }
                        out.println();
                        continue;
                    }
                    case 18:
                        out.println("    Equality Principles");
                        out.println("===========================");
                        out.print("Enter the [set1,set2] of sets\n\nSet Values:\n(1)MP partition\n(2)MPSet partition\n(3)RMPSet partition\n(4)LMPSet partition\n(Enter values[Format:1,2])>>>");
                        byte[] parSize = new byte[3];
                        int v = 1;
                        int tye = 1;
                        try {
                            v = in.read(parSize);
                            String s = new String(parSize);
                            String[] sp = s.split(",");
                            v = Integer.valueOf(sp[0]);
                            tye = Integer.valueOf(sp[1]);
                        } catch (NumberFormatException e) {
                            v = in.read(parSize);
                            String s = new String(parSize);
                            String[] sp = s.split(",");
                            v = Integer.valueOf(sp[0]);
                            tye = Integer.valueOf(sp[1]);
                        }
                        String[] type = {"MP", "MPSet", "RMPSet", "LMPSet"};
                        out.print("\n");
                        out.println("Count Equality Principle Value(" + type[v - 1] + ":" + type[tye - 1] + "):=" + program.getEqualityPrincpleCV(v, tye));
                        out.println("Equality Principle Value(" + type[v - 1] + ":" + type[tye - 1] + "):=" + program.getEqualityPrincpleValues(v, tye));
                        continue;
                    case 19:
                         {
                            out.println("Ferrers Diagram: Dot Display");
                            out.println("==============================");
                            out.print("Enter the type of sets\n\nSet Values:\n(1)MP partition\n(2)MPSet partition\n(3)RMPSet partition\n(4)LMPSet partition\n(Enter value)>>>");
                            byte[] pardiaSize = new byte[1];
                            int diaval = 1;

                            try {
                                diaval = in.read(pardiaSize);
                                String s = new String(pardiaSize);
                                diaval = Integer.valueOf(s);

                            } catch (NumberFormatException e) {
                                diaval = in.read(pardiaSize);
                                String s = new String(pardiaSize);
                                diaval = Integer.valueOf(s);
                            }
                            String[] typeSet = {"MP", "MPSet", "RMPSet", "LMPSet"};
                            out.println("Partition Set:= " + typeSet[diaval - 1]);

                            out.print("\n");
                            program.ferrersdiagram(diaval);
                        }
                        continue;
                    case 20:
                         {
                            out.println("Basic Combinatorial Information (n,r)");
                            out.println("==========================================");
                            out.print("Enter the type of sets\n\nSet Values:\n(1)MP partition\n(2)MPSet partition\n(3)RMPSet partition\n(4)LMPSet partition\n(Enter value)>>>");
                            byte[] rpmSize = new byte[1];
                            int rpmSetValue = 1;

                            try {
                                rpmSetValue = in.read(rpmSize);
                                String s = new String(rpmSize);
                                rpmSetValue = Integer.valueOf(s);

                            } catch (NumberFormatException e) {
                                rpmSetValue = in.read(rpmSize);
                                String s = new String(rpmSize);
                                rpmSetValue = Integer.valueOf(s);
                            }
                            out.print("\n");
                            String[] typeSet = {"MP", "MPSet", "RMPSet", "LMPSet"};
                            out.println("Partition Set(" + typeSet[rpmSetValue - 1] + ")\n#####################");
                            out.println("Permutation-1 Word Arrangement:=");
                            List<Long> p1 = program.rpermuteList(rpmSetValue);
                            out.println(p1);
                            out.println("Permutation-2 of Word Arrangements:=");

                            List<Integer> p2 = program.rpermute2List(rpmSetValue);
                            out.println(p2);
                            int count = 0;
                            for (int l = 0; l < p2.size(); l++) {
                                if (p2.get(l) == 2139095040) {
                                    count += 1;
                                }
                            }
                            if (count > (p2.size() / 3)) {
                                out.println("Problem permutation-2 is an infinite count process.");
                            }
                            out.println("Combination-1 of Word Selection:=");
                            List<Long> cwm = program.rcombinantList(rpmSetValue);
                            out.println(cwm);
                            out.println("Combination-2 of Word Selection:=");
                            List<Integer> cwm2 = program.rcombinant2List(rpmSetValue);
                            out.println(cwm2);
                        }
                        continue;
                    case 21:
                        out.println("One-to-One Correspondence Information");
                        out.println("========================================");
                        out.println("INFO: After digit 9 is a double digit value.");
                        out.println("Letter(s)------>Digit(s)\n");
                        OnetoOneCorrespondence(program.getProblem());
                        continue;
                    case 22:
                        out.println("  Possible Number of Orders(PO) ");
                        out.println("==================================");
                        String[] typeSet = {"MP", "MPSet", "RMPSet", "LMPSet"};
                        List<String> po = program.orderList();
                        out.println(po);
                        continue;
                    case 23:
                         {
                            out.println("     Pascal Triangles");
                            out.println("==============================");
                            out.print("Enter the [reduce-by,type] of partition of integers\n(Reduce-by Values=0 to 9)\nType Values:\n(1)MP partition\n(2)MPSet partition\n(3)RMPSet partition\n(4)LMPSet partition\n(Enter values[Format:1,2])>>>");
                            byte[] pascSize = new byte[3];
                            int pascval = 1;
                            int pascaltye = 1;
                            try {
                                pascval = in.read(pascSize);
                                String s = new String(pascSize);
                                String[] sp = s.split(",");
                                pascval = Integer.valueOf(sp[0]);
                                pascaltye = Integer.valueOf(sp[1]);
                            } catch (NumberFormatException e) {
                                pascval = in.read(pascSize);
                                String s = new String(pascSize);
                                String[] sp = s.split(",");
                                pascval = Integer.valueOf(sp[0]);
                                pascaltye = Integer.valueOf(sp[1]);
                            }
                            out.print("\n");
                            HashMap<Integer, String> parts = program.pascalTriangle(pascval, pascaltye);
                            Set<Integer> keys = parts.keySet();
                            for (int p = 0; p < parts.keySet().size(); p++) {

                                Integer va = (Integer) keys.toArray()[p];
                                out.println("##########################");
                                out.println("Pascal Triangle of " + va);
                                out.println("##########################");
                                out.println(parts.get(va));
                                out.print("\n");
                            }
                            out.println();

                        }
                        continue;
                    case 24:
                        problem.clearMPSentinels();
                        out.println("CP Sentences:");
                        try {
                            for (int i = 0; i < program.getProblem().getProblemSize() + 1; i++) {
                                constraintMP2(problem, boolsentinel, i);
                            }
                        } catch (Exception e) {
                            for (int i = 0; i < program.getProblem().getProblemSize(); i++) {
                                constraintMP2(problem, boolsentinel, i);
                            }
                        }
                        program.getProblem().getSentences().remove(0);
                        continue;
                    case 25:
                        problem.clearMPSentinels();

                        out.println("CP Sentences:");
                        try {
                            for (int i = 0; i < program.getProblem().getProblemSize() + 1; i++) {
                                constraintMP3(problem, boolsentinel, i);
                            }

                        } catch (Exception e) {
                            for (int i = 0; i < program.getProblem().getProblemSize(); i++) {
                                constraintMP3(problem, boolsentinel, i);
                            }
                        }
                        program.getProblem().getSentences().remove(0);
                        continue;
                    case 26:
                        problem.clearMPSentinels();

                        out.println("CP Sentences:");
                        try {
                            for (int i = 0; i < program.getProblem().getProblemSize() + 1; i++) {
                                constraintMP4(problem, boolsentinel, i);
                            }

                        } catch (Exception e) {
                            for (int i = 0; i < program.getProblem().getProblemSize(); i++) {
                                constraintMP4(problem, boolsentinel, i);
                            }
                        }
                        program.getProblem().getSentences().remove(0);
                        continue;
                    case 27:
                        problem.clearMPSentinels();

                        out.println("CP Sentences:");
                        out.println("19:     Show Ferrers Diagrams");
                        try {
                            for (int i = 0; i < program.getProblem().getProblemSize() + 1; i++) {
                                constraintMP5(problem, boolsentinel, i);
                            }

                        } catch (Exception e) {
                            for (int i = 0; i < program.getProblem().getProblemSize(); i++) {
                                constraintMP5(problem, boolsentinel, i);
                            }
                        }
                        program.getProblem().getSentences().remove(0);
                        continue;
                    default:
                        continue;
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(LCMainSystem.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private static void LCmenu() {
        {
            out.println("\nLCProgram Menu\nExplicit Count Methods\n==========================\n");
            out.println("01:     Problem Size");
            out.println("02:     MP Sentences");
            out.println("03:     Principle Values (MPSet)");
            out.println("04:     Alpha Sizes");
            out.println("05:     Partition Sets");
            out.println("06:     Count Problems");
            out.println("07:     Alpha Label Tokens");
            out.println("08:     MP Sets");
            out.println("09:     Principle Values (RMPSet)");
            out.println("10:     Alphanumerics");
            out.println("11:     Meta-Operation");
            out.println("12:     Principle Values (LMPSet)");
            out.println("13:     File MP Reader");
            out.println("14:     Change Problem Size");
            out.println("15:     Change LC Problems[Interactive]");
            out.println("16:     LCTable View");
            out.println("17:     Partition of Integers");
            out.println("18:     Equality Principles");
            out.println("19:     Show Ferrers Diagrams");
            out.println("20:     Permutation and Combination");
            out.println("21:     One-to-One Correspondence");
            out.println("22:     Possible Number of Orders");
            out.println("23:     Show Pascal Triangle");
            out.println("Press Ctrl+C: Quit LCProgram");
            out.println("==========================\n");
        }
    }

    private static void LCalphanumerics(ILCProblem problem) {
        ArrayList<Sentence> sentences = problem.getSentences();
        for (int i = 0; i < sentences.size(); i++) {
            Sentence s = sentences.get(i);
            out.println("Sentence MP(" + (i + 1) + "):");
            List<IAlphanumeric> als = s.getAlphanumeric();
            for (int k = 0; k < als.size(); k++) {
                IAlphanumeric ia = als.get(k);
                out.print(ia.getLetter() + "(" + ia.getSize() + ")  ");
            }
            out.println("");
        }
    }

    private static void OnetoOneCorrespondence(ILCProblem problem) {
        ArrayList<Sentence> sentences = problem.getSentences();
        for (int i = 0; i < sentences.size(); i++) {
            Sentence s = sentences.get(i);
            String sizes = "";
            out.println("Sentence MP(" + (i + 1) + "):");
            List<IAlphanumeric> als = s.getAlphanumeric();
            for (int k = 0; k < als.size(); k++) {
                IAlphanumeric ia = als.get(k);
                out.print(ia.getLetter());
                sizes += ia.getSize();
            }
            out.print("--------->");
            out.print(sizes);
            out.println("");
        } 
    }

    private static void readFileSentence(ILCProblem problem) {
        problem.clearMPSentinels();
        try {
            BufferedReader br = new BufferedReader(new FileReader("sentence.txt"));
            String data;
            int i = 1;
            while ((data = br.readLine()) != null) {
                problem.getSentences().add(new Sentence(new String(data), i));
                out.println(new String(data));
                i++;
            }
        } catch (IOException ex) {
            Logger.getLogger(LCMainSystem.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private static void constraintMP5(ILCProblem problem, boolean boolsentinel, int i) throws IOException {

        int[] cMP = {0, 6, 10, 27, 14, 19, 20};
        boolsentinel = false;
        int size = 0;
        if (i > 0) {
            out.println("Please give your sentence for MP" + i + "(max:" + cMP[i] + " letters):");
        }
        byte[] mp1 = new byte[cMP[i]];
        size = in.read(mp1);
        String smp1 = new String(mp1);
        problem.getSentences().add(new Sentence(smp1.trim(), i));
    }

    private static void constraintMP4(ILCProblem problem, boolean boolsentinel, int i) throws IOException {

        int[] cMPSet = {0, 6, 10, 19, 20};
        boolsentinel = false;
        int size = 0;
        if (i > 0) {
            out.println("Please give your sentence for MP" + i + "(max:" + cMPSet[i] + " letters):");
        }
        byte[] mp1 = new byte[cMPSet[i]];
        size = in.read(mp1);
        String smp1 = new String(mp1);
        problem.getSentences().add(new Sentence(smp1.trim(), i));

    }

    private static void constraintMP1(ILCProblem problem, boolean boolsentinel, int i) throws IOException {

        boolsentinel = false;
        int size = 0;
        if (i > 0) {
            out.println("Enter your sentence for LCP" + i + "(max:27 letters):");
        }
        byte[] mp1 = new byte[100];
        size = in.read(mp1);
        String smp1 = new String(mp1);
        problem.getSentences().add(new Sentence(smp1.trim(), i));
    }

    private static void constraintMP2(ILCProblem problem, boolean boolsentinel, int i) throws IOException {

        int[] cLMPSet = {3, 4, 6, 10, 14, 19, 20, 27};


        boolsentinel = false;
        int size = 0;
        if (i > 1) {
            out.println("Please give your sentence for MP" + (i - 1) + "(max:" + cLMPSet[i] + " letters):");
        }
        byte[] mp1 = new byte[cLMPSet[i]];
        size = in.read(mp1);
        String smp1 = new String(mp1);
        problem.getSentences().add(new Sentence(smp1.trim(), i));
        if (in.markSupported()) {
            in.mark(size);
        }
    }

    private static void constraintMP3(ILCProblem problem, boolean boolsentinel, int i) throws IOException {

        int[] cRMPSet = {0, 6, 10, 14, 19, 20};
        boolsentinel = false;
        int size = 0;
        if (i > 0) {
            out.println("Please give your sentence for MP" + i + "(max:" + cRMPSet[i] + " letters):");
        }
        byte[] mp1 = new byte[cRMPSet[i]];
        size = in.read(mp1);
        String smp1 = new String(mp1);
        problem.getSentences().add(new Sentence(smp1.trim(), i));
    }
}
    
