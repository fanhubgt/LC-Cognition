package lcprogram;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.nio.channels.SocketChannel;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author appiah
 */
public class LCMainServer implements Runnable {

    private ServerSocket server;
    private int port = 8110;
    private Socket socket;
    private String host = "localhost";
    private FileOutputStream fos;

    public static void main(String[] argv) {
        if (argv.length == 1) {
            LCMainServer s = new LCMainServer(Integer.valueOf(argv[0]));
            Thread th = new Thread(s);
            th.start();
        } else if (argv.length == 2) {
            LCMainServer s = new LCMainServer(argv[0], Integer.valueOf(argv[1]));
            Thread th = new Thread(s);
            th.start();
        } else {
            LCMainServer s = new LCMainServer();
            //  s.run();
            Thread th = new Thread(s);
            th.start();
        }
    }

    public LCMainServer() {
        try {
            server = new ServerSocket(port);
        } catch (IOException ex) {
            Logger.getLogger(LCMainServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public LCMainServer(int port) {
        try {
            this.port = port;
            server = new ServerSocket(port);
        } catch (IOException ex) {
            Logger.getLogger(LCMainServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public LCMainServer(String host, int port) {
        try {
            this.port = port;
            this.host = host;
            server = new ServerSocket(port);
        } catch (IOException ex) {
            Logger.getLogger(LCMainServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getHost() {
        return host;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public int getPort() {
        return port;
    }

    public void run() {
        try {
            // server.bind(new InetSocketAddress(host, port));
            socket = server.accept();
            SocketChannel channel = socket.getChannel();
            OutputStream os = socket.getOutputStream();
            InputStream is = socket.getInputStream();
            System.out.println("    LCProgram Log Server 1.5");
            System.out.print("===================================\n");
            fos = new FileOutputStream(new File("LCLog.txt"));

            // wait(100);
            System.out.println("Server is started.....\n");
            int i = 0;
            System.out.println("Remote Host Address:"+socket.getRemoteSocketAddress().toString());
            while (true) {
                byte[] lcout = new byte[server.getReceiveBufferSize()];//size=99 (2 digits, 10^2-1values) for integers.

                if (lcout.length > 1) {
                    try {
                        int v = is.read(lcout);
                        String s = new String(lcout);
                        s = "  LCServer Log #" + (++i) + ":: " + s.trim();
                        s += "\n";
                        System.out.println(s);

                        fos.write(s.getBytes());
                        fos.flush();
                    } catch (NumberFormatException e) {
                        int v = is.read(lcout);
                        String s = new String(lcout);
                        System.out.println("  LCServer Log #" + (++i) + ":: " + s.trim());
                        s += "\n";
                        fos.write(s.getBytes());
                        fos.flush();
                    }
                }
            }
        } catch (SocketException ex) {
            try {
                socket.close();
                server.close();
                fos.close();
                Logger.getLogger(LCMainServer.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex1) {
                Logger.getLogger(LCMainServer.class.getName()).log(Level.SEVERE, null, ex1);
            }
        } catch (IOException ex) {
            Logger.getLogger(LCMainServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
