package lcprogram;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.logging.FileHandler;
import static java.lang.System.out;
import static java.lang.System.in;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Main KeyStore Execution Program for LC.
 * 
 * @author appiah
 */
public class LCMainKeyStore {

    static LCProgram program = new LCProgram();
    static ILCProblem problem = program.getProblem();
    static Logger log = Logger.getLogger(LCMainKeyStore.class.getName());

    public static void main(String[] args) {
        try {
            log.addHandler(new FileHandler("%h/lcprogram%u.log"));
            log.setFilter(new LCFilterDoubleMessage());
            boolean boolsentinel = true;
            if (boolsentinel) {
                program.MPSentences();
            }
            byte[] menu = new byte[2];//size=99 (2 digits, 10^2-1values) for integers.
            while (true) {
                log.log(Level.INFO, "\nSelect an item from menu(00: Menu Items)>>>");
                int value = 1;
                try {
                    int v = in.read(menu);
                    String s = new String(menu);
                    value = Integer.valueOf(s);
                } catch (NumberFormatException e) {
                    int v = in.read(menu);
                    String s = new String(menu);
                    value = Integer.valueOf(s);
                }
                log.log(Level.INFO, "\n");
                switch (value) {
                    case 0:
                        LCmenu();
                        continue;
                    case 1:
                        log.log(Level.INFO, "Problem Size Information\n=======================\n");
                        log.log(Level.INFO, "Problem size:" + problem.getProblemSize());
                        continue;
                    case 2:
                        log.log(Level.INFO, "Sentence Information\n==========================\n");
                        for (int i = 0; i < program.getProblem().getProblemSize(); i++) {
                            log.log(Level.INFO, "LCP Sentence " + (i + 1) + ":" + problem.getSentences().get(i).toString());
                        }
                        continue;
                    case 3:
                        log.log(Level.INFO, "MP(Set) Principle Values\n=============================\n");
                        log.log(Level.INFO, "Addition Principle Value(MP):=" + program.add());
                        log.log(Level.INFO, "Substraction Principle Value(MP):=" + program.substract());
                        log.log(Level.INFO, "Multiplication Principle Value(MP):=" + program.multiply());
                        log.log(Level.INFO, "Addition Principle Value(MPSet):=" + program.addMPSet());
                        log.log(Level.INFO, "Substraction Principle Value(MPSet):=" + program.subMPSet());
                        log.log(Level.INFO, "Multiplication Principle Value(MPSet):=" + program.mulMPSet());
                        continue;
                    case 4:
                        log.log(Level.INFO, "Alpha Sizes Information\n===========================\n");
                        for (int i = 0; i < program.getProblem().getProblemSize(); i++) {
                            log.log(Level.INFO, "(" + (1 + i) + ") Alpha size:" + problem.getSentences().get(i).getAlphaLabels().size());
                        }
                        continue;
                    case 5:
                        log.log(Level.INFO, "Partition of Integers\n=============================\n");
                        log.log(Level.INFO, program.partition().toString());
                        continue;
                    case 6:
                        log.log(Level.INFO, "Count Method Information\n==============================\n");
                        for (int i = 0; i < program.getProblem().getProblemSize(); i++) {
                            log.log(Level.INFO, "Count MP(" + (1 + i) + "):" + problem.getSentences().get(i).getCount());
                        }
                        continue;
                    case 7:
                        log.log(Level.INFO, "Alpha-Label Information\n======================================\n");
                        for (int i = 0; i < program.getProblem().getProblemSize(); i++) {
                            ArrayList<AlphaLabel> labs = problem.getSentences().get(i).getAlphaLabels();
                            log.log(Level.INFO, "Alphalabel " + (i + 1) + ":[");
                            String words = "";
                            for (int k = 0; k < labs.size(); k++) {
                                words += labs.get(k).getWord() + ", ";
                            }
                            words = words.substring(0, words.length() - 2);
                            log.log(Level.INFO, words.trim() + "]");
                            log.log(Level.INFO, "");
                        }
                        continue;
                    case 8:
                        log.log(Level.INFO, "MP Sets Information\n===============================\n");
                        log.log(Level.INFO, "MP:=" + program.MPOrder());
                        log.log(Level.INFO, "MPset:=" + program.MPSetOrder());
                        log.log(Level.INFO, "RMPset:=" + program.RMPSetOrder());
                        log.log(Level.INFO, "LMPset:=" + program.LMPSetOrder());
                        continue;
                    case 9:
                        log.log(Level.INFO, "Principle Values for RMPSet\n======================================\n");
                        log.log(Level.INFO, "Addition Principle Value(RMPSet):=" + program.addRMP());
                        log.log(Level.INFO, "Substraction Principle Value(RMPSet):=" + program.subRMP());
                        log.log(Level.INFO, "Multiplication Principle Value(RMPSet):=" + program.mulRMP());
                        continue;
                    case 10:
                         {
                            log.log(Level.INFO, "Alphanumerics Information\n=======================================\n");
                            program.getProblem().clearMPSentinels();
                            program.MPSentences();
                            LCalphanumerics(program.getProblem());
                        }
                        continue;
                    case 11:
                        log.log(Level.INFO, "Meta-sentential Operations\n====================================\n");
                        program.metaSententialOperation();
                        log.log(Level.INFO, program.getOperations().toString());
                        continue;
                    case 12:
                        log.log(Level.INFO, "Principle values for LMPSet\n==================================\n");
                        log.log(Level.INFO, "Addition Principle Value(LMPSet):=" + program.addLMP());
                        log.log(Level.INFO, "Substraction Principle Value(LMPSet):=" + program.subLMP());
                        log.log(Level.INFO, "Multiplication Principle Value(LMPSet):=" + program.mulLMP());
                        continue;
                    case 13:
                        log.log(Level.INFO, "File Sentence Stream\n=======================\n");
                        readFileSentence(problem);
                        continue;
                    case 14:
                        log.log(Level.INFO, "Change Problem Size\n=======================\n");
                        log.log(Level.INFO, "Enter the size of counting problem(Format=001 to 999):");
                        byte[] size = new byte[3];
                        try {
                            int v = in.read(size);
                            String s = new String(size);
                            v = Integer.valueOf(s);
                            program.getProblem().setProblemSize(v);
                        } catch (NumberFormatException e) {
                            int v = in.read(size);
                            String s = new String(size);
                            v = Integer.valueOf(s);
                            program.getProblem().setProblemSize(v);
                        }
                        continue;
                    case 15:
                        log.log(Level.INFO, "Key-Input Problems Entry. \nChange the problem size (Item:14) if it is necessary.\nDefault is 5." +
                                "\n========================================================\n");

                        problem.clearMPSentinels();
                        log.log(Level.INFO, "CP Sentences");
                        try {
                            for (int i = 0; i < program.getProblem().getProblemSize() + 1; i++) {
                                constraintMP1(problem, boolsentinel, i);
                            }

                        } catch (Exception e) {
                            for (int i = 0; i < program.getProblem().getProblemSize(); i++) {
                                constraintMP1(problem, boolsentinel, i);
                            }
                        }
                        program.getProblem().getSentences().remove(0);
                        continue;
                    case 16:
                        log.log(Level.INFO, "LCTable Columns View");
                        log.log(Level.INFO, "Index      Position      Size        Word");
                        log.log(Level.INFO, "==========================================");

                        for (int k = 0; k < problem.getSentences().size(); k++) {
                            Sentence s = problem.getSentences().get(k);
                            for (int l = 0; l < s.getAlphaLabels().size(); l++) {
                                AlphaLabel al = s.getAlphaLabels().get(l);
                                log.log(Level.INFO, al.toString());
                            }
                        }
                        continue;
                    case 17: {
                        log.log(Level.INFO, "Partition of Integers");
                        log.log(Level.INFO, "==========================================");
                        log.log(Level.INFO, "Enter the [reduce,type] of partition of integers\n(Reduce Values=0 to 9)\nType Values:\n(1)MP partition\n(2)MPSet partition\n(3)RMPSet partition\n(4)LMPSet partition\n(Enter values[Format:1,2])>>>");
                        byte[] parSize = new byte[3];
                        int v = 1;
                        int tye = 1;
                        try {
                            v = in.read(parSize);
                            String s = new String(parSize);
                            String[] sp = s.split(",");
                            v = Integer.valueOf(sp[0]);
                            tye = Integer.valueOf(sp[1]);
                        } catch (NumberFormatException e) {
                            v = in.read(parSize);
                            String s = new String(parSize);
                            String[] sp = s.split(",");
                            v = Integer.valueOf(sp[0]);
                            tye = Integer.valueOf(sp[1]);
                        }
                        log.log(Level.INFO, "\n");
                        HashMap<Integer, String> parts = program.partitionInteger(v, tye);
                        Set<Integer> keys = parts.keySet();
                        for (int p = 0; p < parts.keySet().size(); p++) {

                            Integer va = (Integer) keys.toArray()[p];
                            log.log(Level.INFO, "######################");
                            log.log(Level.INFO, "Partition of " + va);
                            log.log(Level.INFO, "######################");
                            log.log(Level.INFO, parts.get(va));
                            log.log(Level.INFO, "\n");
                        }
                        log.log(Level.INFO, "");
                        continue;
                    }
                    case 18:
                        log.log(Level.INFO, "    Equality Principles");
                        log.log(Level.INFO, "===========================");
                        log.log(Level.INFO, "Enter the [set1,set2] of sets\n\nSet Values:\n(1)MP partition\n(2)MPSet partition\n(3)RMPSet partition\n(4)LMPSet partition\n(Enter values[Format:1,2])>>>");
                        byte[] parSize = new byte[3];
                        int v = 1;
                        int tye = 1;
                        try {
                            v = in.read(parSize);
                            String s = new String(parSize);
                            String[] sp = s.split(",");
                            v = Integer.valueOf(sp[0]);
                            tye = Integer.valueOf(sp[1]);
                        } catch (NumberFormatException e) {
                            v = in.read(parSize);
                            String s = new String(parSize);
                            String[] sp = s.split(",");
                            v = Integer.valueOf(sp[0]);
                            tye = Integer.valueOf(sp[1]);
                        }
                        String[] type = {"MP", "MPSet", "RMPSet", "LMPSet"};
                        log.log(Level.INFO, "\n");
                        log.log(Level.INFO, "Count Equality Principle Value(" + type[v - 1] + ":" + type[tye - 1] + "):=" + program.getEqualityPrincpleCV(v, tye));
                        log.log(Level.INFO, "Equality Principle Value(" + type[v - 1] + ":" + type[tye - 1] + "):=" + program.getEqualityPrincpleValues(v, tye));
                        continue;
                    case 19:
                         {
                            log.log(Level.INFO, "Ferrers Diagram: Dot Display");
                            log.log(Level.INFO, "==============================");
                            log.log(Level.INFO, "Enter the type of sets\n\nSet Values:\n(1)MP partition\n(2)MPSet partition\n(3)RMPSet partition\n(4)LMPSet partition\n(Enter value)>>>");
                            byte[] pardiaSize = new byte[1];
                            int diaval = 1;

                            try {
                                diaval = in.read(pardiaSize);
                                String s = new String(pardiaSize);
                                diaval = Integer.valueOf(s);

                            } catch (NumberFormatException e) {
                                diaval = in.read(pardiaSize);
                                String s = new String(pardiaSize);
                                diaval = Integer.valueOf(s);
                            }
                            String[] typeSet = {"MP", "MPSet", "RMPSet", "LMPSet"};
                            log.log(Level.INFO, "Partition Set:= " + typeSet[diaval - 1]);

                            log.log(Level.INFO, "\n");
                            program.ferrersdiagram(diaval);
                        }
                        continue;
                    case 20:
                         {
                            log.log(Level.INFO, "Basic Combinatorial Information (n,r)");
                            log.log(Level.INFO, "==========================================");
                            log.log(Level.INFO, "Enter the type of sets\n\nSet Values:\n(1)MP partition\n(2)MPSet partition\n(3)RMPSet partition\n(4)LMPSet partition\n(Enter value)>>>");
                            byte[] rpmSize = new byte[1];
                            int rpmSetValue = 1;

                            try {
                                rpmSetValue = in.read(rpmSize);
                                String s = new String(rpmSize);
                                rpmSetValue = Integer.valueOf(s);

                            } catch (NumberFormatException e) {
                                rpmSetValue = in.read(rpmSize);
                                String s = new String(rpmSize);
                                rpmSetValue = Integer.valueOf(s);
                            }
                            log.log(Level.INFO, "\n");
                            String[] typeSet = {"MP", "MPSet", "RMPSet", "LMPSet"};
                            log.log(Level.INFO, "Partition Set(" + typeSet[rpmSetValue - 1] + ")\n#####################");
                            log.log(Level.INFO, "Permutation-1 Word Arrangement:=");
                            List<Long> p1 = program.rpermuteList(rpmSetValue);
                            log.log(Level.INFO, p1.toString());
                            log.log(Level.INFO, "Permutation-2 of Word Arrangements:=");

                            List<Integer> p2 = program.rpermute2List(rpmSetValue);
                            log.log(Level.INFO, p2.toString());
                            int count = 0;
                            for (int l = 0; l < p2.size(); l++) {
                                if (p2.get(l) == 2139095040) {
                                    count += 1;
                                }
                            }
                            if (count > (p2.size() / 3)) {
                                log.log(Level.INFO, "Problem permutation-2 is an infinite count process.");
                            }
                            log.log(Level.INFO, "Combination-1 of Word Selection:=");
                            List<Long> cwm = program.rcombinantList(rpmSetValue);
                            log.log(Level.INFO, cwm.toString());
                            log.log(Level.INFO, "Combination-2 of Word Selection:=");
                            List<Integer> cwm2 = program.rcombinant2List(rpmSetValue);
                            log.log(Level.INFO, cwm2.toString());
                        }
                        continue;
                    case 21:
                        log.log(Level.INFO, "One-to-One Correspondence Information");
                        log.log(Level.INFO, "========================================");
                        log.log(Level.INFO, "INFO: After digit 9 is a double digit value.");
                        log.log(Level.INFO, "Letter(s)------>Digit(s)\n");
                        OnetoOneCorrespondence(program.getProblem());
                        continue;
                    case 22:
                        log.log(Level.INFO, "  Possible Number of Orders(PO) ");
                        log.log(Level.INFO, "==================================");
                        String[] typeSet = {"MP", "MPSet", "RMPSet", "LMPSet"};
                        List<String> po = program.orderList();
                        log.log(Level.INFO, po.toString());
                        continue;
                    case 23:
                         {
                            log.log(Level.INFO, "     Pascal Triangles");
                            log.log(Level.INFO, "==============================");
                            log.log(Level.INFO, "Enter the [reduce-by,type] of partition of integers\n(Reduce-by Values=0 to 9)\nType Values:\n(1)MP partition\n(2)MPSet partition\n(3)RMPSet partition\n(4)LMPSet partition\n(Enter values[Format:1,2])>>>");
                            byte[] pascSize = new byte[3];
                            int pascval = 1;
                            int pascaltye = 1;
                            try {
                                pascval = in.read(pascSize);
                                String s = new String(pascSize);
                                String[] sp = s.split(",");
                                pascval = Integer.valueOf(sp[0]);
                                pascaltye = Integer.valueOf(sp[1]);
                            } catch (NumberFormatException e) {
                                pascval = in.read(pascSize);
                                String s = new String(pascSize);
                                String[] sp = s.split(",");
                                pascval = Integer.valueOf(sp[0]);
                                pascaltye = Integer.valueOf(sp[1]);
                            }
                            log.log(Level.INFO, "\n");
                            HashMap<Integer, String> parts = program.pascalTriangle(pascval, pascaltye);
                            Set<Integer> keys = parts.keySet();
                            for (int p = 0; p < parts.keySet().size(); p++) {

                                Integer va = (Integer) keys.toArray()[p];
                                log.log(Level.INFO, "##########################");
                                log.log(Level.INFO, "Pascal Triangle of " + va);
                                log.log(Level.INFO, "##########################");
                                log.log(Level.INFO, parts.get(va));
                                log.log(Level.INFO, "\n");
                            }
                            log.log(Level.INFO, "");

                        }
                        continue;
                    case 24:
                        problem.clearMPSentinels();
                        log.log(Level.INFO, "CP Sentences:");
                        try {
                            for (int i = 0; i < program.getProblem().getProblemSize() + 1; i++) {
                                constraintMP2(problem, boolsentinel, i);
                            }
                        } catch (Exception e) {
                            for (int i = 0; i < program.getProblem().getProblemSize(); i++) {
                                constraintMP2(problem, boolsentinel, i);
                            }
                        }
                        program.getProblem().getSentences().remove(0);
                        continue;
                    case 25:
                        problem.clearMPSentinels();

                        log.log(Level.INFO, "CP Sentences:");
                        try {
                            for (int i = 0; i < program.getProblem().getProblemSize() + 1; i++) {
                                constraintMP3(problem, boolsentinel, i);
                            }

                        } catch (Exception e) {
                            for (int i = 0; i < program.getProblem().getProblemSize(); i++) {
                                constraintMP3(problem, boolsentinel, i);
                            }
                        }
                        program.getProblem().getSentences().remove(0);
                        continue;
                    case 26:
                        problem.clearMPSentinels();

                        log.log(Level.INFO, "CP Sentences:");
                        try {
                            for (int i = 0; i < program.getProblem().getProblemSize() + 1; i++) {
                                constraintMP4(problem, boolsentinel, i);
                            }

                        } catch (Exception e) {
                            for (int i = 0; i < program.getProblem().getProblemSize(); i++) {
                                constraintMP4(problem, boolsentinel, i);
                            }
                        }
                        program.getProblem().getSentences().remove(0);
                        continue;
                    case 27:
                        problem.clearMPSentinels();

                        log.log(Level.INFO, "CP Sentences:");
                        log.log(Level.INFO, "19:     Show Ferrers Diagrams");
                        try {
                            for (int i = 0; i < program.getProblem().getProblemSize() + 1; i++) {
                                constraintMP5(problem, boolsentinel, i);
                            }

                        } catch (Exception e) {
                            for (int i = 0; i < program.getProblem().getProblemSize(); i++) {
                                constraintMP5(problem, boolsentinel, i);
                            }
                        }
                        program.getProblem().getSentences().remove(0);
                        continue;
                    default:
                        continue;
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(LCMainConsole.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private static void LCmenu() {
        {
            log.log(Level.INFO, "\nLCProgram Menu\nExplicit Count Methods\n==========================\n");
            log.log(Level.INFO, "01:     Problem Size");
            log.log(Level.INFO, "02:     MP Sentences");
            log.log(Level.INFO, "03:     Principle Values (MPSet)");
            log.log(Level.INFO, "04:     Alpha Sizes");
            log.log(Level.INFO, "05:     Partition Sets");
            log.log(Level.INFO, "06:     Count Problems");
            log.log(Level.INFO, "07:     Alpha Label Tokens");
            log.log(Level.INFO, "08:     MP Sets");
            log.log(Level.INFO, "09:     Principle Values (RMPSet)");
            log.log(Level.INFO, "10:     Alphanumerics");
            log.log(Level.INFO, "11:     Meta-Operation");
            log.log(Level.INFO, "12:     Principle Values (LMPSet)");
            log.log(Level.INFO, "13:     File MP Reader");
            log.log(Level.INFO, "14:     Change Problem Size");
            log.log(Level.INFO, "15:     Change LC Problems[Interactive]");
            log.log(Level.INFO, "16:     LCTable View");
            log.log(Level.INFO, "17:     Partition of Integers");
            log.log(Level.INFO, "18:     Equality Principles");
            log.log(Level.INFO, "19:     Show Ferrers Diagrams");
            log.log(Level.INFO, "20:     Permutation and Combination");
            log.log(Level.INFO, "21:     One-to-One Correspondence");
            log.log(Level.INFO, "22:     Possible Number of Orders");
            log.log(Level.INFO, "23:     Show Pascal Triangle");
            log.log(Level.INFO, "Press Ctrl+C: Quit LCProgram");
            log.log(Level.INFO, "==========================\n");
        }
    }

    private static void LCalphanumerics(ILCProblem problem) {
        ArrayList<Sentence> sentences = problem.getSentences();
        for (int i = 0; i < sentences.size(); i++) {
            Sentence s = sentences.get(i);
            log.log(Level.INFO, "Sentence MP(" + (i + 1) + "):");
            List<IAlphanumeric> als = s.getAlphanumeric();
            for (int k = 0; k < als.size(); k++) {
                IAlphanumeric ia = als.get(k);
                log.log(Level.INFO, ia.getLetter() + "(" + ia.getSize() + ")  ");
            }
            log.log(Level.INFO, "");
        }
    }

    private static void OnetoOneCorrespondence(ILCProblem problem) {
        ArrayList<Sentence> sentences = problem.getSentences();
        for (int i = 0; i < sentences.size(); i++) {
            Sentence s = sentences.get(i);
            String sizes = "";
            log.log(Level.INFO, "Sentence MP(" + (i + 1) + "):");
            List<IAlphanumeric> als = s.getAlphanumeric();
            for (int k = 0; k < als.size(); k++) {
                IAlphanumeric ia = als.get(k);
                log.log(Level.INFO, Character.toString(ia.getLetter()));
                sizes += ia.getSize();
            }
            log.log(Level.INFO, "--------->");
            log.log(Level.INFO, sizes);
            log.log(Level.INFO, "");
        }
    }

    private static void readFileSentence(ILCProblem problem) {
        problem.clearMPSentinels();
        try {
            BufferedReader br = new BufferedReader(new FileReader("sentence.txt"));
            String data;
            int i = 1;
            while ((data = br.readLine()) != null) {
                problem.getSentences().add(new Sentence(new String(data), i));
                log.log(Level.INFO, new String(data));
                i++;
            }
        } catch (IOException ex) {
            log.log(Level.SEVERE, null, ex);
        }
    }

    private static void constraintMP5(ILCProblem problem, boolean boolsentinel, int i) throws IOException {

        int[] cMP = {0, 6, 10, 27, 14, 19, 20};
        boolsentinel = false;
        int size = 0;
        if (i > 0) {
            log.log(Level.INFO, "Please give your sentence for MP" + i + "(max:" + cMP[i] + " letters):");
        }
        byte[] mp1 = new byte[cMP[i]];
        size = in.read(mp1);
        String smp1 = new String(mp1);
        problem.getSentences().add(new Sentence(smp1.trim(), i));
    }

    private static void constraintMP4(ILCProblem problem, boolean boolsentinel, int i) throws IOException {

        int[] cMPSet = {0, 6, 10, 19, 20};
        boolsentinel = false;
        int size = 0;
        if (i > 0) {
            log.log(Level.INFO, "Please give your sentence for MP" + i + "(max:" + cMPSet[i] + " letters):");
        }
        byte[] mp1 = new byte[cMPSet[i]];
        size = in.read(mp1);
        String smp1 = new String(mp1);
        problem.getSentences().add(new Sentence(smp1.trim(), i));

    }

    private static void constraintMP1(ILCProblem problem, boolean boolsentinel, int i) throws IOException {

        boolsentinel = false;
        int size = 0;
        if (i > 0) {
            log.log(Level.INFO, "Enter your sentence for LCP" + i + "(max:27 letters):");
        }
        byte[] mp1 = new byte[100];
        size = in.read(mp1);
        String smp1 = new String(mp1);
        problem.getSentences().add(new Sentence(smp1.trim(), i));
    }

    private static void constraintMP2(ILCProblem problem, boolean boolsentinel, int i) throws IOException {

        int[] cLMPSet = {3, 4, 6, 10, 14, 19, 20, 27};


        boolsentinel = false;
        int size = 0;
        if (i > 1) {
            log.log(Level.INFO, "Please give your sentence for MP" + (i - 1) + "(max:" + cLMPSet[i] + " letters):");
        }
        byte[] mp1 = new byte[cLMPSet[i]];
        size = in.read(mp1);
        String smp1 = new String(mp1);
        problem.getSentences().add(new Sentence(smp1.trim(), i));
        if (in.markSupported()) {
            in.mark(size);
        }
    }

    private static void constraintMP3(ILCProblem problem, boolean boolsentinel, int i) throws IOException {

        int[] cRMPSet = {0, 6, 10, 14, 19, 20};
        boolsentinel = false;
        int size = 0;
        if (i > 0) {
            log.log(Level.INFO, "Please give your sentence for MP" + i + "(max:" + cRMPSet[i] + " letters):");
        }
        byte[] mp1 = new byte[cRMPSet[i]];
        size = in.read(mp1);
        String smp1 = new String(mp1);
        problem.getSentences().add(new Sentence(smp1.trim(), i));
    }
}
    
