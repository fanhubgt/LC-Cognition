
package lcprogram;

import java.util.logging.Filter;
import java.util.logging.LogRecord;

/**
 *
 * @author appiah
 */
public class LCFilter implements Filter {

    public boolean isLoggable(LogRecord record) {
        return true;
    }
}
