
package lcprogram;

import java.util.logging.Formatter;
import java.util.logging.LogRecord;

/**
 *
 * @author appiah
 */
public class LCFormater extends Formatter {

    @Override
    public String format(LogRecord record) {
        return "\n"+record.getMessage();
    }
}
