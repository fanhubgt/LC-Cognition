
package lcprogram;

import java.util.logging.Filter;
import java.util.logging.LogRecord;

/**
 *
 * @author appiah
 */
public class LCFilterDoubleMessage implements Filter {

    String lastMessage = "";

    public LCFilterDoubleMessage() {
    }
    
    public boolean isLoggable(LogRecord record) {
        if (lastMessage.equalsIgnoreCase(record.getMessage())) {
            return false;
        } else {
            lastMessage = record.getMessage();
            return true;
        }
    }
    
}
