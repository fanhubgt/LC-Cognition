package lcprogram.test;

import lcprogram.LCProgram;
import lcprogram.MarriageProblem;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import static java.lang.System.out;

/**
 *
 * @author appiah
 */
public class MetaSententialOpTest {

    public MetaSententialOpTest() {
    }
    LCProgram program;
    MarriageProblem problem;

    @Before
    public void setUp() {
        program = new LCProgram();
        problem = (MarriageProblem) program.getProblem();
        program.MPSentences();
    }

    @After
    public void tearDown() {
        program = null;
        problem = null;
    }

    @Test
    public void testMetaSenttentialOp() {
        program.metaSententialOperation();
        out.println(program.getOperations());

    }
}
