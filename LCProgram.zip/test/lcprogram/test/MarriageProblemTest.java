package lcprogram.test;

import lcprogram.*;
import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author appiah
 */
public class MarriageProblemTest {
    

    public MarriageProblemTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getProblemSize method, of class MarriageProblem.
     */
    @Test
    public void getProblemSize() {
        System.out.println("getProblemSize");
        MarriageProblem instance = new MarriageProblem();
        int expResult = 0;
        int result = instance.getProblemSize();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setProblemSize method, of class MarriageProblem.
     */
    @Test
    public void setProblemSize() {
        System.out.println("setProblemSize");
        int problemSize = 0;
        MarriageProblem instance = new MarriageProblem();
        instance.setProblemSize(problemSize);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSentences method, of class MarriageProblem.
     */
    @Test
    public void getSentences() {
        System.out.println("getSentences");
        MarriageProblem instance = new MarriageProblem();
        ArrayList<Sentence> expResult = null;
        ArrayList<Sentence> result = instance.getSentences();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setSentences method, of class MarriageProblem.
     */
    @Test
    public void setSentences() {
        System.out.println("setSentences");
        ArrayList<Sentence> sentences = null;
        MarriageProblem instance = new MarriageProblem();
        instance.setSentences(sentences);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addSentence method, of class MarriageProblem.
     */
    @Test
    public void addSentence() {
        System.out.println("addSentence");
        Sentence se = null;
        MarriageProblem instance = new MarriageProblem();
        instance.addSentence(se);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of reSentence method, of class MarriageProblem.
     */
    @Test
    public void reSentence() {
        System.out.println("reSentence");
        Sentence se = null;
        MarriageProblem instance = new MarriageProblem();
        instance.reSentence(se);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }


    /**
     * Test of equals method, of class MarriageProblem.
     */
    @Test
    public void equals() {
        System.out.println("equals");
        Object obj = null;
        MarriageProblem instance = new MarriageProblem();
        boolean expResult = false;
        boolean result = instance.equals(obj);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }


}