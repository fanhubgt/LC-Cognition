/home/appiah/jdk1.6.0_03/bin/java -jar LCConsole.jar 
