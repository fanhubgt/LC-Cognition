/home/appiah/jdk1.6.0_03/bin/java -jar LCLogServer.jar 8110
