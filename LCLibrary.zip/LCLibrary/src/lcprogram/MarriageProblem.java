package lcprogram;

import java.util.ArrayList;

/**
 * The marriage problem class
 * 
 * @author appiah
 */
public class MarriageProblem implements ILCProblem {

    private ArrayList<Sentence> sentences = new ArrayList<Sentence>();
    private int problemSize = 5;
    private Sentence sentence;
    private int domainClass;

    public MarriageProblem() {
    }

    public MarriageProblem(ArrayList<Sentence> sentences) {
        this.sentences = sentences;
    }

    public int getProblemSize() {
        return problemSize;
    }

    public void setProblemSize(int problemSize) {
        this.problemSize = problemSize;
    }

    public ArrayList<Sentence> getSentences() {
        return this.sentences;
    }

    public void setSentences(ArrayList<Sentence> sentences) {
        this.sentences = sentences;
    }

    public void addSentence(Sentence se) {
        getSentences().add(se);
    }

    public void reSentence(Sentence se) {
        getSentences().remove(se);
    }

    @Override
    public String toString() {
        return sentence.toString() + ":" + problemSize;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final MarriageProblem other = (MarriageProblem) obj;
        if (this.problemSize != other.problemSize) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 59 * hash + (this.sentence != null ? this.sentence.hashCode() : 0);
        return hash;
    }

    public void clearMPSentinels() {
        sentences = new ArrayList<Sentence>();
    }

    public void setDomainClass(int classic) {
        this.domainClass = classic;
    }

    public int getDomainClass() {
        return this.domainClass;
    }
}
