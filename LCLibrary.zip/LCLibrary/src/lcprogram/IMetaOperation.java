/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lcprogram;

/**
 *
 * @author appiah
 */
public interface IMetaOperation {

    String getOperation();

    int getResults();

    String getSentisummer();

    String getSymbols();

    void setOperation(String operation);

    void setResults(int results);

    void setSentisummer(String sentisummer);

    void setSymbols(String symbols);

}
