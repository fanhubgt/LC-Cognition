package lcprogram.optimal;

import lcprogram.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author appiah
 */
public class CuttingStrategy implements ICuttingStrategy {

    ILCProgram program;
    public static int max_6 = 6;
    public static int max_5 = 5;
    private Sentence degreeSentence = new Sentence();
    private int problemClass = 0;
    private int sentinelNumber = 0;
    private int minValue = 0;
    private int maxValue = 0;

    public CuttingStrategy() {
    }

    public CuttingStrategy(ILCProgram program) {
        this.program = program;
    }

    public int residue(int size, int n) {
        return (int) (program.numberOrder(size) % n);
    }

    public List<Integer> residue(List<Integer> sizevalues, int n) {
        List<Integer> residues = new ArrayList<Integer>();
        List<Integer> allSizeValues = new ArrayList<Integer>();
        if (sizevalues != null) {
            allSizeValues = sizevalues;
        }
        copyList(allSizeValues(), allSizeValues);
        for (Integer value : allSizeValues) {
            residues.add(new Integer(residue(value, n)));
        }
        return residues;
    }

    public List<Integer> sentinelResidue(List<Integer> sizevalues, int n, int sentinelNo) {
        List<Integer> residues = new ArrayList<Integer>();
        List<Integer> allSizeValues = new ArrayList<Integer>();
        if (sizevalues != null) {
            allSizeValues = sizevalues;
        }
        setSentinelNumber(sentinelNo);
        copyList(allSizeValues(sentinelNo), allSizeValues);
        for (Integer value : allSizeValues) {
            residues.add(new Integer(residue(value, n)));
        }
        return residues;
    }

    public void setMinValue(int minValue) {
        this.minValue = minValue;
    }

    public void setMaxValue(int maxValue) {
        this.maxValue = maxValue;
    }

    public int getMaxValue() {
        return maxValue;
    }

    public int getMinValue() {
        return minValue;
    }

    public void setSentinelNumber(int sentinelNumber) {
        this.sentinelNumber = sentinelNumber;
    }

    public void setProblemClass(int problemClass) {
        this.problemClass = problemClass;
    }

    public int getSentinelNumber() {
        return sentinelNumber;
    }

    public int getProblemClass() {
        return problemClass;
    }

    public int min_value(List<Integer> sizevalues, int sentinelNo) {
        List<Integer> allvalues = new ArrayList<Integer>();
        if (sizevalues != null) {
            allvalues = sizevalues;
        }
        setSentinelNumber(sentinelNo);
        copyList(allSizeValues(sentinelNo), allvalues);
        return program.minimum(allvalues);
    }

    public int min_value(List<Integer> sizevalues) {
        List<Integer> allvalues = new ArrayList<Integer>();
        if (sizevalues != null) {
            allvalues = sizevalues;
        }
        copyList(allSizeValues(), allvalues);
        return program.minimum(allvalues);
    }

    public int max_value(List<Integer> sizevalues) {
        List<Integer> allvalues = new ArrayList<Integer>();
        if (sizevalues != null) {
            allvalues = sizevalues;
        }
        copyList(allSizeValues(), allvalues);
        return program.maximum(allvalues);
    }

    private List<Integer> allSizeValues(int sentinelNo) {
        List<Integer> allvalues = new ArrayList<Integer>();
        ILCProblem problem = ProblemFactory.getBodyClass();
        ILCProblem problem1 = ProblemFactory.getSocialClass();
        ILCProblem problem2 = ProblemFactory.getIntercourseClass();
        ILCProblem problem3 = ProblemFactory.getFamilyClass();
        ILCProblem problem4 = ProblemFactory.getSchoolClass();
        ILCProblem problem5 = ProblemFactory.getNaturalClass();
        ILCProblem problem6 = ProblemFactory.getUserClass();
        setSentinelNumber(sentinelNo);
        copyList(classSizes(problem.getSentences(), sentinelNo), allvalues);
        copyList(classSizes(problem1.getSentences(), sentinelNo), allvalues);
        copyList(classSizes(problem2.getSentences(), sentinelNo), allvalues);
        copyList(classSizes(problem3.getSentences(), sentinelNo), allvalues);
        copyList(classSizes(problem4.getSentences(), sentinelNo), allvalues);
        copyList(classSizes(problem5.getSentences(), sentinelNo), allvalues);
        copyList(classSizes(problem6.getSentences(), sentinelNo), allvalues);
        return allvalues;
    }

    private List<Integer> allSizeValues() {
        List<Integer> allvalues = new ArrayList<Integer>();
        ILCProblem problem = ProblemFactory.getBodyClass();
        ILCProblem problem1 = ProblemFactory.getSocialClass();
        ILCProblem problem2 = ProblemFactory.getIntercourseClass();
        ILCProblem problem3 = ProblemFactory.getFamilyClass();
        ILCProblem problem4 = ProblemFactory.getSchoolClass();
        ILCProblem problem5 = ProblemFactory.getNaturalClass();
        ILCProblem problem6 = ProblemFactory.getUserClass();

        copyList(classSizes(problem.getSentences()), allvalues);
        copyList(classSizes(problem1.getSentences()), allvalues);
        copyList(classSizes(problem2.getSentences()), allvalues);
        copyList(classSizes(problem3.getSentences()), allvalues);
        copyList(classSizes(problem4.getSentences()), allvalues);
        copyList(classSizes(problem5.getSentences()), allvalues);
        copyList(classSizes(problem6.getSentences()), allvalues);
        return allvalues;
    }

    private List<Integer> classSizes(List<Sentence> sentences, int sentinelNo) {
        List<Integer> values = new ArrayList<Integer>();
        for (Sentence s : sentences) {
            if (sentinelNo == s.getSentinumber()) {
                for (AlphaLabel label : s.getAlphaLabels()) {
                    values.add(label.getSize());
                }
            }
        }
        setSentinelNumber(sentinelNo);
        return values;
    }

    private List<Integer> classSizes(List<Sentence> sentences) {
        List<Integer> values = new ArrayList<Integer>();
        for (Sentence s : sentences) {
            for (AlphaLabel label : s.getAlphaLabels()) {
                values.add(label.getSize());
            }
        }
        return values;
    }

    private List<Integer> copyList(List<Integer> copy, List<Integer> allvalues) {
        List<Integer> returnvalues = allvalues;
        for (Integer value : copy) {
            returnvalues.add(value);
        }
        return returnvalues;
    }

    public int max_value(List<Integer> sizevalues, int sentinelNo) {
        List<Integer> allvalues = new ArrayList<Integer>();
        if (sizevalues != null) {
            allvalues = sizevalues;
        }
        setSentinelNumber(sentinelNo);
        copyList(allSizeValues(sentinelNo), allvalues);
        return program.maximum(allvalues);
    }

    public int min_domain(List<Integer> sizevalues, int domainClass) {
        List<Integer> allvalues = new ArrayList<Integer>();
        if (sizevalues != null) {
            allvalues = sizevalues;
        }
        setProblemClass(domainClass);
        switch (domainClass) {
            case ProblemFactory.bodyCD:
                copyList(classSizes(ProblemFactory.getBodyClass().getSentences()), allvalues);
                return program.minimum(allvalues);
            case ProblemFactory.familyCD:
                copyList(classSizes(ProblemFactory.getFamilyClass().getSentences()), allvalues);
                return program.minimum(allvalues);
            case ProblemFactory.intercourseCD:
                copyList(classSizes(ProblemFactory.getIntercourseClass().getSentences()), allvalues);
                return program.minimum(allvalues);
            case ProblemFactory.naturalCD:
                copyList(classSizes(ProblemFactory.getNaturalClass().getSentences()), allvalues);
                return program.minimum(allvalues);
            case ProblemFactory.schoolCD:
                copyList(classSizes(ProblemFactory.getSchoolClass().getSentences()), allvalues);
                return program.minimum(allvalues);
            case ProblemFactory.socialCD:
                copyList(classSizes(ProblemFactory.getSocialClass().getSentences()), allvalues);
                return program.minimum(allvalues);
            case ProblemFactory.userCD:
                copyList(classSizes(ProblemFactory.getUserClass().getSentences()), allvalues);
                return program.minimum(allvalues);
        }
        return 0;
    }

    public int max_domain(List<Integer> sizevalues, int domainClass) {
        List<Integer> allvalues = new ArrayList<Integer>();
        if (sizevalues != null) {
            allvalues = sizevalues;
        }
        setProblemClass(domainClass);
        switch (domainClass) {
            case ProblemFactory.bodyCD:
                copyList(classSizes(ProblemFactory.getBodyClass().getSentences()), allvalues);
                return program.maximum(allvalues);
            case ProblemFactory.familyCD:
                copyList(classSizes(ProblemFactory.getFamilyClass().getSentences()), allvalues);
                return program.maximum(allvalues);
            case ProblemFactory.intercourseCD:
                copyList(classSizes(ProblemFactory.getIntercourseClass().getSentences()), allvalues);
                return program.maximum(allvalues);
            case ProblemFactory.naturalCD:
                copyList(classSizes(ProblemFactory.getNaturalClass().getSentences()), allvalues);
                return program.maximum(allvalues);
            case ProblemFactory.schoolCD:
                copyList(classSizes(ProblemFactory.getSchoolClass().getSentences()), allvalues);
                return program.maximum(allvalues);
            case ProblemFactory.socialCD:
                copyList(classSizes(ProblemFactory.getSocialClass().getSentences()), allvalues);
                return program.maximum(allvalues);
            case ProblemFactory.userCD:
                copyList(classSizes(ProblemFactory.getUserClass().getSentences()), allvalues);
                return program.maximum(allvalues);
        }
        return 0;
    }

    public int min_min_domain(List<Integer> sizevalues, int domainClass, int sentinelNo, int min) {
        List<Integer> allvalues = new ArrayList<Integer>();
        if (sizevalues != null) {
            allvalues = sizevalues;
        }
        setMinValue(min);
        setSentinelNumber(sentinelNo);
        setProblemClass(domainClass);
        switch (domainClass) {
            case ProblemFactory.bodyCD:
                copyList(classSizes(ProblemFactory.getBodyClass().getSentences(), sentinelNo), allvalues);
                return program.minimum(minSizes(allvalues, minValue));
            case ProblemFactory.familyCD:
                copyList(classSizes(ProblemFactory.getFamilyClass().getSentences(), sentinelNo), allvalues);
                return program.minimum(minSizes(allvalues, minValue));
            case ProblemFactory.intercourseCD:
                copyList(classSizes(ProblemFactory.getIntercourseClass().getSentences(), sentinelNo), allvalues);
                return program.minimum(minSizes(allvalues, minValue));
            case ProblemFactory.naturalCD:
                copyList(classSizes(ProblemFactory.getNaturalClass().getSentences(), sentinelNo), allvalues);
                return program.minimum(minSizes(allvalues, minValue));
            case ProblemFactory.schoolCD:
                copyList(classSizes(ProblemFactory.getSchoolClass().getSentences(), sentinelNo), allvalues);
                return program.minimum(minSizes(allvalues, minValue));
            case ProblemFactory.socialCD:
                copyList(classSizes(ProblemFactory.getSchoolClass().getSentences(), sentinelNo), allvalues);
                return program.minimum(minSizes(allvalues, minValue));
            case ProblemFactory.userCD:
                copyList(classSizes(ProblemFactory.getUserClass().getSentences(), sentinelNo), allvalues);
                return program.minimum(minSizes(allvalues, minValue));
        }
        return 0;
    }

    public int max_max_domain(List<Integer> sizevalues, int domainClass, int sentinelNo, int max) {
        List<Integer> allvalues = new ArrayList<Integer>();
        if (sizevalues != null) {
            allvalues = sizevalues;
        }
        setMaxValue(max);
        setSentinelNumber(sentinelNo);
        setProblemClass(domainClass);

        switch (domainClass) {
            case ProblemFactory.bodyCD:
                copyList(classSizes(ProblemFactory.getBodyClass().getSentences(), sentinelNo), allvalues);
                return program.maximum(maxSizes(allvalues, max));
            case ProblemFactory.familyCD:
                copyList(classSizes(ProblemFactory.getFamilyClass().getSentences(), sentinelNo), allvalues);
                return program.maximum(maxSizes(allvalues, max));
            case ProblemFactory.intercourseCD:
                copyList(classSizes(ProblemFactory.getIntercourseClass().getSentences(), sentinelNo), allvalues);
                return program.maximum(maxSizes(allvalues, max));
            case ProblemFactory.naturalCD:
                copyList(classSizes(ProblemFactory.getNaturalClass().getSentences(), sentinelNo), allvalues);
                return program.maximum(maxSizes(allvalues, max));
            case ProblemFactory.schoolCD:
                copyList(classSizes(ProblemFactory.getSchoolClass().getSentences(), sentinelNo), allvalues);
                return program.maximum(maxSizes(allvalues, max));
            case ProblemFactory.socialCD:
                copyList(classSizes(ProblemFactory.getSchoolClass().getSentences(), sentinelNo), allvalues);
                return program.maximum(maxSizes(allvalues, max));
            case ProblemFactory.userCD:
                copyList(classSizes(ProblemFactory.getUserClass().getSentences(), sentinelNo), allvalues);
                return program.maximum(maxSizes(allvalues, max));
        }
        return 0;
    }

    public List<Integer> maxSizes(List<Integer> sizes, int maxValue) {
        List<Integer> mSizes = new ArrayList<Integer>();
        if (sizes != null) {
            for (Integer i : sizes) {
                if (i >= maxValue) {
                    mSizes.add(i);
                }
            }
        }
        return mSizes;
    }

    public List<Integer> minSizes(List<Integer> sizes, int minValue) {
        List<Integer> mSizes = new ArrayList<Integer>();
        if (sizes != null) {
            for (Integer i : sizes) {
                if (i <= minValue) {
                    mSizes.add(i);
                }
            }
        }
        return mSizes;
    }

    public int[] random(List<Integer> sizevalues, int domainClass) {
        Random r = new Random(1);

        int max = 0;
        if (domainClass == ProblemFactory.socialCD) {
            max = max_domain(sizevalues, domainClass);
            max = max_max_domain(sizevalues, domainClass, r.nextInt(max_5), max);
        } else {
            max = max_domain(sizevalues, domainClass);
            max = max_max_domain(sizevalues, domainClass, r.nextInt(max_6), max);
        }
        int min = 0;
        if (domainClass == ProblemFactory.socialCD) {
            min = min_domain(sizevalues, domainClass);
            min = min_min_domain(sizevalues, domainClass, r.nextInt(max_5), min);
        } else {
            min = min_domain(sizevalues, domainClass);
            min = min_min_domain(sizevalues, domainClass, r.nextInt(max_6), min);
        }
        int[] results = {min, max};
        return results;
    }

    public int randomMin(int[] sizevalues, int sentinelNo) {
        Random r = new Random(1);
        int min = 0;
        List<Integer> allvalues = new ArrayList<Integer>();
        if (sizevalues != null) {
            for (int i = 0; i < sizevalues.length; i++) {
                allvalues.add(sizevalues[i]);
            }
        }
        int randDomainClass = r.nextInt(6);
        if (randDomainClass == 1 && sentinelNo > 5) {
            min = min_domain(allvalues, randDomainClass);
            min = min_min_domain(allvalues, randDomainClass, 5, min);
        } else {
            min = min_domain(allvalues, randDomainClass);
            min = min_min_domain(allvalues, randDomainClass, sentinelNo, min);
        }
        return min;
    }

    public int randomMax(int[] sizevalues, int sentinelNo) {
        Random r = new Random(1);
        int max = 0;
        List<Integer> allvalues = new ArrayList<Integer>();
        if (sizevalues != null) {
            for (int i = 0; i < sizevalues.length; i++) {
                allvalues.add(sizevalues[i]);
            }
        }
        int randDomainClass = r.nextInt(6);
        if (randDomainClass == 1 && sentinelNo > 5) {
            max = max_domain(allvalues, randDomainClass);
            max = max_max_domain(allvalues, randDomainClass, 5, max);
        } else {
            max = max_domain(allvalues, randDomainClass);
            max = max_max_domain(allvalues, randDomainClass, sentinelNo, max);
        }
        return max;
    }

    public int min_domain_max_degree(int[] sizevalues, int domainClass) {
        List<Integer> allvalues = new ArrayList<Integer>();
        if (sizevalues != null) {
            for (int i = 0; i < sizevalues.length; i++) {
                allvalues.add(sizevalues[i]);
            }
        }
        int maxDeg = max_domain(allvalues, domainClass);
        Sentence sDeg = new Sentence();
        ILCProblem p;
        switch (domainClass) {
            case ProblemFactory.bodyCD:
                p = ProblemFactory.getBodyClass();
                sDeg = sentenceDegree(p.getSentences(), maxDeg);
                break;
            case ProblemFactory.familyCD:
                p = ProblemFactory.getFamilyClass();
                sDeg = sentenceDegree(p.getSentences(), maxDeg);
                break;
            case ProblemFactory.intercourseCD:
                p = ProblemFactory.getIntercourseClass();
                sDeg = sentenceDegree(p.getSentences(), maxDeg);
                break;
            case ProblemFactory.schoolCD:
                p = ProblemFactory.getSchoolClass();
                sDeg = sentenceDegree(p.getSentences(), maxDeg);
                break;
            case ProblemFactory.socialCD:
                p = ProblemFactory.getSocialClass();
                sDeg = sentenceDegree(p.getSentences(), maxDeg);
                break;
            case ProblemFactory.naturalCD:
                p = ProblemFactory.getNaturalClass();
                sDeg = sentenceDegree(p.getSentences(), maxDeg);
                break;
            case ProblemFactory.userCD:
                p = ProblemFactory.getUserClass();
                sDeg = sentenceDegree(p.getSentences(), maxDeg);
                break;
        }
        setDegreeSentence(sDeg);
        allvalues = program.sentenceSizes(sDeg);
        return min_value(allvalues);
    }

    private Sentence sentenceDegree(List<Sentence> ss, int maxDeg) {
        Sentence sDeg = null;
        for (Sentence s : ss) {
            for (AlphaLabel l : s.getAlphaLabels()) {
                if (maxDeg == l.getSize()) {
                    sDeg = s;
                    break;
                }
            }
        }
        return sDeg;
    }

    public int max_domain_min_degree(int[] sizevalues, int domainClass) {
        List<Integer> allvalues = new ArrayList<Integer>();
        if (sizevalues != null) {
            for (int i = 0; i < sizevalues.length; i++) {
                allvalues.add(sizevalues[i]);

            }
        }
        int minDeg = min_domain(allvalues, domainClass);
        Sentence sDeg = new Sentence();
        ILCProblem p;
        switch (domainClass) {
            case ProblemFactory.bodyCD:
                p = ProblemFactory.getBodyClass();
                sDeg = sentenceDegree(p.getSentences(), minDeg);
                break;
            case ProblemFactory.familyCD:
                p = ProblemFactory.getFamilyClass();
                sDeg = sentenceDegree(p.getSentences(), minDeg);
                break;
            case ProblemFactory.intercourseCD:
                p = ProblemFactory.getIntercourseClass();
                sDeg = sentenceDegree(p.getSentences(), minDeg);
                break;
            case ProblemFactory.schoolCD:
                p = ProblemFactory.getSchoolClass();
                sDeg = sentenceDegree(p.getSentences(), minDeg);
                break;
            case ProblemFactory.socialCD:
                p = ProblemFactory.getSocialClass();
                sDeg = sentenceDegree(p.getSentences(), minDeg);
                break;
            case ProblemFactory.naturalCD:
                p = ProblemFactory.getNaturalClass();
                sDeg = sentenceDegree(p.getSentences(), minDeg);
                break;
            case ProblemFactory.userCD:
                p = ProblemFactory.getUserClass();
                sDeg = sentenceDegree(p.getSentences(), minDeg);
                break;
        }
        setDegreeSentence(sDeg);
        allvalues = program.sentenceSizes(sDeg);
        return max_value(allvalues);
    }

    public int min_domain_over_degree(int[] sizevalues, int domainClass) {
        List<Integer> allvalues = new ArrayList<Integer>();
        if (sizevalues != null) {
            for (int i = 0; i < sizevalues.length; i++) {
                allvalues.add(sizevalues[i]);
            }
        }
        Sentence sDeg = new Sentence();
        ILCProblem p;
        switch (domainClass) {
            case ProblemFactory.bodyCD:
                p = ProblemFactory.getBodyClass();
                sDeg = sentenceOverMaxDegree(p.getSentences());
                break;
            case ProblemFactory.familyCD:
                p = ProblemFactory.getFamilyClass();
                sDeg = sentenceOverMaxDegree(p.getSentences());
                break;
            case ProblemFactory.intercourseCD:
                p = ProblemFactory.getIntercourseClass();
                sDeg = sentenceOverMaxDegree(p.getSentences());
                break;
            case ProblemFactory.schoolCD:
                p = ProblemFactory.getSchoolClass();
                sDeg = sentenceOverMaxDegree(p.getSentences());
                break;
            case ProblemFactory.socialCD:
                p = ProblemFactory.getSocialClass();
                sDeg = sentenceOverMaxDegree(p.getSentences());
                break;
            case ProblemFactory.naturalCD:
                p = ProblemFactory.getNaturalClass();
                sDeg = sentenceOverMaxDegree(p.getSentences());
                break;
            case ProblemFactory.userCD:
                p = ProblemFactory.getUserClass();
                sDeg = sentenceOverMaxDegree(p.getSentences());
                break;
        }
        setDegreeSentence(sDeg);
        copyList(program.sentenceSizes(sDeg), allvalues);
        return min_value(allvalues);
    }

    private Sentence sentenceOverMaxDegree(List<Sentence> ss) {
        Sentence sod = new Sentence();
        sod = ss.get(0);
        int maxCount = ss.get(0).getCount();
        for (int i = 0; i < ss.size(); i++) {
            if (maxCount > ss.get(i).getCount()) {
                continue;
            } else {
                sod = ss.get(i);
            }
        }
        return sod;
    }

    private Sentence sentenceOverMinDegree(List<Sentence> ss) {
        Sentence sod = new Sentence();
        sod = ss.get(0);
        int minCount = ss.get(0).getCount();
        for (int i = 0; i < ss.size(); i++) {
            if (minCount < ss.get(i).getCount()) {
                continue;
            } else {
                sod = ss.get(i);
            }
        }
        return sod;
    }

    public int max_domain_over_degree(int[] sizevalues, int domainClass) {
        List<Integer> allvalues = new ArrayList<Integer>();
        if (sizevalues != null) {
            for (int i = 0; i < sizevalues.length; i++) {
                allvalues.add(sizevalues[i]);
            }
        }
        Sentence sDeg = new Sentence();
        ILCProblem p;
        switch (domainClass) {
            case ProblemFactory.bodyCD:
                p = ProblemFactory.getBodyClass();
                sDeg = sentenceOverMinDegree(p.getSentences());
                break;
            case ProblemFactory.familyCD:
                p = ProblemFactory.getFamilyClass();
                sDeg = sentenceOverMinDegree(p.getSentences());
                break;
            case ProblemFactory.intercourseCD:
                p = ProblemFactory.getIntercourseClass();
                sDeg = sentenceOverMinDegree(p.getSentences());
                break;
            case ProblemFactory.schoolCD:
                p = ProblemFactory.getSchoolClass();
                sDeg = sentenceOverMinDegree(p.getSentences());
                break;
            case ProblemFactory.socialCD:
                p = ProblemFactory.getSocialClass();
                sDeg = sentenceOverMinDegree(p.getSentences());
                break;
            case ProblemFactory.naturalCD:
                p = ProblemFactory.getNaturalClass();
                sDeg = sentenceOverMinDegree(p.getSentences());
                break;
            case ProblemFactory.userCD:
                p = ProblemFactory.getUserClass();
                sDeg = sentenceOverMinDegree(p.getSentences());
                break;
        }
        setDegreeSentence(sDeg);
        copyList(program.sentenceSizes(sDeg), allvalues);
        return max_value(allvalues);
    }

    public int[] max_degree(int[] sizevalues, int sentinelNo) {
        List<Integer> allvalues = new ArrayList<Integer>();
        if (sizevalues != null) {
            for (int i = 0; i < sizevalues.length; i++) {
                allvalues.add(sizevalues[i]);
            }
        }
        copyList(allSizeValues(sentinelNo), allvalues);
        int maxDeg = max_value(allvalues);
        Sentence sDeg = new Sentence();
        sDeg = sentenceDegree(ProblemFactory.getSentenceClasses(), maxDeg);
        allvalues = new ArrayList<Integer>();
        copyList(program.sentenceSizes(sDeg), allvalues);
        int min = program.minimum(allvalues);
        int max = program.maximum(allvalues);
        int[] results = {min, max};

        return results;
    }

    public int[] min_degree(int[] sizevalues, int sentinelNo) {
        List<Integer> allvalues = new ArrayList<Integer>();
        if (sizevalues != null) {
            for (int i = 0; i < sizevalues.length; i++) {
                allvalues.add(sizevalues[i]);
            }
        }
        copyList(allSizeValues(sentinelNo), allvalues);
        int minDeg = min_value(allvalues);
        Sentence sDeg = new Sentence();
        sDeg = sentenceDegree(ProblemFactory.getSentenceClasses(), minDeg);
        allvalues = new ArrayList<Integer>();
        copyList(program.sentenceSizes(sDeg), allvalues);
        int min = program.minimum(allvalues);
        int max = program.maximum(allvalues);
        int[] results = {min, max};

        return results;
    }

    public int min_max_alternate(int[] sizevalues, int sentinelNo, boolean maxEnabled) {
        List<Integer> allvalues = new ArrayList<Integer>();
        if (sizevalues != null) {
            for (int i = 0; i < sizevalues.length; i++) {
                allvalues.add(sizevalues[i]);
            }
        }
        copyList(allSizeValues(sentinelNo), allvalues);
        int maxDeg = max_value(allvalues);
        Sentence sDeg = new Sentence();
        sDeg = sentenceDegree(ProblemFactory.getSentenceClasses(), maxDeg);
        allvalues = new ArrayList<Integer>();
        copyList(program.sentenceSizes(sDeg), allvalues);
        int min = program.minimum(allvalues);
        int max = program.maximum(allvalues);
        int results = maxEnabled ? max : min;

        return results;
    }

    public int minmax_alternate(int[] sizevalues, int domainClass, boolean maxEnabled) {
        List<Integer> allvalues = new ArrayList<Integer>();
        if (sizevalues != null) {
            for (int i = 0; i < sizevalues.length; i++) {
                allvalues.add(sizevalues[i]);
            }
        }
        copyList(allSizeValues(), allvalues);
        int maxDeg = max_value(allvalues);
        Sentence sDeg = new Sentence();
        ILCProblem p;

        switch (domainClass) {
            case ProblemFactory.bodyCD:
                p = ProblemFactory.getBodyClass();
                sDeg = sentenceDegree(p.getSentences(), maxDeg);
                break;
            case ProblemFactory.familyCD:
                p = ProblemFactory.getFamilyClass();
                sDeg = sentenceDegree(p.getSentences(), maxDeg);
                break;
            case ProblemFactory.intercourseCD:
                p = ProblemFactory.getIntercourseClass();
                sDeg = sentenceDegree(p.getSentences(), maxDeg);
                break;
            case ProblemFactory.schoolCD:
                p = ProblemFactory.getSchoolClass();
                sDeg = sentenceDegree(p.getSentences(), maxDeg);
                break;
            case ProblemFactory.socialCD:
                p = ProblemFactory.getSocialClass();
                sDeg = sentenceDegree(p.getSentences(), maxDeg);
                break;
            case ProblemFactory.naturalCD:
                p = ProblemFactory.getNaturalClass();
                sDeg = sentenceDegree(p.getSentences(), maxDeg);
                break;
            case ProblemFactory.userCD:
                p = ProblemFactory.getUserClass();
                sDeg = sentenceDegree(p.getSentences(), maxDeg);
                break;
        }
        setDegreeSentence(sDeg);
        allvalues = new ArrayList<Integer>();
        copyList(program.sentenceSizes(sDeg), allvalues);
        int results = 0;
        if (allvalues.size() >0) {
            int min = program.minimum(allvalues);
            int max = program.maximum(allvalues);
            results = maxEnabled ? max : min;
        }
        return results;
    }

    public double median_domain(int[] sizesvalues, int domainclass) {

        List<Integer> allvalues = new ArrayList<Integer>();
        if (sizesvalues != null) {
            for (int i = 0; i < sizesvalues.length; i++) {
                allvalues.add(sizesvalues[i]);
            }
        }
        ILCProblem p;
        switch (domainclass) {
            case ProblemFactory.bodyCD:
                p = ProblemFactory.getBodyClass();
                copyList(getSizes(p.getSentences()), allvalues);
                break;
            case ProblemFactory.familyCD:
                p = ProblemFactory.getFamilyClass();
                copyList(getSizes(p.getSentences()), allvalues);
                break;
            case ProblemFactory.intercourseCD:
                p = ProblemFactory.getIntercourseClass();
                copyList(getSizes(p.getSentences()), allvalues);
                break;
            case ProblemFactory.schoolCD:
                p = ProblemFactory.getSchoolClass();
                copyList(getSizes(p.getSentences()), allvalues);
                break;
            case ProblemFactory.socialCD:
                p = ProblemFactory.getSocialClass();
                copyList(getSizes(p.getSentences()), allvalues);
                break;
            case ProblemFactory.naturalCD:
                p = ProblemFactory.getNaturalClass();
                copyList(getSizes(p.getSentences()), allvalues);
                break;
            case ProblemFactory.userCD:
                p = ProblemFactory.getUserClass();
                copyList(getSizes(p.getSentences()), allvalues);
                break;
        }
        return median(allvalues.toArray(new Integer[0]));
    }

    public List<Integer> getSizes(List<Sentence> sens) {
        List<Integer> sizes = new ArrayList<Integer>();
        for (Sentence s : sens) {
            for (AlphaLabel l : s.getAlphaLabels()) {
                sizes.add(l.getSize());
            }
        }
        return sizes;
    }

    public double median(Integer[] values) {
        double med = 1.0;
        int sum = 0;
        for (int i = 0; i < values.length; i++) {
            sum += values[i].intValue();
        }
        med = sum / values.length;
        return med;
    }

    public double median(int[] sizevalues, int sentinelNo) {
        List<Integer> allvalues = new ArrayList<Integer>();
        if (sizevalues != null) {
            for (int i = 0; i < sizevalues.length; i++) {
                allvalues.add(sizevalues[i]);
            }
        }
        copyList(allSizeValues(sentinelNo), allvalues);
        return median(allvalues.toArray(new Integer[0]));
    }

    public int max_regret(int[] sizesvalue, int[] sentinels, int domainClass) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public int max_impact(int[] sizesvalue, int[] sentinels, int domainClass) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public int min_domain_random(int[] sizesvalue, int domainClass) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public int max_domain_random(int[] sizesvalue, int domainClass) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public int[] all_interval_seriesD(int[] sizesvalue, int domainClass) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public int[] all_interval_seriesDN(int[] sizesvalue, int domainClass, int sentinelNo) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public int[] all_interval_seriesS(int[] sizesvalue, int sentinelNo) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Sentence getDegreeSentence() {
        return degreeSentence;
    }

    public void setDegreeSentence(Sentence degreeSentence) {
        this.degreeSentence = degreeSentence;
    }
    
}
