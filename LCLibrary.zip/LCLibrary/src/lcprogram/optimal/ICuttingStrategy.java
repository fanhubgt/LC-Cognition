package lcprogram.optimal;

import java.util.List;

/**
 * It is an optimize search global/local method used in describing sizes
 * of words in a sentence to help the user create a new
 * word of similar size.
 * 
 * @author appiah
 */
public interface ICuttingStrategy {

    /**
     * It returns the remainder of sizes as residues
     * @param size Size used in the modulo computation
     * @param n Number used to divide the size.
     * @return Remainder of size after size % n.
     */
    public int residue(int size, int n);

    /**
     * It returns a list of remainder of sizes as residues
     * @param sizevalues Sizes used in the modulo computation
     * @param n Number used to divide the size.
     * @return Remainder of sizes after size % n.
     */
    public List<Integer> residue(List<Integer> sizevalues, int n);

    /**
     * It returns the minimum value from a list.
     * @param sizevalues List of sizes
     * @param sentinelNo Number of sentence in a problem.
     * @return Minimum value from a list.
     */
    public int min_value(List<Integer> sizevalues, int sentinelNo);

    /**
     * It returns the maximum value from a list.
     * @param sizevalues List of sizes
     * @param sentinelNo Number of sentence in a problem.
     * @return Maximum value in the list
     */
    public int max_value(List<Integer> sizevalues, int sentinelNo);

    /**
     * It returns the minimum value from a domain sentence.
     * @param sizevalues  List of sizes for a sentence.
     * @param domainClass Problem class for a domain.
     * @return Minimum value in the size list.
     */
    public int min_domain(List<Integer> sizevalues, int domainClass);

    /**
     * It returns the maximum value from a domain sentence.
     * @param sizevalues List of sizes for a sentence.
     * @param domainClass Problem class for a domain.
     * @return Maximum value in the list of any sentence.
     */
    public int max_domain(List<Integer> sizevalues, int domainClass);

    /**
     * It returns the minimum value from a domain sentence in a problem class 
     * of minimum count.
     * @param sizevalues List of sizes for a minimum domain sentence.
     * @param domainClass Problem class for a domain.
     * @param sentinelNo Sentence number for the problem class.
     * @return Minimum value in the size list of a smaller count.
     */
    public int min_min_domain(List<Integer> sizevalues, int domainClass, int sentinelNo, int min);

    /**
     * It returns the maximum value from a domain sentence in a problem class
     * of maximum count.
     * @param sizevalues List of sizes for a maximum domain sentence.
     * @param domainClass Problem class for a domain.
     * @param sentinelNo Sentence number for the problem class.
     * @return Maximum value in the size list of a larger count.
     */
    public int max_max_domain(List<Integer> sizevalues, int domainClass, int sentinelNo, int max);

    /**
     * It returns the max and min values from a domain class without 
     * any sentinel number. It checks all sentences in a domain class of
     * problem at random.
     * .
     * @param sizevalues List of sizes for a maximum domain sentence.
     * @param domainClass Problem class for a domain.
     * @return Min and max values in the size of a domain class.
     */
    public int[] random(List<Integer> sizevalues, int domainClass);

    /**
     * It returns a random min value from a set of problem classes with 
     * a specified sentinel number for each class.
     * @param sizevalues List of sizes for a maximum domain sentence.
     * @param sentinelNo Sentence number for the problem class.
     * @return Minimum value in the size of a domain sentence.
     */
    public int randomMin(int[] sizevalues, int sentinelNo);

    /**
     * It returns a random max value from a set of problem classes with 
     * a specified sentinel number for each class.
     * @param sizevalues List of sizes for a maximum domain sentence.
     * @param sentinelNo Sentence number for the problem class.
     * @return Maximum value in the size of a domain sentence.
     */
    public int randomMax(int[] sizevalues, int sentinelNo);

    /**
     * It returns the min value from a maximum sizes of a sentence from
     * a specified domain class.
     * @param sizevalues List of sizes for a maximum domain sentence.
     * @param domainClass Problem class for a domain.
     * @return Minimum value in the size.
     */
    public int min_domain_max_degree(int[] sizevalues, int domainClass);

    /**
     * It returns the max value from a minimum sizes of a sentence from
     * a specified domain class.
     * @param sizevalues List of sizes for a maximum domain sentence.
     * @param domainClass Problem class for a domain.
     * @return Max value in the size.
     */
    public int max_domain_min_degree(int[] sizevalues, int domainClass);

    /**
     * It returns the min value from a maximum count of a sentence from
     * a specified domain class.
     * @param sizevalues List of sizes for a maximum domain sentence.
     * @param domainClass Problem class for a domain.
     * @return Minimum value in the size.
     */
    public int min_domain_over_degree(int[] sizevalues, int domainClass);

    /**
     * It returns the max value from a minimum count of a sentence from
     * a specified domain class.
     * @param sizevalues List of sizes for a maximum domain sentence.
     * @param domainClass Problem class for a domain.
     * @return Max value in the size.
     */
    public int max_domain_over_degree(int[] sizevalues, int domainClass);

    /**
     * It returns the min and max degree from a maximum sizes of a sentence from
     * a specified domain class.
     * @param sizevalues List of sizes for a maximum domain sentence.
     * @param sentinelNo The number of sentence to use.
     * @return Max and min value in the size or sentinel no of a sentence.
     */
    public int[] max_degree(int[] sizevalues, int sentinelNo);

    /**
     * It returns the min and max degree from a minimum sizes of a sentence from
     * a specified domain class.
     * @param sizevalues List of sizes for a maximum domain sentence.
     * @param sentinelNo The number of sentence to use.
     * @return Max and min value in the size or sentinel no of a sentence.
     */
    public int[] min_degree(int[] sizevalues, int sentinelNo);

    /**
     * It returns the min or max value from a maximum or minimum sizes of a sentence from
     * a specified sentinel number.
     * @param sizevalues List of sizes for a min/max domain sentence.
     * @param sentinelNo The number of sentence to use.
     * @return Max and min value in the size or sentinel no of a sentence.
     */
    public int min_max_alternate(int[] sizevalues, int sentinelNo, boolean maxEnabled);

    /**
     * It returns the min or max value from a maximum or minimum sizes of a sentence from
     * a specified domain class.
     * @param sizevalues List of sizes for a min/max domain sentence.
     * @param domainClass Problem class for a domain.
     * * @param maxEnabled This enables a maximum return and mx size usage in search.
     * @return Max or min value in the size or domain sentence.
     */
    public int minmax_alternate(int[] sizevalues, int domainClass, boolean maxEnabled);

    /**
     * It returns the median of a domain class 
     * known to the sentence system.
     * @param sizesvalues List of sizes for a min/max domain sentence.
     * @param domainclass  Problem class for a domain.
     * @return Median value of a sentinel number.
     */
    public double median_domain(int[] sizesvalues, int domainclass);

    /**
     * It returns the median of a sentinel number for all domain classes
     * known to the sentence system.
     * @param sizesvalues List of sizes for a min/max domain sentence.
     * @param sentinelNo The number of sentence to use.
     * @return Median value of a sentinel number.
     */
    public double median(int[] sizesvalues, int sentinelNo);

    /**
     * It returns the max of regret sentinel numbers like a sentence with 
     * 'not', 'without', 'no', etc.
     * @param sizesvalues List of sizes 
     * @param sentinels Regret sentinel numbers.
     * @param domainClass Problem class for a domain.
     * @return Max value in the size list.
     */
    public int max_regret(int[] sizesvalue, int[] sentinels, int domainClass);

    /**
     * It returns the max of impact sentinel numbers like a sentence that does not
     * use 'not', 'without', 'no', etc.
     * @param sizesvalues List of sizes 
     * @param sentinels Impact sentinel numbers.
     * @param domainClass Problem class for a domain.
     * @return Max value in the size list.
     */
    public int max_impact(int[] sizesvalue, int[] sentinels, int domainClass);

    /**
     * It returns the min value from size of a randomized sentence in a
     * particular domain.
     * @param sizesvalue  List of sizes
     * @param domainClass Problem class for a domain.
     * @return  Min value in the size list.
     */
    public int min_domain_random(int[] sizesvalue, int domainClass);

    /**
     * It returns the max value from size of a randomized sentence in a
     * particular domain.
     * @param sizesvalue  List of sizes
     * @param domainClass Problem class for a domain.
     * @return  Max value in the size list.
     */
    public int max_domain_random(int[] sizesvalue, int domainClass);

    /**
     * Given S={s1!, s2!, s3!...sn!) to be sizes permute of each sentence in a domain class
     * , a difference vector, v={|(s2!-s1!)|, |(s3!-s2!|,....(sn+1! - sn!)} is calculated
     * from the 
     * @param sizesvalue List of sizes
     * @param domainClass List of sizes
     * @return An array of difference permutes.
     */
    public int[] all_interval_seriesD(int[] sizesvalue, int domainClass);

    /**
     * Given S={s1!, s2!, s3!...sn!) to be sizes permute of each sentence in a domain class
     * , a difference vector, v={|(s2!-s1!)|, |(s3!-s2!|,....(sn+1! - sn!)} 
     * is calculated.
     * @param sizesvalue List of sizes
     * @param domainClass List of sizes
     * @return An array of difference permutes.
     */
    public int[] all_interval_seriesDN(int[] sizesvalue, int domainClass, int sentinelNo);

    /**
     * Given S={s1!, s2!, s3!...sn!) to be sizes permute of each sentence in a domain class
     * , a difference vector, v={|(s2!-s1!)|, |(s3!-s2!|,....(sn+1! - sn!)} is calculated.
     * @param sizesvalue List of sizes
     * @param domainClass List of sizes
     * @return An array of difference permutes.
     */
    public int[] all_interval_seriesS(int[] sizesvalue, int sentinelNo);
}

