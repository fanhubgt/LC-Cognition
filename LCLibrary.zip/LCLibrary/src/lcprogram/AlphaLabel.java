package lcprogram;

/**
 * This is a word with numberic labelling of index of each alphabet
 * or character. For example,  a word like "damn it".
 * 
 * 1 2 3 4 5 6
 * D a m n i t
 * 
 * @author appiah
 */
public class AlphaLabel implements IAlphaLabel {

    private String word;
    private char letter;
    private int index;
    private int size;
    private int position;

    public AlphaLabel() {
    }

    public AlphaLabel(String word) {
        this.word = word;
    }

    public AlphaLabel(String word, char letter, int index, int size, int position) {
        this.word = word;
        this.letter = letter;
        this.index = index;
        this.size = size;
        this.position = position;
    }

    public AlphaLabel(String word, int index, int position) {
        this.word = word;
        this.index = index;
        this.position = position;
    }

    public char getLetter() {
        return letter;
    }

    public int getIndex() {
        return index;
    }

    public int getPosition() {
        return position;
    }

    public void setLetter(char letter) {
        this.letter = letter;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public AlphaLabel(String word, char letter, int index, int size) {
        this.word = word;
        this.letter = letter;
        this.index = index;
        this.size = size;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public String getWord() {
        return this.word;
    }

    public void setLetter(char letter, int index) {
        this.letter = letter;
        this.index = index;
        char[] wchars = this.word.toCharArray();
        wchars[index] = letter;
        this.word = wchars.toString();
    }

    public char getLetter(int index) {
        return this.word.toCharArray()[index];
    }

    public boolean subsetEquality(int start, int end, String letterSet) {
        String subString = this.word.substring(start, end);
        return subString.equalsIgnoreCase(letterSet);
    }

    public int getSize() {
        return this.size = word.length();
    }

    public void setSize(int size) {
        this.size = size;
    }

    public boolean subsetEquality(int start, int end, char[] letterSet) {
        String subString = this.word.substring(start, end);
        return subString.equalsIgnoreCase(letterSet.toString());
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final AlphaLabel other = (AlphaLabel) obj;
        if (this.word != other.word && (this.word == null || !this.word.equals(other.word))) {
            return false;
        }
        if (this.letter != other.letter) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 67 * hash + this.index;
        hash = 67 * hash + this.size;
        return hash;
    }

    @Override
    public String toString() {
        return this.index+"          "+this.position+"             "+getSize()+"            "+this.word;
    }
    
}
