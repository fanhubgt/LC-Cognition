package lcprogram;

/**
 * @author appiah
 */
public class MetaOperation implements IMetaOperation {

    private String symbols;
    private String sentisummer;
    private int results;
    private String operation;

    public MetaOperation() {
    }

    public MetaOperation(String symbols, String sentisummer, int results, String operation) {
        this.symbols = symbols;
        this.sentisummer = sentisummer;
        this.results = results;
        this.operation = operation;
    }
    
    public MetaOperation(String symbols, int results, String operation) {
        this.symbols = symbols;
        this.results = results;
        this.operation = operation;
    }
 
    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public int getResults() {
        return results;
    }

    public void setResults(int results) {
        this.results = results;
    }

    public String getSentisummer() {
        return sentisummer;
    }

    public void setSentisummer(String sentisummer) {
        this.sentisummer = sentisummer;
    }

    public String getSymbols() {
        return symbols;
    }

    public void setSymbols(String symbols) {
        this.symbols = symbols;
    }

    @Override
    public String toString() {
        return operation+": "+symbols+"("+sentisummer+")="+results;
    }
    
    
    
}
