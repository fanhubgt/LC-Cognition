
package lcprogram;

/**
 * It represents the structure of a character and size 
 * of an alphalabel @see AlphaLabel.
 * 
 * @author appiah
 */
public interface IAlphanumeric {

    char getLetter();

    int getSize();

    void setLetter(char letter);

    void setSize(int size);

}
