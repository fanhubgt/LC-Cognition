
package lcprogram;

/**
 *
 * @author appiah
 */
public class DomainClass {

    public static final int socialCD = 1;
    public static final int familyCD = 2;
    public static final int naturalCD = 3;
    public static final int bodyCD = 4;
    public static final int intercourseCD = 5;
    public static final int schoolCD = 6;
     public static final int userCD = 7;
}
