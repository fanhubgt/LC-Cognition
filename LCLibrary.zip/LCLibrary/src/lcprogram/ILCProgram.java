package lcprogram;

import java.util.HashMap;
import java.util.List;

/**
 * Interface for Letter Combinatorics Program
 * 
 * @author appiah
 */
public interface ILCProgram {

    public int minimum(List<Integer> mpset);

    public int maximum(List<Integer> mpset);

    public long rpermute(int n, int r);

    public long subMPSet();

    public Integer[] getSetValues(int settype);

    public long mulMPSet();

    public List<Integer> sentenceSizes(Sentence s);

    public void partitionBuild(HashMap<Integer, String> par, List<Integer> values, int reducer);

    public float rpermute2(int n, int r);

    public long numberOrder(int n);

    public int addMPSet();

    public HashMap<Integer, String> partitionInteger(int reducer, int type);

    public long count(String sentence);

    public boolean containSet(String sentence, String sentinel);

    public HashMap<Integer, String> pascalTriangle(int reducer, int type);

    public ILCProblem getProblem();

    public void setProblem(ILCProblem problem);

    public int add();

    public int substract();

    public long multiply();

    public int count(Sentence sentence);

    public long rcombinant(int r, int n);

    public List<String> partition();

    public List<Integer> MPSetOrder();

    public int generateFunc(int xvalue);

    public MetaOperation metaOperation(int senpetanace);

    public void MPSentences();

    public List<Integer> MPOrder();

    public int realMP();

    public int addRMP();

    public long mulRMP();

    public long subRMP();

    public List<MetaOperation> getOperations();

    public void metaSententialOperation();

    public void setOperations(List<MetaOperation> operations);

    public List<Integer> LMPSetOrder();

    public List<Integer> RMPSetOrder();

    public int addLMP();

    public long mulLMP();

    public long subLMP();

    public int getEqualityPrincpleCV(int set1, int set2);

    public List<Integer> getEqualityPrincpleValues(int set1, int set2);

    public List<Integer> rcombinant2List(int setType);

    public List<Long> rcombinantList(int setType);

    public List<Integer> rpermute2List(int setType);

    public List<Long> rpermuteList(int setType);

    /**
     * It results to count * e^ (count/limitsize) * numberOrderLimit.
     * The count is the enumeration of a sentence, limitsize=20 
     * and numberOrderLimit has a value for 20!.
     * @return It returns a possible number of order
     */
    public List<String> orderList();

    /**
     * It prints ferrers diagram for MP, MPSet, RMPSet and LMPSet partitions. 
     * @param type Type of Set.
     */
    public void ferrersdiagram(int type);
}
