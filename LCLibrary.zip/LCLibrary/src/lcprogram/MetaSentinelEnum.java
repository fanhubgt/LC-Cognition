/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lcprogram;

/**
 *
 * @author appiah
 */
public class MetaSentinelEnum {

    public static int MetaMPS1 = 1;
    public static int MetaMPS2 = 2;
    public static int REALMP3 = 3;
    public static int MetaMPS4 = 4;
    public static int MetaMPS5 = 5;
    public static int MetaMPS6 = 6;

    public static int MetaMPS1() {
        return MetaMPS1;
    }

    public static int MetaMPS2() {
        return MetaMPS2;
    }

    public static int MetaMPS4() {
        return MetaMPS4;
    }

    public static int MetaMPS5() {
        return MetaMPS5;
    }

    public static int MetaMPS6() {
        return MetaMPS6;
    }

    public static int REALMP3() {
        return REALMP3;
    }
}
