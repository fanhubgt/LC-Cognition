package lcprogram;

import java.util.ArrayList;
import java.util.HashMap;
import static java.lang.System.out;
import static java.lang.System.in;
import java.util.List;
import java.util.Random;
import java.util.StringTokenizer;

/**
 * Implementation of LCProgram.
 * This is a program on letter combinatorics(LC). LC is 
 * about letters or phrases or words  and counting problems.
 * The program describes a java modeling of the concepts
 * of LC including alphanumeric labelling, combinatorial 
 * enumerations, counting methods etc.
 * The theory of example of LC is a Marriage Problem(MP).
 * A marriage problem consists of 5 sentences and has a generating function.
 * 
 * @author appiah
 */
public class LCProgram implements ILCProgram {

    private ILCProblem problem = new MarriageProblem();
    private List<MetaOperation> operations = new ArrayList<MetaOperation>();
    String filename = "sentence.txt";

    public LCProgram() {
    }

    public long count(String sentence) {
        Sentence s = new Sentence(sentence, 1);
        return s.getCount();
    }

    public boolean containSet(String sentence, String sentinel) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public LCProgram(MarriageProblem problem) {
        this.problem = problem;
    }

    public void setProblem(ILCProblem problem) {
        this.problem = problem;
    }

    public ILCProblem getProblem() {
        return this.problem;
    }

    public int add() {
        int sum = 0;
        for (int i = 0; i < problem.getProblemSize(); i++) {
            sum += problem.getSentences().get(i).getCount();
        }
        return sum;
    }

    public int substract() {
        int sub = problem.getSentences().get(4).getCount();
        for (int i = 0; i < problem.getProblemSize() - 1; i++) {
            sub -= problem.getSentences().get(i).getCount();
        }
        return sub;
    }

    public long multiply() {
        int mul = 1;
        for (int i = 0; i < problem.getProblemSize(); i++) {
            mul *= problem.getSentences().get(i).getCount();
        }
        return mul;
    }

    public int realMP() {
        List<Integer> mpset = MPSetOrder();

        int max = maximum(mpset);
        int min = minimum(mpset);

        return (max - min);
    }

    public int maximum(List<Integer> mpset) {
        int max = mpset.get(0);
        for (int i = 0; i < mpset.size(); i++) {
            if (max > mpset.get(i)) {
                continue;
            } else {
                max = mpset.get(i);
            }
        }
        return max;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getFilename() {
        return filename;
    }

    public int minimum(List<Integer> mpset) {
        int min = mpset.get(0);
        for (int i = 0; i < mpset.size(); i++) {
            if (min < mpset.get(i)) {
                continue;
            } else {
                min = mpset.get(i);
            }
        }
        return min;
    }

    public List<Integer> sentenceSizes(Sentence s) {
        List<Integer> sizes = new ArrayList<Integer>();
        if (s != null) {
            for (AlphaLabel l : s.getAlphaLabels()) {
                sizes.add(l.getSize());
            }
        }
        return sizes;
    }

    public int count(Sentence sentence) {
        return sentence.getCount();
    }

    public long rpermute(int n, int r) {
        long p = 1;
        for (int k = 1; k < r; k++) {
            p = (p * (n + 1 - k));
        }
        return p;
    }

    public float rpermute2(int n, int r) {
        float p = 1;
        for (int k = 2; k < n; k++) {
            p = (p * k);
        }
        for (int j = 2; j < (n - r); j++) {
            p = p / j;
        }
        return p;
    }

    public List<Long> rpermuteList(int setType) {
        List<Long> pl = new ArrayList<Long>();
        Integer[] values = getSetValues(setType);

        String vout = "[";
        int n = getSetCount(setType);
        for (int i = 0; i < values.length; i++) {
            Integer r = values[i];
            vout += r.toString();
            String comma = (i < values.length - 1) ? "," : "";
            vout += comma;
            pl.add(rpermute(n, r));
        }
        out.print(vout + "] :=");
        return pl;
    }

    public List<Integer> rpermute2List(int setType) {
        List<Integer> pl = new ArrayList<Integer>();
        Integer[] values = getSetValues(setType);
        int n = getSetCount(setType);
        String v = "[";
        for (int i = 0; i < values.length; i++) {
            Integer r = values[i];
            v += r.toString();
            String comma = (i < values.length - 1) ? "," : "";
            v += comma;
            pl.add(Float.floatToIntBits(rpermute2(n, r)));
        }
        out.print(v + "] :=");
        return pl;
    }

    public List<Long> rcombinantList(int setType) {
        List<Long> pl = new ArrayList<Long>();
        Integer[] values = getSetValues(setType);

        String vout = "[";
        int n = getSetCount(setType);
        for (int i = 0; i < values.length; i++) {
            Integer r = values[i];
            vout += r.toString();
            String comma = (i < values.length - 1) ? "," : "";
            vout += comma;
            pl.add(rcombinant(r, n));
        }
        out.print(vout + "] :=");
        return pl;
    }

    public List<Integer> rcombinant2List(int setType) {
        List<Integer> pl = new ArrayList<Integer>();
        Integer[] values = getSetValues(setType);
        int n = getSetCount(setType);
        String v = "[";
        for (int i = 0; i < values.length; i++) {
            Integer r = values[i];
            v += r.toString();
            String comma = (i < values.length - 1) ? "," : "";
            v += comma;
            pl.add(Float.floatToIntBits(rcombinant(r, n)));
        }
        out.print(v + "] :=");
        return pl;
    }

    public long rcombinant(int r, int n) {
        long rfact = 1;
        for (int i = 1; i <= r; i++) {
            rfact *= i;
        }
        return (rpermute(n, r) / rfact);
    }

    public List<String> partition() {
        List<String> pars = new ArrayList<String>();
        for (int i = 0; i <
                problem.getProblemSize(); i++) {
            pars.add("\nSentence " + (i + 1) + " :" + problem.getSentences().get(i).getPartitions().toString() + "\n");
        }

        return pars;
    }

    public List<Integer> MPOrder() {
        List<Integer> setord = new ArrayList<Integer>();
        for (int i = 0; i <
                problem.getProblemSize(); i++) {
            setord.add(problem.getSentences().get(i).getCount());
        }

        return setord;
    }

    public List<Integer> MPSetOrder() {
        List<Integer> setord = new ArrayList<Integer>();
        for (int i = 0; i <
                problem.getProblemSize(); i++) {
            setord.add(problem.getSentences().get(i).getCount());
        }

        setord.remove(setord.get(2));
        return setord;
    }

    public List<Integer> RMPSetOrder() {
        List<Integer> setord = new ArrayList<Integer>();
        for (int i = 0; i <
                problem.getProblemSize(); i++) {
            setord.add(problem.getSentences().get(i).getCount());
        }

        setord.remove(setord.get(2));
        setord.add(2, new Integer(realMP()));
        return setord;
    }

    public int addRMP() {
        List<Integer> seto = RMPSetOrder();
        int sum = 0;
        for (int i = 0; i <
                seto.size(); i++) {
            sum += seto.get(i);
        }

        return sum;
    }

    public long mulRMP() {
        List<Integer> seto = RMPSetOrder();
        long mul = 1;
        for (int i = 0; i <
                seto.size(); i++) {
            mul *= seto.get(i);
        }

        return mul;
    }

    public long subRMP() {
        List<Integer> seto = RMPSetOrder();
        long sub = seto.get(seto.size() - 1);
        for (int i = 0; i <
                seto.size() - 1; i++) {
            sub -= seto.get(i);
        }

        return sub;
    }

    public long subMPSet() {
        List<Integer> seto = MPSetOrder();
        long sub = seto.get(seto.size() - 1);
        for (int i = 0; i <
                seto.size() - 1; i++) {
            sub -= seto.get(i);
        }

        return sub;
    }

    public int addMPSet() {
        List<Integer> seto = MPSetOrder();
        int sum = 0;
        for (int i = 0; i < seto.size(); i++) {
            sum += seto.get(i);
        }

        return sum;
    }

    public long mulMPSet() {
        List<Integer> seto = MPSetOrder();
        long mul = 1;
        for (int i = 0; i <
                seto.size(); i++) {
            mul *= seto.get(i);
        }

        return mul;
    }

    public int addLMP() {
        List<Integer> seto = LMPSetOrder();
        int sum = 0;
        for (int i = 0; i <
                seto.size(); i++) {
            sum += seto.get(i);
        }

        return sum;
    }

    public long subLMP() {
        List<Integer> seto = LMPSetOrder();
        long sub = seto.get(seto.size() - 1);
        for (int i = 0; i <
                seto.size() - 1; i++) {
            sub -= seto.get(i);
        }

        return sub;
    }

    public int getEqualityPrincpleCV(int set1, int set2) {
        int sum = 0;
        sum =
                getSetCount(set1) + getSetCount(set2);
        return sum;
    }

    private int getSetCount(int settype) {

        switch (settype) {
            case 1:
                return add();
            case 2:
                return addMPSet();
            case 3:
                return addRMP();
            case 4:
                return addLMP();
        }

        return 0;
    }

    public List<Integer> getEqualityPrincpleValues(int set1, int set2) {
        Integer[] sv1 = getSetValues(set1);
        Integer[] sv2 = getSetValues(set2);
        List<Integer> sum = new ArrayList<Integer>();
        int index1 = sv1.length;
        int index2 = sv2.length;


        if (index1 < index2) {
            for (int i = 0; i <
                    index1; i++) {
                sum.add(new Integer(sv1[i] + sv2[i]));
            }

            int d = index2 - index1;
            for (int i = 0; i <
                    d; i++) {
                sum.add(sv2[index1 + i]);
            }

            return sum;
        } else if (index1 > index2) {

            for (int i = 0; i <
                    index2; i++) {
                sum.add(sv1[i] + sv2[i]);
            }

            int d = index1 - index2;
            for (int i = 0; i <
                    d; i++) {
                sum.add(sv1[index2 + i]);
            }

            return sum;
        } else if (index1 == index2) {

            for (int i = 0; i <
                    index1 - 1; i++) {
                sum.add(sv1[i] + sv2[i]);
            }

            return sum;
        }

        return null;
    }

    public Integer[] getSetValues(int settype) {

        switch (settype) {
            case 1:
                return (Integer[]) MPOrder().toArray(new Integer[0]);
            case 2:
                return (Integer[]) MPSetOrder().toArray(new Integer[0]);
            case 3:
                return (Integer[]) RMPSetOrder().toArray(new Integer[0]);
            case 4:
                return (Integer[]) LMPSetOrder().toArray(new Integer[0]);
        }

        return null;
    }

    public void ferrersdiagram(int type) {
        Random r = new Random(5);
        int rand = r.nextInt(5);
        out.println("Partition Random Reducer:=" + rand);
        HashMap<Integer, String> parts = partitionInteger(rand, type);
        out.println("Partition Size:" + parts.size());
        Integer[] kvalues = getSetValues(type);
        String[] disp = {"$", "O", "o", ".", "x", "#"};
        for (int i = 0; i <
                kvalues.length; i++) {
            String spartint = parts.get(kvalues[i]);
            out.println("##################\nPartition of " + kvalues[i] + "\n##################");
            String[] partsint = spartint.split("\n");
            for (int k = 0; k <
                    partsint.length; k++) {
                out.println("Partition of Integers: " + partsint[k]);
                String partvalue = partsint[k];
                partvalue =
                        partvalue.trim();

                if (k > 0) {
                    out.println("$$Dot Partition: Conjugate Ferrers Diagram$$\n");
                } else {
                    out.println("$$Dot Partition$$\n");
                }
                out.println("------------------------");
                StringTokenizer tokenizer = new StringTokenizer(partvalue);
                while (tokenizer.hasMoreElements()) {
                    String partok = tokenizer.nextToken();
                    if (!partok.equalsIgnoreCase("+")) {
                        Integer dotcount = Integer.valueOf(partok);
                        for (int m = 0; m <
                                dotcount; m++) {
                            out.print("" + disp[rand] + "");
                        }

                    }
                    out.println("");
                }

                out.println("------------------------");
                out.println("");
            }

        }
    }

    public HashMap<Integer, String> partitionInteger(int reducer, int type) {
        HashMap<Integer, String> par = new HashMap<Integer, String>();
        if (reducer > 0) {
            switch (type) {
                case 1:
                    partitionBuild(par, MPOrder(), reducer);
                    break;
                case 2:
                    partitionBuild(par, MPSetOrder(), reducer);
                    break;
                case 3:
                    partitionBuild(par, RMPSetOrder(), reducer);
                    break;
                case 4:
                    partitionBuild(par, LMPSetOrder(), reducer);
                    break;
            }

        }
        return par;
    }

    public HashMap<Integer, String> pascalTriangle(int reducer, int type) {
        HashMap<Integer, String> par = new HashMap<Integer, String>();
        if (reducer > 0) {
            switch (type) {
                case 1:
                    pascalBuild(par, MPOrder(), reducer);
                    break;
                case 2:
                    pascalBuild(par, MPSetOrder(), reducer);
                    break;
                case 3:
                    pascalBuild(par, RMPSetOrder(), reducer);
                    break;
                case 4:
                    pascalBuild(par, LMPSetOrder(), reducer);
                    break;
            }

        }
        return par;
    }

    public void partitionBuild(HashMap<Integer, String> par, List<Integer> values, int reducer) {
        for (int i = 0; i <
                values.size(); i++) {
            Integer value = values.get(i);
            int d = value - reducer;
            String pars = "";
            String parvalue = new String(String.valueOf(d) + " + " + String.valueOf(reducer));
            d =
                    value - reducer - 1;
            pars +=
                    parvalue + "\n";
            parvalue =
                    new String(String.valueOf(d) + " + " + String.valueOf(reducer) + " + " + "1");
            pars +=
                    parvalue + "\n";
            d =
                    value - reducer - 2;
            parvalue =
                    new String(String.valueOf(d) + " + " + String.valueOf(reducer) + " + " + "1 + 1");
            d =
                    value - reducer - 3;
            pars +=
                    parvalue + "\n";
            parvalue =
                    new String(String.valueOf(d) + " + " + String.valueOf(reducer) + " + " + "1 + 1 + 1");
            pars +=
                    parvalue + "\n";
            par.put(value, pars);
        }

    }

    private void pascalBuild(HashMap<Integer, String> par, List<Integer> values, int reducer) {
        for (int i = 0; i < values.size(); i++) {
            Integer value = values.get(i);
            String pars = "";
            String parvalue = new String("     " + String.valueOf(value));
            pars += parvalue + "\n";
            int d = value - reducer;
            parvalue = new String("    " + String.valueOf(d) + "  " + String.valueOf(reducer));
            d =
                    value - reducer - 1;
            pars +=
                    parvalue + "\n";
            parvalue =
                    new String("   " + String.valueOf(d) + "  " + String.valueOf(reducer) + "  " + "1");
            pars +=
                    parvalue + "\n";
            d =
                    value - reducer - 2;
            parvalue =
                    new String("  " + String.valueOf(d) + "  " + String.valueOf(reducer) + "  " + "1  1");
            d =
                    value - reducer - 3;
            pars +=
                    parvalue + "\n";
            parvalue =
                    new String("" + String.valueOf(d) + "  " + String.valueOf(reducer) + "  " + "1  1  1");
            pars +=
                    parvalue + "\n";
            par.put(value, pars);
        }

    }

    public int generateFunc(int xvalue) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public MetaOperation metaOperation(
            int s) {

        switch (s) {
            case 1:
                return operations.get(0);
            case 2:
                return operations.get(1);
            case 3:
                return operations.get(3);
            case 4:
                return operations.get(4);
            case 5:
                return operations.get(5);
            case 6:
                return operations.get(6);
        }

        return null;
    }

    public void MPSentences() {
        problem.addSentence(new Sentence("Damn it", 1));
        problem.addSentence(new Sentence("Whats wrong", 2));
        problem.addSentence(new Sentence("It is a combination of 46 letters", 3));
        problem.addSentence(new Sentence("Akua will not marry you", 4));
        problem.addSentence(new Sentence("Pokua will not marry you", 5));
    }

    public void metaSententialOperation() {
        List<Integer> seto = LMPSetOrder();
        operations = new ArrayList<MetaOperation>();
        operations.add(new MetaOperation("-", "sum(L5, s) , sum(L3, s)", seto.get(0), "\nsum(L1,s)"));
        operations.add(new MetaOperation("-", "sum(L5, s) , sum(L2, s)", seto.get(1), "\nsum(L2,s)"));
        operations.add(new MetaOperation("-", "sum(L5, s) , sum(L1, s)", seto.get(2), "\nsum(L3,s)"));
        operations.add(new MetaOperation("+|-", "sum(L5, s) , sum(L4, s) , sum(L2, s)", seto.get(3), "\nsum(L4,s)"));
        operations.add(new MetaOperation("+", "sum(L3, s) , sum(L1, s)", seto.get(4), "\nsum(L5,s)"));
        operations.add(new MetaOperation("+|-", "sum(L5, s) , sum(L3, s)", seto.get(5), "\nsum(L6,s)"));
    }

    public List<MetaOperation> getOperations() {
        return operations;
    }

    public void setOperations(List<MetaOperation> operations) {
        this.operations = operations;
    }

    public List<Integer> LMPSetOrder() {
        List<Integer> setord = new ArrayList<Integer>();
        for (int i = 0; i <
                problem.getProblemSize(); i++) {
            setord.add(problem.getSentences().get(i).getCount());
        }
        Integer val27 = setord.get(2);
        setord.remove(setord.get(2));
        setord.add(2, new Integer(realMP()));
        setord.add(val27);
        return setord;
    }

    public long mulLMP() {
        List<Integer> seto = LMPSetOrder();
        long mul = 1;
        for (int i = 0; i <
                seto.size(); i++) {
            mul *= seto.get(i);
        }

        return mul;
    }

    /**
     * It returns a limit order for n=1 to n=20 to no other value. 
     * @param n Number of orders
     * @return Possible orders of long value.
     */
    public long numberOrder(int n) {
        long result = 1;
        for (int k = 1; k <= n; k++) {
            result *= k;
        }
        return result;
    }

    public List<String> orderList() {
        List<String> possibleOrder = new ArrayList<String>();
        int count = getSetCount(1);
        if (count > 20) {
            int exp = count / 20;
            possibleOrder.add("MP: " + count + " x exp(" + exp + ") x " + numberOrderLimit() + "\n");
        } else {
            possibleOrder.add("" + numberOrder(count));
        }
        count = getSetCount(2);
        if (count > 20) {
            int exp = count / 20;
            possibleOrder.add("MPSet: " + count + " x exp(" + exp + ") x " + numberOrderLimit() + "\n");
        } else {
            possibleOrder.add("" + numberOrder(count));
        }
        count = getSetCount(3);
        if (count > 20) {
            int exp = count / 20;
            possibleOrder.add("RMPSet: " + count + " x exp(" + exp + ") x " + numberOrderLimit() + "\n");
        } else {
            possibleOrder.add("" + numberOrder(count));
        }
        count = getSetCount(4);
        if (count > 20) {
            int exp = count / 20;
            possibleOrder.add("LMPSet: " + count + " x exp(" + exp + ") x " + numberOrderLimit() + "\n");
        } else {
            possibleOrder.add("" + numberOrder(count));
        }
        return possibleOrder;
    }

    private long numberOrderLimit() {
        return numberOrder(20);
    }
}
