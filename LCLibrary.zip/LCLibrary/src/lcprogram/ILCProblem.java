
package lcprogram;

import java.util.ArrayList;

/**
 *
 * @author appiah
 */
public interface ILCProblem {

    void addSentence(Sentence se);

    void clearMPSentinels();

    int getProblemSize();

    ArrayList<Sentence> getSentences();

    void reSentence(Sentence se);

    void setProblemSize(int problemSize);

    void setSentences(ArrayList<Sentence> sentences);

    void setDomainClass(int classic);
    
    int getDomainClass();
}
