package lcprogram;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author appiah
 */
public class ProblemFactory {

    private static ILCProblem socialClass = new MarriageProblem();
    private static ILCProblem familyClass = new MarriageProblem();
    private static ILCProblem naturalClass = new MarriageProblem();
    private static ILCProblem bodyClass = new MarriageProblem();
    private static ILCProblem intercourseClass = new MarriageProblem();
    private static ILCProblem schoolClass = new MarriageProblem();
    private static ILCProblem userClass = new MarriageProblem();
    private static List<ILCProblem> problemClasses = new ArrayList<ILCProblem>();
    private static List<Sentence> sentenceClasses = new ArrayList<Sentence>();
   
    public static final int socialCD = 1;
    public static final int familyCD = 2;
    public static final int naturalCD = 3;
    public static final int bodyCD = 4;
    public static final int intercourseCD = 5;
    public static final int schoolCD = 6;
    public static final int userCD = 7;

    public static ILCProblem getProblemClass(int domainClass) {
        switch (domainClass) {
            case socialCD:
                return getSocialClass();
            case familyCD:
                return getFamilyClass();
            case naturalCD:
                return getNaturalClass();
            case intercourseCD:
                return getIntercourseClass();
            case schoolCD:
                getSchoolClass();
            case bodyCD:
                return getBodyClass();
            case userCD:
                return getBodyClass();
        }
        return null;
    }

    public static ILCProblem getUserClass() {
        if (userClass == null) {
            userClass = new MarriageProblem();
        }
        return userClass;
    }

    @SuppressWarnings("static-access")
    public static ILCProblem getProblemClass(DomainClass domainClass) {

        if (domainClass.socialCD == socialCD) {
            return getSocialClass();
        }
        if (familyCD == domainClass.familyCD) {
            return getFamilyClass();
        }

        if (naturalCD == domainClass.naturalCD) {
            return getNaturalClass();
        }
        if (intercourseCD == domainClass.intercourseCD) {
            return getIntercourseClass();
        }
        if (schoolCD == domainClass.schoolCD) {
            schoolCD:
            getSchoolClass();
        }
        if (bodyCD == domainClass.bodyCD) {
            bodyCD:
            return getBodyClass();
        }
        if (userCD == domainClass.userCD) {
            userCD:
            return getUserClass();
        }

        return null;
    }

    public static ILCProblem getBodyClass() {
        if (bodyClass == null) {
            bodyClass = new MarriageProblem();
        }
        bodyClass.setProblemSize(6);

        bodyClass.addSentence(new Sentence("At wall", 1));
        bodyClass.addSentence(new Sentence("Hand at wall", 2));
        bodyClass.addSentence(new Sentence("I want touch wall", 3));
        bodyClass.addSentence(new Sentence("We do touch wall by hand", 4));
        bodyClass.addSentence(new Sentence("Do not want to touch wall", 5));
        bodyClass.addSentence(new Sentence("At top of a wall and I can not touch", 6));
      
        bodyClass.setDomainClass(DomainClass.bodyCD);
        return bodyClass;
    }

    public static ILCProblem getFamilyClass() {
        if (familyClass == null) {
            familyClass = new MarriageProblem();
        }

        familyClass.setProblemSize(6);
        familyClass.addSentence(new Sentence("At home", 1));
        familyClass.addSentence(new Sentence("We are close", 2));
        familyClass.addSentence(new Sentence("We live in a house", 3));
        familyClass.addSentence(new Sentence("We are family business", 4));
        familyClass.addSentence(new Sentence("It has family set in home", 5));
        familyClass.addSentence(new Sentence("We have family computer in a home", 6));
       
        familyClass.setDomainClass(DomainClass.familyCD);
        return familyClass;
    }

    public static ILCProblem getSchoolClass() {
        if (schoolClass == null) {
            schoolClass = new MarriageProblem();
        }

        schoolClass.setProblemSize(6);

        schoolClass.addSentence(new Sentence("He song", 1));
        schoolClass.addSentence(new Sentence("School song", 2));
        schoolClass.addSentence(new Sentence("Sing school song", 3));
        schoolClass.addSentence(new Sentence("I do sing song at school", 4));
        schoolClass.addSentence(new Sentence("We do sing song at school", 5));
        schoolClass.addSentence(new Sentence("There is no school without a song", 6));
        
        schoolClass.setDomainClass(DomainClass.schoolCD);
        return schoolClass;
    }

    public static ILCProblem getIntercourseClass() {
        if (intercourseClass == null) {
            intercourseClass = new MarriageProblem();
        }

        intercourseClass.setProblemSize(6);

        intercourseClass.addSentence(new Sentence("Love me", 1));
        intercourseClass.addSentence(new Sentence("I do love you", 2));
        intercourseClass.addSentence(new Sentence("Will love me back", 3));
        intercourseClass.addSentence(new Sentence("Will be your lover dear", 4));
        intercourseClass.addSentence(new Sentence("Will always love me back", 5));
        intercourseClass.addSentence(new Sentence("I will be your lover believe in me", 6));
        
        intercourseClass.setDomainClass(DomainClass.intercourseCD);
        return intercourseClass;
    }

    public static ILCProblem getNaturalClass() {
        if (naturalClass == null) {
            naturalClass = new MarriageProblem();
        }

        Random r = new Random();
        naturalClass.setProblemSize(6);
        if (r.nextInt(3) == 1) {
            naturalClass.addSentence(new Sentence("Go away", 1));
        } else if (r.nextInt(2) == 2) {
            naturalClass.addSentence(new Sentence("Go moon", 1));
        } else {
            naturalClass.addSentence(new Sentence("A sun go", 1));
        }

        naturalClass.addSentence(new Sentence("Go away moon", 2));
        naturalClass.addSentence(new Sentence("Go away moon-sun", 3));
        naturalClass.addSentence(new Sentence("The sun is go away thing", 4));
        naturalClass.addSentence(new Sentence("The moon is go away thing", 5));

        if (r.nextInt(4) == 1) {
            naturalClass.addSentence(new Sentence("The sun and moon goes upto the sky", 6));
        } else if (r.nextInt(3) == 2) {
            naturalClass.addSentence(new Sentence("The sun and moon go upto the skies", 6));
        } else if (r.nextInt(3) == 3) {
            naturalClass.addSentence(new Sentence("A sun and moon gone upto the skies", 6));
        } else {
            naturalClass.addSentence(new Sentence("Sun and moon gone upto the clouds", 6));
        }
        naturalClass.setDomainClass(DomainClass.naturalCD);
        return naturalClass;
    }

    public static ILCProblem getSocialClass() {
        if (socialClass == null) {
            socialClass = new MarriageProblem();
        }

        socialClass.clearMPSentinels();
        socialClass.addSentence(new Sentence("Damn it", 1));
        socialClass.addSentence(new Sentence("Whats wrong", 2));
        socialClass.addSentence(new Sentence("It is a combination of 46 letters", 3));
        socialClass.addSentence(new Sentence("Akua will not marry you", 4));
        socialClass.addSentence(new Sentence("Pokua will not marry you", 5));
        
        socialClass.setDomainClass(DomainClass.socialCD);
        return socialClass;
    }

    public static List<ILCProblem> getProblemClasses() {
        if (problemClasses == null) {
            problemClasses = new ArrayList<ILCProblem>();
        }
        problemClasses.add(getSchoolClass());
        problemClasses.add(getSocialClass());
        problemClasses.add(getBodyClass());
        problemClasses.add(getFamilyClass());
        problemClasses.add(getIntercourseClass());
        problemClasses.add(getNaturalClass());
        problemClasses.add(getUserClass());

        return problemClasses;
    }

    public static List<Sentence> getSentenceClasses() {
        if (sentenceClasses == null) {
            sentenceClasses = new ArrayList<Sentence>();
        }
        for (Sentence s : getBodyClass().getSentences()) {
            sentenceClasses.add(s);
        }
        for (Sentence s : getFamilyClass().getSentences()) {
            sentenceClasses.add(s);
        }
        for (Sentence s : getIntercourseClass().getSentences()) {
            sentenceClasses.add(s);
        }
        for (Sentence s : getNaturalClass().getSentences()) {
            sentenceClasses.add(s);
        }
        for (Sentence s : getSchoolClass().getSentences()) {
            sentenceClasses.add(s);
        }
        for (Sentence s : getUserClass().getSentences()) {
            sentenceClasses.add(s);
        }
        for (Sentence s : getSocialClass().getSentences()) {
            sentenceClasses.add(s);
        }
        return sentenceClasses;
    }
}
