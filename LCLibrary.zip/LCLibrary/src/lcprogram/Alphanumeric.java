/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lcprogram;

/**
 *
 * @author appiah
 */
public class Alphanumeric implements IAlphanumeric {

    private char letter;
    private int size;

    
    public Alphanumeric(char letter) {
        this.letter = letter;
    }
    
    public Alphanumeric(char letter, int size) {
        this.letter = letter;
        this.size = size;
    }

    public char getLetter() {
        return this.letter;
    }

    public void setLetter(char letter) {
        this.letter = letter;
    }

    public int getSize() {
        return this.size;
    }

    public void setSize(int size) {
        this.size = size;
    }
    
    
}
