package lcprogram;

import java.util.ArrayList;
import java.util.List;

/**
 * A sentence of a marriage problem.
 * 
 * @author appiah
 */
public interface ISentence {

    /**
     * It is a word from a sentence with all its alphabet labelling 
     * structure.
     * @return List of AlphaLabels.
     */
    public ArrayList<AlphaLabel> getAlphaLabels();

    /**
     * It sets alphalabels of a sentence's word.
     * @param alphaLabels List of AlphaLabels.
     */
    public void setAlphaLabels(ArrayList<AlphaLabel> alphaLabels);

    /**
     * It replaces a word in an alphalabel with a word if the number 
     * of letters are equal or not to that of the replaced word.
     * @param alphanum number of sentence alphalabel
     * @param word word used in replacement.
     * @return If successfully replaced returns true or false.
     */
    public boolean subsetReplace(int alphanum, String word);

    /**
     * It replaces a word in an alphalabel with a word with a concantenation
     * of letters are equal to that of the original word plus the append word.
     * @param index index in a sentence.
     * @param word  word used in appendment.
     * @param sse   whether to check for append after or before.(true=after, false=before)
     * @return If successfully replaced returns true or false.
     */
    public boolean subsetReplace(int index, String word, boolean sse);

    /**
     * It returns the number of this sentence.
     * @return Number of sentence.
     */
    public int getSentinumber();

    /**
     * It sets the sentinel number of a sentence.
     * @param sentinumber A number of a sentence.
     */
    public void setSentinumber(int sentinumber);

    String getSentinel();

    void setSentinel(String sentinel);

    int getCount();

    void setCount(int count);

    List<Integer> getPartitions();

    void setPartitions(List<Integer> partitions);
    
      /**
     * It returns the alphanumeric labelling of a word.
     * @return List of structures made up of an alphabet with index.
     */
    public List<IAlphanumeric> getAlphanumeric();

    /**
     * It sets the alphanumeric labelling of a word.
     * @param alphanumeric List of alphanumerics
     */
    public void setAlphanumeric(List<IAlphanumeric> alphanumeric);
 
}
