/*
 *
 */
package lcprogram;

/**
 * Interface for alphabet labelling.
 * 
 * @author appiah
 */
public interface IAlphaLabel {

    /**
     *  It sets a word for labelling
     * @param label The label of word from a sentence.
     */
    public void setWord(String label);

    /**
     * It returns the label word of a sentence.
     * @return A label word made of alphabets
     */
    public String getWord();

    /**
     * It sets  a new character at the position, index of a  word.
     * @param letter Character used in replacement.
     * @param index Position in word to do the replacement.
     */
    public void setLetter(char letter, int index);

    /**
     * It returns the character or letter at the specified index.
     * @param index position to make a char retrieval.
     * @return A specific character from a word.
     */
    public char getLetter(int index);

    /**
     * It returns the size of words. 
     * @return Size of words.
     */
    public int getSize();

    /**
     * It sets the size of words.
     * @param size Sise of wordss to check to consistency.
     */
    public void setSize(int size);

    /**
     * It checks for subset equality of word with a specific chararray letterset.
     * @param start Start position to find the first letter.
     * @param end end position to find the last letter.
     * @param letterSet An array of letters.
     * @return True if equal or false.
     */
    public boolean subsetEquality(int start, int end, char[] letterSet);

    /**
     * It checks for subset equality of word with a specific string letterset.
     * @param start start Start position to find the first letter.
     * @param end  end end position to find the last letter.
     * @param letterSet  letterSet An array of letters.
     * @return True if equal or false.
     */
    boolean subsetEquality(int start, int end, String letterSet);

    public int getIndex();

    public char getLetter();

    /**
     *  It returns the position of word in a sentence
     * 
     * @return Position of sentence.
     */
    public int getPosition();

    /**
     * 
     * @param index
     */
    public void setIndex(int index);

    public void setLetter(char letter);

    /**
     * It sets the position of word in a sentence.
     * @param position Position in sentence
     */
    public void setPosition(int position);
}
