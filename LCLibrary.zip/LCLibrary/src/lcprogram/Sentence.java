package lcprogram;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

/**
 * Implementation of an MP sentence.
 * 
 * @author appiah
 */
public class Sentence implements ISentence {

    private ArrayList<AlphaLabel> alphaLabels = new ArrayList<AlphaLabel>();
    private String sentinel;
    private int sentinumber=0;
    private int wordCount;
    private Alphanumeric an;
    private int count;
    private List<Integer> partitions = new ArrayList<Integer>();
    private List<IAlphanumeric> alphanumeric = new ArrayList<IAlphanumeric>();

    public Sentence(String sentinel, int sentinumber, int wordCount, int count) {
        this.sentinel = sentinel;
        this.sentinumber = sentinumber;
        this.wordCount = wordCount;
        this.count = count;
    }

    public Sentence(ArrayList<AlphaLabel> alphaLabels, int sentinumber) {
        this.alphaLabels = alphaLabels;
        this.sentinumber = sentinumber;
    }

    public Sentence(String sentinel, int sentinumber, int count) {
        this.sentinel = sentinel;
        this.sentinumber = sentinumber;
        this.count = count;
    }

    public List<IAlphanumeric> getAlphanumeric() {
        char[] wchars = this.sentinel.trim().toCharArray();
        int wsize = wchars.length;
        String spacev = " ";
        char[] space = spacev.toCharArray();

        for (int i = 0; i < wchars.length; i++) {
            an = new Alphanumeric(wchars[i]);
            alphanumeric.add(an);
        }
        for (int k = 0; k < alphanumeric.size(); k++) {
            IAlphanumeric ia = alphanumeric.get(k);
            if (ia.getLetter() == space[0]) {
                alphanumeric.remove(alphanumeric.get(k));
                continue;
            }
        }
        for (int k = 0; k < alphanumeric.size(); k++) {
            IAlphanumeric ia = alphanumeric.get(k);
            ia.setSize(k + 1);
            alphanumeric.remove(alphanumeric.get(k));
            alphanumeric.add(k, ia);
        }

        return alphanumeric;
    }

    public void setAlphanumeric(List<IAlphanumeric> alphanumeric) {
        this.alphanumeric = alphanumeric;
    }

    public Sentence(String sentinel, int sentinumber) {
        setSentinumber(sentinumber);
        this.sentinel = sentinel;
        setSentinel(sentinel);
        
    }

    public List<Integer> getPartitions() {
        for (int i = 0; i < alphaLabels.size(); i++) {
            partitions.add(alphaLabels.get(i).getSize());
        }
        return partitions;
    }

    public void setPartitions(List<Integer> partitions) {
        this.partitions = partitions;
    }

    public Sentence(int sentinumber) {
        this.sentinumber = sentinumber;
    }

    public Sentence() {
    }

    public Sentence(ArrayList<AlphaLabel> alphaLabels, String sentinel, int sentinumber) {
        this.alphaLabels = alphaLabels;
        this.sentinel = sentinel;
        this.sentinumber = sentinumber;
    }

    public void setWordCount(int wordCount) {
        this.wordCount = wordCount;
    }

    public int getWordCount() {
        return wordCount = alphaLabels.size();
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getCount() {
        int sum = 0;
        for (int i = 0; i < alphaLabels.size(); i++) {
            sum += alphaLabels.get(i).getSize();
        }
        count = sum;
        return count;
    }

    public String getSentinel() {
        return sentinel;
    }

    public void setSentinel(final String sentinel) {
        this.sentinel = sentinel;
        tokenize(sentinel);
    }

    public void tokenize(String senpentance) {
        StringTokenizer tokenizer = new StringTokenizer(senpentance, " ");
        while (tokenizer.hasMoreTokens()) {
            AlphaLabel al = new AlphaLabel(tokenizer.nextToken(), this.getSentinumber(), this.getAlphaLabels().size() + 1);
            getAlphaLabels().add(al);
        }
    }

    public int getSentinumber() {
        return this.sentinumber;
    }

    public void setSentinumber(int sentinumber) {
        this.sentinumber = sentinumber;
    }

    public ArrayList<AlphaLabel> getAlphaLabels() {
        return alphaLabels;
    }

    public void setAlphaLabels(ArrayList<AlphaLabel> alphaLabels) {
        this.alphaLabels = alphaLabels;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Sentence other = (Sentence) obj;
        if (this.alphaLabels != other.alphaLabels && (this.alphaLabels == null || !this.alphaLabels.equals(other.alphaLabels))) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 41 * hash + (this.alphaLabels != null ? this.alphaLabels.hashCode() : 0);
        return hash;
    }

    public boolean subsetReplace(int alphanum, String word) {

        AlphaLabel label = (AlphaLabel) getAlphaLabels().toArray()[alphanum];
        if (label == null) {
            return false;
        }
        label.setWord(word);
        getAlphaLabels().remove(alphanum);
        getAlphaLabels().add(label);
        return true;
    }

    public boolean subsetReplace(int index, String word, boolean sse) {
        AlphaLabel label = (AlphaLabel) getAlphaLabels().toArray()[index];
        if (label == null) {
            return false;
        }
        if (sse = true) {
            label.setWord(label.getWord() + word);
        } else {
            label.setWord(word + label.getWord());
        }
        getAlphaLabels().remove(index);
        getAlphaLabels().add(label);
        return true;
    }

    @Override
    public String toString() {
        return this.sentinel;
    }
}
