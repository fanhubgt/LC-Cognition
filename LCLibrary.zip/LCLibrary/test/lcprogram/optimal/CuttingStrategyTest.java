package lcprogram.optimal;

import java.util.ArrayList;
import java.util.List;
import lcprogram.LCProgram;
import lcprogram.Sentence;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author appiah
 */
public class CuttingStrategyTest {

    List<Integer> allsizevalues;
    int n = 3;
    int domainClass = 1;
    int sentinelNo = 5;

    public CuttingStrategyTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() {
        allsizevalues = new ArrayList<Integer>();
        allsizevalues.add(new Integer(6));
        allsizevalues.add(new Integer(10));
        allsizevalues.add(new Integer(14));
        allsizevalues.add(new Integer(19));
        allsizevalues.add(new Integer(20));
        allsizevalues.add(new Integer(27));
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of residue method, of class CuttingStrategy.
     */
    @Test
    public void residue() {

        int size = 2;

        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 2;
        int result = instance.residue(size, n);
        System.out.println("residue: " + result);
        assertEquals(expResult, result);

    }

    /**
     * Test of sentinelResidue method, of class CuttingStrategy.
     */
    @Test
    public void sentinelResidue() {

        List<Integer> sizevalues = null;//allsizevalues;

        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        List<Integer> expResult = null;
        List<Integer> result = instance.sentinelResidue(sizevalues, n, sentinelNo);
        System.out.println("sentinelResidue:=" + result);
        assertEquals(expResult, result);

    }

    /**
     * Test of setMinValue method, of class CuttingStrategy.
     */
    @Test
    public void setMinValue() {
        System.out.println("setMinValue");
        int minValue = 1;
        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        instance.setMinValue(minValue);

    }

    /**
     * Test of setMaxValue method, of class CuttingStrategy.
     */
    @Test
    public void setMaxValue() {
        System.out.println("setMaxValue");
        int maxValue = 0;
        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        instance.setMaxValue(maxValue);

    }

    /**
     * Test of getMaxValue method, of class CuttingStrategy.
     */
    @Test
    public void getMaxValue() {
        System.out.println("getMaxValue");
        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 0;
        int result = instance.getMaxValue();
        assertEquals(expResult, result);
    }

    /**
     * Test of getMinValue method, of class CuttingStrategy.
     */
    @Test
    public void getMinValue() {
        System.out.println("getMinValue");
        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 0;
        int result = instance.getMinValue();
        assertEquals(expResult, result);

    }

    /**
     * Test of setSentinelNumber method, of class CuttingStrategy.
     */
    @Test
    public void setSentinelNumber() {
        System.out.println("setSentinelNumber");
        int sentinelNumber = 0;
        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        instance.setSentinelNumber(sentinelNumber);

    }

    /**
     * Test of setProblemClass method, of class CuttingStrategy.
     */
    @Test
    public void setProblemClass() {
        System.out.println("setProblemClass");
        int problemClass = 0;
        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        instance.setProblemClass(problemClass);

    }

    /**
     * Test of getSentinelNumber method, of class CuttingStrategy.
     */
    @Test
    public void getSentinelNumber() {
        System.out.println("getSentinelNumber");
        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 0;
        int result = instance.getSentinelNumber();
        assertEquals(expResult, result);

    }

    /**
     * Test of getProblemClass method, of class CuttingStrategy.
     */
    @Test
    public void getProblemClass() {
        System.out.println("getProblemClass");
        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 0;
        int result = instance.getProblemClass();
        assertEquals(expResult, result);
    }

    /**
     * Test of min_value method, of class CuttingStrategy.
     */
    @Test
    public void min_value() {

        List<Integer> sizevalues = null;

        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 0;
        int result = instance.min_value(sizevalues, sentinelNo);
        System.out.println("min_value:=" + result);
    // assertEquals(expResult, result);

    }

    /**
     * Test of max_value method, of class CuttingStrategy.
     */
    @Test
    public void max_value() {

        List<Integer> sizevalues = null;
        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 0;
        int result = instance.max_value(sizevalues);
        System.out.println("max_value:=" + result);
    //assertEquals(expResult, result);

    }

    /**
     * Test of min_domain method, of class CuttingStrategy.
     */
    @Test
    public void min_domain() {

        List<Integer> sizevalues = null;
        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 0;
        int result = instance.min_domain(sizevalues, domainClass);
        System.out.println("min_domain:=" + result);
    //assertEquals(expResult, result);

    }

    /**
     * Test of max_domain method, of class CuttingStrategy.
     */
    @Test
    public void max_domain() {

        List<Integer> sizevalues = allsizevalues;

        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 0;
        int result = instance.max_domain(sizevalues, domainClass);
        System.out.println("max_domain:=" + result);
    // assertEquals(expResult, result);
    }

    /**
     * Test of min_min_domain method, of class CuttingStrategy.
     */
    @Test
    public void min_min_domain() {

        List<Integer> sizevalues = allsizevalues;

        int min = 6;
        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 0;
        int result = instance.min_min_domain(sizevalues, domainClass, sentinelNo, min);
        System.out.println("min_min_domain:=" + result);
    //assertEquals(expResult, result);
    }

    /**
     * Test of max_max_domain method, of class CuttingStrategy.
     */
    @Test
    public void max_max_domain() {

        List<Integer> sizevalues = allsizevalues;

        int max = 1;
        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 0;
        int result = instance.max_max_domain(sizevalues, domainClass, sentinelNo, max);
        System.out.println("max_max_domain:=" + result);
    //  assertEquals(expResult, result);
    }

    /**
     * Test of maxSizes method, of class CuttingStrategy.
     */
    @Test
    public void maxSizes() {

        List<Integer> sizes = allsizevalues;
        int maxValue = 27;
        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        List<Integer> expResult = null;
        List<Integer> result = instance.maxSizes(sizes, maxValue);
       
        System.out.println("maxSizes:=" + result);
    }

    /**
     * Test of minSizes method, of class CuttingStrategy.
     */
    @Test
    public void minSizes() {

        List<Integer> sizes = allsizevalues;
        int minValue = 0;
        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        List<Integer> expResult = null;
        List<Integer> result = instance.minSizes(sizes, minValue);
        System.out.println("minSizes:=" + result);
    
    }

    /**
     * Test of random method, of class CuttingStrategy.
     */
    @Test
    public void random() {

        List<Integer> sizevalues =allsizevalues;

        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int[] expResult = null;
        int[] result = instance.random(sizevalues, domainClass);
        System.out.println("random:=" + result);
    // assertEquals(expResult, result);

    }

    /**
     * Test of randomMin method, of class CuttingStrategy.
     */
    @Test
    public void randomMin() {

        int[] sizevalues = null;
        int sentinelNo = 0;
        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 0;
        int result = instance.randomMin(sizevalues, sentinelNo);
        System.out.println("randomMin:=" + result);
    //assertEquals(expResult, result);

    }

    /**
     * Test of randomMax method, of class CuttingStrategy.
     */
    @Test
    public void randomMax() {

        int[] sizevalues = null;

        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 0;
        int result = instance.randomMax(sizevalues, sentinelNo);
        System.out.println("randomMax:=" + result);
    // assertEquals(expResult, result);

    }

    /**
     * Test of min_domain_max_degree method, of class CuttingStrategy.
     */
    @Test
    public void min_domain_max_degree() {

        int[] sizevalues = null;

        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 0;
        int result = instance.min_domain_max_degree(sizevalues, domainClass);
        System.out.println("min_domain_max_degree:=" + result);
    // assertEquals(expResult, result);

    }

    /**
     * Test of max_domain_min_degree method, of class CuttingStrategy.
     */
    @Test
    public void max_domain_min_degree() {

        int[] sizevalues = null;

        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 0;
        int result = instance.max_domain_min_degree(sizevalues, domainClass);
        System.out.println("max_domain_min_degree:=" + result);
    //assertEquals(expResult, result);

    }

    /**
     * Test of min_domain_over_degree method, of class CuttingStrategy.
     */
    @Test
    public void min_domain_over_degree() {

        int[] sizevalues = null;

        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 0;
        int result = instance.min_domain_over_degree(sizevalues, domainClass);
        System.out.println("min_domain_over_degree:=" + result);
    //assertEquals(expResult, result);

    }

    /**
     * Test of max_domain_over_degree method, of class CuttingStrategy.
     */
    @Test
    public void max_domain_over_degree() {
        int[] sizevalues = null;

        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 0;
        int result = instance.max_domain_over_degree(sizevalues, domainClass);
        System.out.println("max_domain_over_degree:=" + result);

    // assertEquals(expResult, result);

    }

    /**
     * Test of max_degree method, of class CuttingStrategy.
     */
    @Test
    public void max_degree() {

        int[] sizevalues = null;

        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int[] expResult = null;
        int[] result = instance.max_degree(sizevalues, sentinelNo);
        System.out.println("max_degree:[min=" + result[0]+"  max="+result[1]+"]");
    // assertEquals(expResult, result);
    }

    /**
     * Test of min_degree method, of class CuttingStrategy.
     */
    @Test
    public void min_degree() {

        int[] sizevalues = null;

        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int[] expResult = null;
        int[] result = instance.min_degree(sizevalues, sentinelNo);
        System.out.println("min_degree:[min=" + result[0]+"  max="+result[1]+"]");
    //  assertEquals(expResult, result);

    }

    /**
     * Test of min_max_alternate method, of class CuttingStrategy.
     */
    @Test
    public void min_max_alternate() {

        int[] sizevalues = null;

        boolean maxEnabled = false;
        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 0;
        int result = instance.min_max_alternate(sizevalues, sentinelNo, maxEnabled);
        System.out.println("min_max_alternate:=" + result);
    //  assertEquals(expResult, result);

    }

    /**
     * Test of minmax_alternate method, of class CuttingStrategy.
     */
    @Test
    public void minmax_alternate() {

        int[] sizevalues = null;

        boolean maxEnabled = false;
        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 0;
        int result = instance.minmax_alternate(sizevalues, domainClass, maxEnabled);
        System.out.println("minmax_alternate:=" + result);
    //assertEquals(expResult, result);

    }

    /**
     * Test of median_domain method, of class CuttingStrategy.
     */
    @Test
    public void median_domain() {

        int[] sizesvalues = null;

        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 0;
        double result = instance.median_domain(sizesvalues, domainClass);
        System.out.println("median_domain:=" + result);
    }

    /**
     * Test of median method, of class CuttingStrategy.
     */
    @Test
    public void median() {

        int[] sizesvalues = null;

        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 0;
        double result = instance.median(sizesvalues, sentinelNo);
        System.out.println("median:=" + result);
    }

    /**
     * Test of max_regret method, of class CuttingStrategy.
     */
    @Test
    public void max_regret() {

        int[] sizesvalue = null;
        int[] sentinels = null;

        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 0;
        int result = instance.max_regret(sizesvalue, sentinels, domainClass);
        System.out.println("max_regret:=" + result);
    }

    /**
     * Test of max_impact method, of class CuttingStrategy.
     */
    @Test
    public void max_impact() {

        int[] sizesvalue = null;
        int[] sentinels = null;
        
        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 0;
        int result = instance.max_impact(sizesvalue, sentinels, domainClass);
        System.out.println("max_impact:=" + result);
    }

    /**
     * Test of min_domain_random method, of class CuttingStrategy.
     */
    @Test
    public void min_domain_random() {
        int[] sizesvalue = null;
        
        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 0;
        int result = instance.min_domain_random(sizesvalue, domainClass);
        System.out.println("min_domain_random:=" + result);
    }

    /**
     * Test of max_domain_random method, of class CuttingStrategy.
     */
    @Test
    public void max_domain_random() {

        int[] sizesvalue = null;

        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int expResult = 0;
        int result = instance.max_domain_random(sizesvalue, domainClass);
        System.out.println("max_domain_random:=" + result);
    }

    /**
     * Test of all_interval_seriesD method, of class CuttingStrategy.
     */
    @Test
    public void all_interval_seriesD() {

        int[] sizesvalue = null;

        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int[] expResult = null;
        int[] result = instance.all_interval_seriesD(sizesvalue, domainClass);
        System.out.println("all_interval_seriesD:=" + result);
    }

    /**
     * Test of all_interval_seriesDN method, of class CuttingStrategy.
     */
    @Test
    public void all_interval_seriesDN() {

        int[] sizesvalue = null;
        
        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int[] expResult = null;
        int[] result = instance.all_interval_seriesDN(sizesvalue, domainClass, sentinelNo);
        System.out.println("all_interval_seriesDN:=" + result);
    }

    /**
     * Test of all_interval_seriesS method, of class CuttingStrategy.
     */
    @Test
    public void all_interval_seriesS() {
      
        int[] sizesvalue = null;
      
        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        int[] expResult = null;
        int[] result = instance.all_interval_seriesS(sizesvalue, sentinelNo);
         System.out.println("all_interval_seriesS:="+result);
    }

    /**
     * Test of getDegreeSentence method, of class CuttingStrategy.
     */
    @Test
    public void getDegreeSentence() {

        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        Sentence expResult = null;
        Sentence result = instance.getDegreeSentence();
        min_degree();
        System.out.println("getDegreeSentence:=" + result);
        
    }

    /**
     * Test of setDegreeSentence method, of class CuttingStrategy.
     */
    @Test
    public void setDegreeSentence() {
        System.out.println("setDegreeSentence");
        Sentence degreeSentence = null;
        CuttingStrategy instance = new CuttingStrategy(new LCProgram());
        instance.setDegreeSentence(degreeSentence);
       
    }
}
