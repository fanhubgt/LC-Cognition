
package lcprogram.optimal;

/**
 *
 * @author appiah
 */
public class SearchStrategy {

}
