package lcprogram.test;

import lcprogram.LCProgram;
import lcprogram.MarriageProblem;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import static java.lang.System.out;
import static java.lang.System.in;

/**
 *
 * @author appiah
 */
public class AlphaSizeTest {

    public AlphaSizeTest() {
    }
    LCProgram program;
    MarriageProblem problem;

    @Before
    public void setUp() {
        program = new LCProgram();
        problem = (MarriageProblem) program.getProblem();
        program.MPSentences();
    }

    @After
    public void tearDown() {
        program = null;
        problem = null;
    }

    @Test
    public void testAlphaSize() {
        out.println("(1) Alpha size:" + problem.getSentences().get(0).getAlphaLabels().size());
        out.println("(2) Alpha size:" + problem.getSentences().get(1).getAlphaLabels().size());
        out.println("(3) Alpha size:" + problem.getSentences().get(2).getAlphaLabels().size());
        out.println("(4) Alpha size:" + problem.getSentences().get(3).getAlphaLabels().size());
        out.println("(5) Alpha size:" + problem.getSentences().get(4).getAlphaLabels().size());

    }
}
