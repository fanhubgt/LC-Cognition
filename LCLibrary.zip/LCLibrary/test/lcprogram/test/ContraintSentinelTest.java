package lcprogram.test;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import lcprogram.LCProgram;
import lcprogram.MarriageProblem;
import lcprogram.Sentence;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import static java.lang.System.out;
import static java.lang.System.in;

/**
 *
 * @author appiah
 */
public class ContraintSentinelTest {

    public ContraintSentinelTest() {
    }
    LCProgram program;
    MarriageProblem problem;

    @Before
    public void setUp() {
        program = new LCProgram();
        problem = (MarriageProblem) program.getProblem();
    }

    @After
    public void tearDown() {
        program = null;
        problem = null;
    }

    @Test
    public void testConstraintSentinel() {
        try {
            int[] cMP = {6, 10, 27, 14, 19, 20};

            byte[] mp1 = new byte[cMP[0]];
            int size = in.read(mp1);
            out.println("Please give your sentence for MP 1:");

            String smp1 = new String(mp1);
            problem.getSentences().add(new Sentence(smp1.trim(), 1));
            out.println("Please give your sentence for MP 2:");
            byte[] mp2 = new byte[cMP[1]];
            size = in.read(mp2);
            String smp2 = new String(mp2);
            problem.getSentences().add(new Sentence(smp2.trim(), 2));
            out.println("Please give your sentence for MP 3:");
            byte[] mp3 = new byte[cMP[2]];
            size = in.read(mp3);
            String smp3 = new String(mp3);
            problem.getSentences().add(new Sentence(smp3.trim(), 3));
            out.println("Please give your sentence for MP 4:");
            byte[] mp4 = new byte[cMP[3]];
            size = in.read(mp4);
            String smp4 = new String(mp4);
            problem.getSentences().add(new Sentence(smp4.trim(), 4));
            out.println("Please give your sentence for MP 5:");
            byte[] mp5 = new byte[cMP[4]];
            size = in.read(mp5);
            String smp5 = new String(mp5);
            problem.getSentences().add(new Sentence(smp5.trim(), 5));
        } catch (IOException ex) {
            Logger.getLogger(ContraintSentinelTest.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
