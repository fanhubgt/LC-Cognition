/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lcprogram.test;

import lcprogram.LCProgram;
import lcprogram.MarriageProblem;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import static java.lang.System.out;

/**
 *
 * @author appiah
 */
public class PrintSentenceTest {

    public PrintSentenceTest() {
    }
    LCProgram program;
    MarriageProblem problem;

    @Before
    public void setUp() {
        program = new LCProgram();
        problem = (MarriageProblem) program.getProblem();
        program.MPSentences();
    }

    @After
    public void tearDown() {
        program = null;
        problem = null;
    }

    @Test
    public void testSetencePrint() {
        out.println("MP Sentence 1: " + problem.getSentences().get(0).toString());
        out.println("MP Sentence 2: " + problem.getSentences().get(1).toString());
        out.println("MP Sentence 3: " + problem.getSentences().get(2).toString());
        out.println("MP Sentence 4: " + problem.getSentences().get(3).toString());
        out.println("MP Sentence 5: " + problem.getSentences().get(4).toString());

    }
}
