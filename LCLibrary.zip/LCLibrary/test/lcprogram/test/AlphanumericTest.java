/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lcprogram.test;

import java.util.ArrayList;
import java.util.List;
import lcprogram.IAlphanumeric;
import lcprogram.LCProgram;
import lcprogram.MarriageProblem;
import lcprogram.Sentence;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import static java.lang.System.out;
import static java.lang.System.in;

/**
 *
 * @author appiah
 */
public class AlphanumericTest {

    public AlphanumericTest() {
    }
    LCProgram program;
    MarriageProblem problem;

    @Before
    public void setUp() {
        program = new LCProgram();
        problem = (MarriageProblem) program.getProblem();
        program.MPSentences();
    }

    @After
    public void tearDown() {
        program = null;
        problem = null;
    }

    @Test
    public void testAlphanumeric() {
        ArrayList<Sentence> sentences = problem.getSentences();
        for (int i = 0; i < sentences.size(); i++) {
            Sentence s = sentences.get(i);
            out.println("Sentence MP(" + (i + 1) + "):");
            List<IAlphanumeric> als = s.getAlphanumeric();
            for (int k = 0; k < als.size(); k++) {
                IAlphanumeric ia = als.get(k);
                out.print("(" + ia.getLetter() + "):" + ia.getSize() + "  ");
            }
            out.println("");
        }
    }
}
