package lcprogram.test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author appiah
 */
public class LCTestSuite{

    public LCTestSuite() {
    }

    @Before
    public void setUp() {
    
    }

    @After
    public void tearDown() {

    }
    @Test
    public void runTest(){
        new AlphaLabelTest();
    }
}
