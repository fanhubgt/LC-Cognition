/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lcprogram.test;

import lcprogram.LCProgram;
import lcprogram.MarriageProblem;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static java.lang.System.out;
import static java.lang.System.in;

/**
 *
 * @author appiah
 */
public class MenuTest {

    LCProgram program;
    MarriageProblem problem;

    @Before
    public void setUp() {
        program = new LCProgram();
        problem = (MarriageProblem) program.getProblem();
        program.MPSentences();
    }

    @After
    public void tearDown() {
        program = null;
        problem = null;
    }

    @Test
    public void testMenu() {
        out.println("\nLCProgram Menu\n==========================\n");
        out.println("01:     Problem Size");
        out.println("02:     MP Sentences");
        out.println("03:     Principle Values (MPSet)");
        out.println("04:     Alpha Sizes");
        out.println("05:     Partition Sets");
        out.println("06:     Count Problems");
        out.println("07:     Alpha Label Tokens");
        out.println("08:     MP Sets");
        out.println("09:     Principle Values (RMPSet)");
        out.println("10:     Alphanumerics");
        out.println("11:     Meta-Operation");
        out.println("12:     Principle Values (LMPSet)");
        out.println("Press Ctrl+C: Quit LCProgram");
        out.println("==========================\n");

    }
}
