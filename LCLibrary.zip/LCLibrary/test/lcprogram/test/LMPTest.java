/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package lcprogram.test;

import lcprogram.LCProgram;
import lcprogram.MarriageProblem;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import static java.lang.System.out;
import static java.lang.System.in;

/**
 *
 * @author appiah
 */
public class LMPTest {

    public LMPTest() {
    }
    LCProgram program;
    MarriageProblem problem;

    @Before
    public void setUp() {
        program = new LCProgram();
        problem = (MarriageProblem) program.getProblem();
        program.MPSentences();
    }

    @After
    public void tearDown() {
        program = null;
        problem = null;
    }

    @Test
    public void testLMPSet() {
        out.println("Addition Principle Value(LMPSet):=" + program.addLMP());
        out.println("Substraction Principle Value(LMPSet):=" + program.subLMP());
        out.println("Multiplication Principle Value(LMPSet):=" + program.mulLMP());

    }
}
