
package lcprogram.test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import lcprogram.LCProgram;
import lcprogram.MarriageProblem;
import lcprogram.Sentence;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import static java.lang.System.out;
import static java.lang.System.in;

/**
 *
 * @author appiah
 */
public class FileSentenceTest {

    public FileSentenceTest() {
    }
    LCProgram program;
    MarriageProblem problem;

    @Before
    public void setUp() {
        program = new LCProgram();
        problem = (MarriageProblem) program.getProblem();
        program.MPSentences();
    }

    @After
    public void tearDown() {
        program = null;
        problem = null;
    }

    @Test
    public void testfileSentinel() {
        try {
            BufferedReader br=new BufferedReader(new FileReader(("/home/appiah/NetBeansProjects/LCProgram/sentence.txt")));
            String data;
            int i=1;
            while((data=br.readLine())!=null){
              problem.getSentences().add(new Sentence(new String(data), i)); 
              out.println(problem.getSentences().get(i-1));
              i++;
            }
            
        } catch (IOException ex) {
            Logger.getLogger(FileSentenceTest.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
