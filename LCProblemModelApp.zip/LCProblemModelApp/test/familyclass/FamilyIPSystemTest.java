/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package familyclass;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author appiah
 */
public class FamilyIPSystemTest {

    public FamilyIPSystemTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of prover method, of class FamilyIPSystem.
     */
    @Test
    public void prover() {
        System.out.println("prover");
        String sentence = "We Are Close";
        int type = 2;
        FamilyIPSystem instance = new FamilyIPSystem();
        instance.prover(sentence, type);

    }

    /**
     * Test of verifier method, of class FamilyIPSystem.
     */
    @Test
    public void verifier() {
        System.out.println("verifier");
        String vr = "We Are Close";
        int type = 2;
        FamilyIPSystem instance = new FamilyIPSystem();
        instance.verifier(vr, type);

    }

    /**
     * Test of checkTokens method, of class FamilyIPSystem.
     */
    @Test
    public void checkTokens() {
        int type = 2;
        String sentence = "We Are Close";
        boolean expResult = false;
        boolean result = FamilyIPSystem.checkTokens(type, sentence);
        System.out.println("checkTokens:=" + result);
    }
}
