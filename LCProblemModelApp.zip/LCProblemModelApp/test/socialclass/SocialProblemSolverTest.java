package socialclass;

import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author appiah
 */
public class SocialProblemSolverTest {

    public SocialProblemSolverTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
        System.out.println("SocialProblem Prototype class is setup..");
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
        System.out.println("SocialProblem Prototype class is tear down..");
    }

    @Before
    public void setUp() {
        System.out.println("SocialProblem Prototype is setup......");
    }

    @After
    public void tearDown() {
        System.out.println("SocialProblem Prototype is tear down...");
    }

    /**
     * Test of getSeo method, of class SocialProblemSolver.
     */
    @Test
    public void getSeo() {

        SocialProblemSolver instance = new SocialProblemSolver();
        
        SentinelEnumOne result = instance.getSeo();
        System.out.println("getSeo:=" +  result);
    }

    /**
     * Test of getSet method, of class SocialProblemSolver.
     */
    @Test
    public void getSet() {

        SocialProblemSolver instance = new SocialProblemSolver();
     
        SentinelEnumTwo result = instance.getSet();
        System.out.println("getSet:=" + result.toString());
    }

    /**
     * Test of getSeth method, of class SocialProblemSolver.
     */
    @Test
    public void getSeth() {

        SocialProblemSolver instance = new SocialProblemSolver();
        
        SentinelEnumThree result = instance.getSeth();
        System.out.println("getSeth:=" + result.toString());
    }

    /**
     * Test of getSef method, of class SocialProblemSolver.
     */
    @Test
    public void getSef() {

        SocialProblemSolver instance = new SocialProblemSolver();
       
        SentinelEnumFour result = instance.getSef();
        System.out.println("getSef:=" + result.toString());
    }

    /**
     * Test of getSefi method, of class SocialProblemSolver.
     */
    @Test
    public void getSefi() {

        SocialProblemSolver instance = new SocialProblemSolver();
       
        SentinelEnumFive result = instance.getSefi();
        System.out.println("getSefi:=" + result.toString());
    }

    /**
     * Test of getSes method, of class SocialProblemSolver.
     */
    @Test
    public void getSes() {

        SocialProblemSolver instance = new SocialProblemSolver();
       
        SentinelEnumSix result = instance.getSes();
        System.out.println("getSes:=" + result.toString());
    }

    /**
     * Test of partition method, of class SocialProblemSolver.
     */
    @Test
    public void partition() {

        int type = 2;
        SocialProblemSolver instance = new SocialProblemSolver();
        
        List<Integer> result = instance.partition(type);
        System.out.println("partition:=" + result);
    }

    /**
     * Test of count method, of class SocialProblemSolver.
     */
    @Test
    public void count() {

        int type = 2;
        SocialProblemSolver instance = new SocialProblemSolver();
        
        int result = instance.count(type);
        System.out.println("count:=" + result);
    }

    /**
     * Test of add method, of class SocialProblemSolver.
     */
    @Test
    public void add() {

        int type = 1;
        SocialProblemSolver instance = new SocialProblemSolver();
        
        int result = instance.add(type);
        System.out.println("add:=" + result);
    }

    /**
     * Test of subtract method, of class SocialProblemSolver.
     */
    @Test
    public void subtract() {

        int type = 2;
        SocialProblemSolver instance = new SocialProblemSolver();
        
        int result = instance.subtract(type);
        System.out.println("subtract:=" + result);
    }

    /**
     * Test of multiply method, of class SocialProblemSolver.
     */
    @Test
    public void multiply() {

        int type = 3;
        SocialProblemSolver instance = new SocialProblemSolver();
        
        int result = instance.multiply(type);
        System.out.println("multiply:=" + result);
    }

    /**
     * Test of rcombinant method, of class SocialProblemSolver.
     */
    @Test
    public void rcombinant() {

        int r = 4;
        int n = 2;
        SocialProblemSolver instance = new SocialProblemSolver();
       
        long result = instance.rcombinant(r, n);
        System.out.println("rcombinant:=" + result);
    }

    /**
     * Test of size method, of class SocialProblemSolver.
     */
    @Test
    public void size() {

        int type = 3;
        SocialProblemSolver instance = new SocialProblemSolver();

        List<Integer> result = instance.size(type);
        System.out.println("size:=" + result);
    }

    /**
     * Test of getWordTokens method, of class SocialProblemSolver.
     */
    @Test
    public void getWordTokens() {

        int type = 4;
        SocialProblemSolver instance = new SocialProblemSolver();

        List<String> result = instance.getWordTokens(type);
        System.out.println("getWordTokens:=" + result);
    }

    /**
     * Test of MPOrder method, of class SocialProblemSolver.
     */
    @Test
    public void MPOrder() {

        int type = 0;
        SocialProblemSolver instance = new SocialProblemSolver();
  
        List<Integer> result = instance.MPOrder(type);
        System.out.println("MPOrder:=" + result);
    }

    /**
     * Test of MPSetOrder method, of class SocialProblemSolver.
     */
    @Test
    public void MPSetOrder() {

        int type = 0;
        SocialProblemSolver instance = new SocialProblemSolver();
       
        List<Integer> result = instance.MPSetOrder(type);
        System.out.println("MPSetOrder:=" + result);
    }

    /**
     * Test of RMPSetOrder method, of class SocialProblemSolver.
     */
    @Test
    public void RMPSetOrder() {

        int type = 0;
        SocialProblemSolver instance = new SocialProblemSolver();
       
        List<Integer> result = instance.RMPSetOrder(type);
        System.out.println("RMPSetOrder:=" + result);
    }

    /**
     * Test of LMPSetOrder method, of class SocialProblemSolver.
     */
    @Test
    public void LMPSetOrder() {

        int type = 1;
        SocialProblemSolver instance = new SocialProblemSolver();
        
        List<Integer> result = instance.LMPSetOrder(type);
        System.out.println("LMPSetOrder:=" + result);
    }

    /**
     * Test of getPosition method, of class SocialProblemSolver.
     */
    @Test
    public void getPosition() {

        int type = 2; //Second sentence of the problem
        SocialProblemSolver instance = new SocialProblemSolver();
      
        int result = instance.getPosition(type);
        System.out.println("getPosition:=" + result);
    }

    /**
     * Test of getEqualityPrinciples method, of class SocialProblemSolver.
     */
    @Test
    public void getEqualityPrinciples() {

        int type1 = 2;
        int type2 = 4;
        SocialProblemSolver instance = new SocialProblemSolver();
        
        List<Integer> result = instance.getEqualityPrinciples(type1, type2);
        System.out.println("getEqualityPrinciples:=" + result);
    }

    /**
     * Test of getCountEqualityPrinciple method, of class SocialProblemSolver.
     */
    @Test
    public void getCountEqualityPrinciple() {

        int type1 = 1;
        int type2 = 2;
        SocialProblemSolver instance = new SocialProblemSolver();
        
        int result = instance.getCountEqualityPrinciple(type1, type2);

        System.out.println("getCountEqualityPrinciple:=" + result);
    }

    /**
     * Test of rpermute method, of class SocialProblemSolver.
     */
    @Test
    public void rpermute() {

        int n = 2;
        int r = 3;
        SocialProblemSolver instance = new SocialProblemSolver();
       
        long result = instance.rpermute(n, r);
        System.out.println("rpermute:=" + result);
    }

    /**
     * Test of order method, of class SocialProblemSolver.
     */
    @Test
    public void order() {

        int type = 0;
        int sentinelNo = 0;
        SocialProblemSolver instance = new SocialProblemSolver();
        
        long result = instance.order(type, sentinelNo);
        System.out.println("order:=" + result);
    }

    /**
     * Test of getProblemSize method, of class SocialProblemSolver.
     */
    @Test
    public void getProblemSize() {
        SocialProblemSolver instance = new SocialProblemSolver();
       
        int result = instance.getProblemSize();
        System.out.println("getProblemSize:=" + result);
    }

    /**
     * Test of getSentence method, of class SocialProblemSolver.
     */
    @Test
    public void getSentence() {

        int sentencetype = 4;
        SocialProblemSolver instance = new SocialProblemSolver();
        String result = instance.getSentence(sentencetype);
        System.out.println("getSentence:=" + result);
    }

    /**
     * Test of AppiahTest method, of class SocialProblemSolver.
     */
    @Test
    public void AppiahTest() {
        System.out.println("AppiahTest");
        SocialProblemSolver instance = new SocialProblemSolver();
        instance.AppiahTest();

    }

    /**
     * Test of printLetters method, of class SocialProblemSolver.
     */
    @Test
    public void printLetters() {

        int sentinelNo = 1;
        SocialProblemSolver instance = new SocialProblemSolver();
        List<Character> result = instance.printLetters(sentinelNo);
        System.out.println("printLetters:=" + result);
    }

    /**
     * Test of getLetters method, of class SocialProblemSolver.
     */
    @Test
    public void getLetters() {

        int sentinelNo = 3; //Sentence 3 of Social Problem
        SocialProblemSolver instance = new SocialProblemSolver();
       
        List<Character> result = instance.getLetters(instance.getSentence(sentinelNo));
        System.out.println("getLetters:=" + result);
    }
    
}
