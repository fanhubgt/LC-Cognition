/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package natural;

import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author appiah
 */
public class MoonSunGoProblemSolverTest {

    public MoonSunGoProblemSolverTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getSeo method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void getSeo() {
        System.out.println("getSeo");
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        SentinelEnumOne expResult = null;
        SentinelEnumOne result = instance.getSeo();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSet method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void getSet() {
        System.out.println("getSet");
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        SentinelEnumTwo expResult = null;
        SentinelEnumTwo result = instance.getSet();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSeth method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void getSeth() {
        System.out.println("getSeth");
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        SentinelEnumThree expResult = null;
        SentinelEnumThree result = instance.getSeth();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSef method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void getSef() {
        System.out.println("getSef");
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        SentinelEnumFour expResult = null;
        SentinelEnumFour result = instance.getSef();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSefi method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void getSefi() {
        System.out.println("getSefi");
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        SentinelEnumFive expResult = null;
        SentinelEnumFive result = instance.getSefi();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSes method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void getSes() {
        System.out.println("getSes");
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        SentinelEnumSix expResult = null;
        SentinelEnumSix result = instance.getSes();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of partition method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void partition() {
        System.out.println("partition");
        int type = 0;
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        List<Integer> expResult = null;
        List<Integer> result = instance.partition(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of count method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void count() {
        System.out.println("count");
        int type = 0;
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        int expResult = 0;
        int result = instance.count(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of add method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void add() {
        System.out.println("add");
        int type = 0;
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        int expResult = 0;
        int result = instance.add(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of subtract method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void subtract() {
        System.out.println("subtract");
        int type = 0;
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        int expResult = 0;
        int result = instance.subtract(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of multiply method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void multiply() {
        System.out.println("multiply");
        int type = 0;
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        int expResult = 0;
        int result = instance.multiply(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of rcombinant method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void rcombinant() {
        System.out.println("rcombinant");
        int r = 0;
        int n = 0;
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        long expResult = 0L;
        long result = instance.rcombinant(r, n);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of size method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void size() {
        System.out.println("size");
        int type = 0;
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        List<Integer> expResult = null;
        List<Integer> result = instance.size(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getWordTokens method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void getWordTokens() {
        System.out.println("getWordTokens");
        int type = 0;
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        List<String> expResult = null;
        List<String> result = instance.getWordTokens(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of MPOrder method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void MPOrder() {
        System.out.println("MPOrder");
        int type = 0;
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        List<Integer> expResult = null;
        List<Integer> result = instance.MPOrder(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of MPSetOrder method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void MPSetOrder() {
        System.out.println("MPSetOrder");
        int type = 0;
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        List<Integer> expResult = null;
        List<Integer> result = instance.MPSetOrder(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of RMPSetOrder method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void RMPSetOrder() {
        System.out.println("RMPSetOrder");
        int type = 0;
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        List<Integer> expResult = null;
        List<Integer> result = instance.RMPSetOrder(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of LMPSetOrder method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void LMPSetOrder() {
        System.out.println("LMPSetOrder");
        int type = 0;
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        List<Integer> expResult = null;
        List<Integer> result = instance.LMPSetOrder(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPosition method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void getPosition() {
        System.out.println("getPosition");
        int type = 0;
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        int expResult = 0;
        int result = instance.getPosition(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getEqualityPrinciples method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void getEqualityPrinciples() {
        System.out.println("getEqualityPrinciples");
        int type1 = 0;
        int type2 = 0;
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        List<Integer> expResult = null;
        List<Integer> result = instance.getEqualityPrinciples(type1, type2);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCountEqualityPrinciple method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void getCountEqualityPrinciple() {
        System.out.println("getCountEqualityPrinciple");
        int type1 = 0;
        int type2 = 0;
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        int expResult = 0;
        int result = instance.getCountEqualityPrinciple(type1, type2);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of rpermute method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void rpermute() {
        System.out.println("rpermute");
        int n = 0;
        int r = 0;
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        long expResult = 0L;
        long result = instance.rpermute(n, r);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of order method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void order() {
        System.out.println("order");
        int type = 0;
        int sentinelNo = 0;
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        long expResult = 0L;
        long result = instance.order(type, sentinelNo);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getProblemSize method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void getProblemSize() {
        System.out.println("getProblemSize");
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        int expResult = 0;
        int result = instance.getProblemSize();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSentence method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void getSentence() {
        System.out.println("getSentence");
        int type = 0;
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        String expResult = "";
        String result = instance.getSentence(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of AppiahTest method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void AppiahTest() {
        System.out.println("AppiahTest");
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        instance.AppiahTest();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of printLetters method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void printLetters() {
        System.out.println("printLetters");
        int sentinelNo = 0;
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        List<Character> expResult = null;
        List<Character> result = instance.printLetters(sentinelNo);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getLetters method, of class MoonSunGoProblemSolver.
     */
    @Test
    public void getLetters() {
        System.out.println("getLetters");
        String sentence = "";
        MoonSunGoProblemSolver instance = new MoonSunGoProblemSolver();
        List<Character> expResult = null;
        List<Character> result = instance.getLetters(sentence);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

}