/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package natural;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author appiah
 */
public class NatrualIPSystemTest {

    public NatrualIPSystemTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of prover method, of class NatrualIPSystem.
     */
    @Test
    public void prover() {
        System.out.println("prover");
        String sentence = "Go Away";
        int type = 1;
        NatrualIPSystem instance = new NatrualIPSystem();
        instance.prover(sentence, type);

    }

    /**
     * Test of verifier method, of class NatrualIPSystem.
     */
    @Test
    public void verifier() {
        System.out.println("verifier");
        String vr = "Go Away";
        int type = 1;
        NatrualIPSystem instance = new NatrualIPSystem();
        instance.verifier(vr, type);

    }

    /**
     * Test of checkTokens method, of class NatrualIPSystem.
     */
    @Test
    public void checkTokens() {

        int type = 1;
        String sentence = "Go Away";
        boolean expResult = false;
        boolean result = NatrualIPSystem.checkTokens(type, sentence);
        System.out.println("checkTokens:=" + result);
    }
}
