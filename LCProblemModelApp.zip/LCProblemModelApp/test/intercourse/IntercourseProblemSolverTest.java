/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package intercourse;

import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author appiah
 */
public class IntercourseProblemSolverTest {

    public IntercourseProblemSolverTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getSeo method, of class IntercourseProblemSolver.
     */
    @Test
    public void getSeo() {
        System.out.println("getSeo");
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        SentinelEnumOne expResult = null;
        SentinelEnumOne result = instance.getSeo();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSet method, of class IntercourseProblemSolver.
     */
    @Test
    public void getSet() {
        System.out.println("getSet");
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        SentinelEnumTwo expResult = null;
        SentinelEnumTwo result = instance.getSet();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSeth method, of class IntercourseProblemSolver.
     */
    @Test
    public void getSeth() {
        System.out.println("getSeth");
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        SentinelEnumThree expResult = null;
        SentinelEnumThree result = instance.getSeth();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSef method, of class IntercourseProblemSolver.
     */
    @Test
    public void getSef() {
        System.out.println("getSef");
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        SentinelEnumFour expResult = null;
        SentinelEnumFour result = instance.getSef();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSefi method, of class IntercourseProblemSolver.
     */
    @Test
    public void getSefi() {
        System.out.println("getSefi");
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        SentinelEnumFive expResult = null;
        SentinelEnumFive result = instance.getSefi();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSes method, of class IntercourseProblemSolver.
     */
    @Test
    public void getSes() {
        System.out.println("getSes");
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        SentinelEnumSix expResult = null;
        SentinelEnumSix result = instance.getSes();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of partition method, of class IntercourseProblemSolver.
     */
    @Test
    public void partition() {
        System.out.println("partition");
        int type = 0;
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        List<Integer> expResult = null;
        List<Integer> result = instance.partition(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of count method, of class IntercourseProblemSolver.
     */
    @Test
    public void count() {
        System.out.println("count");
        int type = 0;
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        int expResult = 0;
        int result = instance.count(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of add method, of class IntercourseProblemSolver.
     */
    @Test
    public void add() {
        System.out.println("add");
        int type = 0;
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        int expResult = 0;
        int result = instance.add(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of subtract method, of class IntercourseProblemSolver.
     */
    @Test
    public void subtract() {
        System.out.println("subtract");
        int type = 0;
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        int expResult = 0;
        int result = instance.subtract(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of multiply method, of class IntercourseProblemSolver.
     */
    @Test
    public void multiply() {
        System.out.println("multiply");
        int type = 0;
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        int expResult = 0;
        int result = instance.multiply(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of rcombinant method, of class IntercourseProblemSolver.
     */
    @Test
    public void rcombinant() {
        System.out.println("rcombinant");
        int r = 0;
        int n = 0;
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        long expResult = 0L;
        long result = instance.rcombinant(r, n);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of size method, of class IntercourseProblemSolver.
     */
    @Test
    public void size() {
        System.out.println("size");
        int type = 0;
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        List<Integer> expResult = null;
        List<Integer> result = instance.size(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getWordTokens method, of class IntercourseProblemSolver.
     */
    @Test
    public void getWordTokens() {
        System.out.println("getWordTokens");
        int type = 0;
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        List<String> expResult = null;
        List<String> result = instance.getWordTokens(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of MPOrder method, of class IntercourseProblemSolver.
     */
    @Test
    public void MPOrder() {
        System.out.println("MPOrder");
        int type = 0;
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        List<Integer> expResult = null;
        List<Integer> result = instance.MPOrder(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of MPSetOrder method, of class IntercourseProblemSolver.
     */
    @Test
    public void MPSetOrder() {
        System.out.println("MPSetOrder");
        int type = 0;
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        List<Integer> expResult = null;
        List<Integer> result = instance.MPSetOrder(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of RMPSetOrder method, of class IntercourseProblemSolver.
     */
    @Test
    public void RMPSetOrder() {
        System.out.println("RMPSetOrder");
        int type = 0;
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        List<Integer> expResult = null;
        List<Integer> result = instance.RMPSetOrder(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of LMPSetOrder method, of class IntercourseProblemSolver.
     */
    @Test
    public void LMPSetOrder() {
        System.out.println("LMPSetOrder");
        int type = 0;
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        List<Integer> expResult = null;
        List<Integer> result = instance.LMPSetOrder(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPosition method, of class IntercourseProblemSolver.
     */
    @Test
    public void getPosition() {
        System.out.println("getPosition");
        int type = 0;
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        int expResult = 0;
        int result = instance.getPosition(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getEqualityPrinciples method, of class IntercourseProblemSolver.
     */
    @Test
    public void getEqualityPrinciples() {
        System.out.println("getEqualityPrinciples");
        int type1 = 0;
        int type2 = 0;
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        List<Integer> expResult = null;
        List<Integer> result = instance.getEqualityPrinciples(type1, type2);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCountEqualityPrinciple method, of class IntercourseProblemSolver.
     */
    @Test
    public void getCountEqualityPrinciple() {
        System.out.println("getCountEqualityPrinciple");
        int type1 = 0;
        int type2 = 0;
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        int expResult = 0;
        int result = instance.getCountEqualityPrinciple(type1, type2);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of rpermute method, of class IntercourseProblemSolver.
     */
    @Test
    public void rpermute() {
        System.out.println("rpermute");
        int n = 0;
        int r = 0;
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        long expResult = 0L;
        long result = instance.rpermute(n, r);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of order method, of class IntercourseProblemSolver.
     */
    @Test
    public void order() {
        System.out.println("order");
        int type = 0;
        int sentinelNo = 0;
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        long expResult = 0L;
        long result = instance.order(type, sentinelNo);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getProblemSize method, of class IntercourseProblemSolver.
     */
    @Test
    public void getProblemSize() {
        System.out.println("getProblemSize");
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        int expResult = 0;
        int result = instance.getProblemSize();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSentence method, of class IntercourseProblemSolver.
     */
    @Test
    public void getSentence() {
        System.out.println("getSentence");
        int type = 0;
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        String expResult = "";
        String result = instance.getSentence(type);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of AppiahTest method, of class IntercourseProblemSolver.
     */
    @Test
    public void AppiahTest() {
        System.out.println("AppiahTest");
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        instance.AppiahTest();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of printLetters method, of class IntercourseProblemSolver.
     */
    @Test
    public void printLetters() {
        System.out.println("printLetters");
        int sentinelNo = 0;
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        List<Character> expResult = null;
        List<Character> result = instance.printLetters(sentinelNo);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getLetters method, of class IntercourseProblemSolver.
     */
    @Test
    public void getLetters() {
        System.out.println("getLetters");
        String sentence = "";
        IntercourseProblemSolver instance = new IntercourseProblemSolver();
        List<Character> expResult = null;
        List<Character> result = instance.getLetters(sentence);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

}