/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package intercourse;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author appiah
 */
public class IntercourseIPSystemTest {

    public IntercourseIPSystemTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of prover method, of class IntercourseIPSystem.
     */
    @Test
    public void prover() {
        System.out.println("prover");
        String sentence = "Love Me";
        int type = 1;
        IntercourseIPSystem instance = new IntercourseIPSystem();
        instance.prover(sentence, type);
    }

    /**
     * Test of verifier method, of class IntercourseIPSystem.
     */
    @Test
    public void verifier() {
        System.out.println("verifier");
        String vr = "Love Me";
        int type = 1;
        IntercourseIPSystem instance = new IntercourseIPSystem();
        instance.verifier(vr, type);
    }

    /**
     * Test of checkTokens method, of class IntercourseIPSystem.
     */
    @Test
    public void checkTokens() {
        int type = 1;
        String sentence = "Love Me";
        boolean expResult = false;
        boolean result = IntercourseIPSystem.checkTokens(type, sentence);
        System.out.println("checkTokens:="+result);
    }

}