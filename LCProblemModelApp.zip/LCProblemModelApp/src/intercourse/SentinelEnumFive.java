package intercourse;
// #[regen=yes,id=DCE.771DDE67-823A-E516-040F-5A2019FC9F04]
// </editor-fold> 
import lcenum.SentinelUtil;

public enum SentinelEnumFive {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.2AE5997D-E95A-0582-CBD1-874E633CADF5]
    // </editor-fold> 
    Will_4,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.2C572482-A1E1-0E1B-CE82-99CB835CE738]
    // </editor-fold> 
    Always_6,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.89B2F161-4894-21A5-3A85-901BAB1B2977]
    // </editor-fold> 
    Love_4,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.7C8FFF2D-05BE-3A69-D6DB-CF4C2455648A]
    // </editor-fold> 
    Me_2,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.3736E81C-EDB5-6737-2132-507CBA612E7A]
    // </editor-fold> 
    Back_4;

    public static String getWill_4() {
        return "Will_4";
    }

    public static String getAlways_6() {
        return "Always_6";
    }

    public static String getLove_4() {
        return "Love_4";
    }

    public static String getMe_2() {
        return "Me_2";
    }

    public static String getBack_4() {
        return "Back_4";
    }

    public static String getSentence() {
        return new String(
                SentinelUtil.getEnumWord(getWill_4()) + " " +
                SentinelUtil.getEnumWord(getAlways_6()) + " " +
                SentinelUtil.getEnumWord(getLove_4()) + " " +
                SentinelUtil.getEnumWord(getMe_2()) + " " +
                SentinelUtil.getEnumWord(getBack_4()));
    }

    public static int[] getSizes() {
        int sizes[] = {
            SentinelUtil.getEnumSize(getWill_4()),
            SentinelUtil.getEnumSize(getAlways_6()),
            SentinelUtil.getEnumSize(getLove_4()),
            SentinelUtil.getEnumSize(getMe_2()),
            SentinelUtil.getEnumSize(getBack_4())
        };

        return sizes;

    }
}

