package intercourse;
// #[regen=yes,id=DCE.A297BD57-67A3-9D5F-F618-346D2BFF4119]
// </editor-fold> 
import lcenum.SentinelUtil;

public enum SentinelEnumFour {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.B38ECF00-5F23-9618-3E8C-CF70D7915DA4]
    // </editor-fold> 
    Will_4,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.0A846478-284E-3A13-4C9D-49037292E23A]
    // </editor-fold> 
    Be_2,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.F7663D1C-3D62-8B5A-6B6F-CB3512029508]
    // </editor-fold> ,,
    Your_4,
    Lover_5,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.81B85EF9-0F3C-26FD-1126-9D5CE4CB78C3]
    // </editor-fold> 
    Dear_4;

    public static String getWill_4() {
        return "Will_4";
    }

    public static String getBe_2() {
        return "Be_2";
    }

    public static String getYour_4() {
        return "Your_4";
    }

    public static String getLover_5() {
        return "Lover_5";
    }

    public static String getDear_4() {
        return "Dear_4";
    }

    public static String getSentence() {
        return new String(
                SentinelUtil.getEnumWord(getWill_4()) + " " +
                SentinelUtil.getEnumWord(getBe_2()) + " " +
                SentinelUtil.getEnumWord(getYour_4()) + " " +
                SentinelUtil.getEnumWord(getLover_5()) + " " +
                SentinelUtil.getEnumWord(getDear_4()));
    }

    public static int[] getSizes() {
        int sizes[] = {
            SentinelUtil.getEnumSize(getWill_4()),
            SentinelUtil.getEnumSize(getBe_2()),
            SentinelUtil.getEnumSize(getYour_4()),
            SentinelUtil.getEnumSize(getLover_5()),
            SentinelUtil.getEnumSize(getDear_4())
        };

        return sizes;
    }
    }
        
        


