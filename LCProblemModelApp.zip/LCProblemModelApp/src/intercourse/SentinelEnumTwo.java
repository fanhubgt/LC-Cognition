package intercourse;

import lcenum.SentinelUtil;


// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.5CED6A28-AC29-D876-A6B7-DC89FBBE50A6]
// </editor-fold> 
public enum SentinelEnumTwo {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.A9D4B7A3-CC29-D254-5BAA-F12D7528B034]
    // </editor-fold> 
    I_1,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.6A4A3809-98E8-95D4-99EB-5471E1F1741B]
    // </editor-fold> 
    Do_2,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.3BE589CE-8729-2A17-FFA8-85DE24F72FCE]
    // </editor-fold> 
    Love_4,
    You_3;

    public static String getI_1() {
        return "I_1";
    }

    public static String getDo_2() {
        return "Do_2";
    }

    public static String getLove_4() {
        return "Love_4";
    }

    public static String getYou_3() {
        return "You_3";
    }

    public static String getSentence() {
        return new String(
                SentinelUtil.getEnumWord(getI_1()) + " " +
                SentinelUtil.getEnumWord(getDo_2()) + " " +
                SentinelUtil.getEnumWord(getLove_4()) + " " +
                SentinelUtil.getEnumWord(getYou_3()));
    }

    public static int[] getSizes() {
        int sizes[] = {
            SentinelUtil.getEnumSize(getI_1()),
            SentinelUtil.getEnumSize(getDo_2()),
            SentinelUtil.getEnumSize(getLove_4()),
            SentinelUtil.getEnumSize(getYou_3())
        };

        return sizes;
    }
    
}

