package intercourse;
// #[regen=yes,id=DCE.24EEB8FB-86AF-9809-BE41-A8C3FD950179]
// </editor-fold> 
import lcenum.SentinelUtil;

public enum SentinelEnumThree {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.2BCB3C4E-D62F-6BC6-5770-F80BC9223D26]
    // </editor-fold> 
    Will_4,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.80630759-2D3B-BC53-8C34-32465E4D1B25]
    // </editor-fold> 
    Love_4,
    Me_2,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.BC5118F9-6896-D2BB-7253-9766EEDB7CF0]
    // </editor-fold> 
    Back_4;

    public static String getWill_4() {
        return "Will_4";
    }

    public static String getLove_4() {
        return "Love_4";
    }

    public static String getMe_2() {
        return "Me_2";
    }

    public static String getBack_4() {
        return "Back_4";
    }

    public static String getSentence() {
        return new String(
                SentinelUtil.getEnumWord(getWill_4()) + " " +
                SentinelUtil.getEnumWord(getLove_4()) + " " +
                SentinelUtil.getEnumWord(getMe_2()) + " " +
                SentinelUtil.getEnumWord(getBack_4()));
    }

    public static int[] getSizes() {
        int sizes[] = {
            SentinelUtil.getEnumSize(getWill_4()),
            SentinelUtil.getEnumSize(getLove_4()),
            SentinelUtil.getEnumSize(getMe_2()),
            SentinelUtil.getEnumSize(getBack_4())
        };

        return sizes;
    }
}

