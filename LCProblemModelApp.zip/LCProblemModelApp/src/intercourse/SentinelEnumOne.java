package intercourse;


import lcenum.SentinelUtil;


// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.4790B2B0-895B-6553-6C98-0CE46AF6148F]
// </editor-fold> 
public  enum SentinelEnumOne {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.EE84A6AB-F9C7-C5F4-2647-4A0214B2BFC8]
    // </editor-fold> 
    Love_4,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.0F17D8A9-889A-0E5A-D9EB-3179CEAA9CED]
    // </editor-fold> 
    Me_2;

    public static String getLove_4() {
        return "Love_4";
    }

    public static String getMe_2() {
        return "Me_2";
    }
  public static String getSentence() {
        return new String(
                SentinelUtil.getEnumWord(getLove_4()) + " " +
                SentinelUtil.getEnumWord(getMe_2()) 
                );
    }

    public static int[] getSizes() {
        int sizes[] = {
        SentinelUtil.getEnumSize(getLove_4()), 
        SentinelUtil.getEnumSize(getMe_2())
        };
        
        return sizes;
        
    }
    
}

