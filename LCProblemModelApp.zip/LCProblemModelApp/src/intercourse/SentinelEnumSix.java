package intercourse;

import lcenum.SentinelUtil;


// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.81A107BF-B62F-1C6C-DCED-E8E42CAEAE2F]
// </editor-fold> 
public enum SentinelEnumSix {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.D4790134-CB59-E4C0-3FC2-60ACB58BA83D]
    // </editor-fold> 
    I_1,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.D1A2B22F-F935-A14B-C21A-317C7FDC6009]
    // </editor-fold> 
    Will_4,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.BEF9CD20-8040-A02F-6F3D-19CB3A1953C0]
    // </editor-fold> 
    Be_6,
    Your_4,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.824E0645-2D47-6AD9-A0FA-28CE09805F34]
    // </editor-fold> 
    Lover_5,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.8BA86AF3-1546-A6EC-6BFE-15D24A022020]
    // </editor-fold> 
    Believe_7,
    In_2,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.DB0CBF4C-CF1B-FFA6-11FB-2509EF688B64]
    // </editor-fold> 
    Me_2;

    public static String getI_1() {
        return "I_1";
    }

    public static String getWill_4() {
        return "Will_4";
    }

    public static String getBe_2() {
        return "Be_2";
    }

    public static String getLover_5() {
        return "Lover_5";
    }

    public static String getBelieve_7() {
        return "Believe_7";
    }

    public static String getIn_2() {
        return "In_2";
    }

    public static String getMe_2() {
        return "Me_2";
    }

    public static String getYour_4() {
        return "Your_4";
    }

    public static String getSentence() {
        return new String(
                SentinelUtil.getEnumWord(getI_1()) + " " +
                SentinelUtil.getEnumWord(getWill_4()) + " " +
                SentinelUtil.getEnumWord(getBe_2()) + " " +
                SentinelUtil.getEnumWord(getYour_4()) + " " +
                SentinelUtil.getEnumWord(getLover_5()) + " " +
                SentinelUtil.getEnumWord(getBelieve_7()) + " " +
                SentinelUtil.getEnumWord(getIn_2()) + " " +
                SentinelUtil.getEnumWord(getMe_2()));
    }

    public static int[] getSizes() {
        int sizes[] = {
            SentinelUtil.getEnumSize(getI_1()),
            SentinelUtil.getEnumSize(getWill_4()),
            SentinelUtil.getEnumSize(getBe_2()),
            SentinelUtil.getEnumSize(getYour_4()),
            SentinelUtil.getEnumSize(getLover_5()),
            SentinelUtil.getEnumSize(getBelieve_7()),
            SentinelUtil.getEnumSize(getIn_2()),
            SentinelUtil.getEnumSize(getMe_2())
        };
        return sizes;
    }
}

