package lcenum;


/**
 *
 * @author appiah
 */
public interface InteractiveProofSystem {

    public void prover(String sentence, int type) ;

    public void verifier(String vs, int type) ;
}
