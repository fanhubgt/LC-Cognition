package lcenum;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author appiah
 */
public class SentinelUtil {

    public static int getEnumSize(String sentinelNo) {
        String[] values = sentinelNo.split("_");
        return new Integer(values[1]);
    }

    public static String getEnumWord(String sentinelNo) {
        String[] values = sentinelNo.split("_");
        return values[0];
    }

    public static int getSentenceSize(String sentinelNo) {

        return sentinelNo.length();
    }

    public static char[] getEnumLetters(String sentinelNo) {
        return getEnumWord(sentinelNo).toCharArray();
    }

    public static byte[] getEnumBytes(String sentinelNo) {
        return getEnumWord(sentinelNo).getBytes();
    }

    public static String getEnumBinList(String sentinel) {

        byte[] byes = getEnumBytes(sentinel);
        return new String(byes);

    }

    public static Integer[] getCharSequenceInt(String sentence) {
        String[] splitS = sentence.split(" ");
        Integer[] seq = new Integer[splitS.length];
        for (int i = 0; i < splitS.length; i++) {
            char[] ws = splitS[i].toCharArray();
            int sum = 0;
            for (int j = 0; j < ws.length; j++) {
                sum += Character.getNumericValue(ws[j]);
            }
            seq[i] = sum;
        }
        return seq;
    }

    public static List<Object> getArrayList(Object[] aray) {
        List<Object> al = new ArrayList<Object>();
        for (int i = -0; i < aray.length; i++) {
            al.add(aray[i]);
        }
        return al;
    }

    public static String[] getCharSequenceBin(String sentence) {
        Integer[] seqInt = getCharSequenceInt(sentence);
        String[] seqBin = new String[seqInt.length];
        for (int i = 0; i < seqInt.length; i++) {
            seqBin[i] = Integer.toBinaryString(seqInt[i]);
        }

        return seqBin;
    }

    public static int getEnumMem(String sentinelNo) {
        return getEnumWord(sentinelNo).getBytes().length;
    }

    public static int getEnumMem2(String sentinelNo) {
        return getEnumMem(sentinelNo) * getEnumMem(sentinelNo);
    }

    public static double getEnumLSpace(String sentinelNo) {
        return Math.log10(getEnumWord(sentinelNo).getBytes().length);
    }

    public static double getEnumNLSpace(String sentinelNo) {
        return Math.log(getEnumWord(sentinelNo).getBytes().length);
    }

    public static double getEnumNLSpace2(String sentinelNo) {
        return getEnumNLSpace(sentinelNo) * getEnumNLSpace(sentinelNo);
    }

    public static double getEnumNLSpaceN(String sentinelNo) {
        return getEnumWord(sentinelNo).getBytes().length *
                getEnumNLSpace(sentinelNo);
    }

    public static double getEnumSQRTSpace(String sentinelNo) {
        return getEnumWord(sentinelNo).getBytes().length *
                Math.sqrt(getEnumWord(sentinelNo).getBytes().length);
    }

    public static double getEnumEXPSpace(String sentinelNo) {
        return Math.pow(2, getEnumWord(sentinelNo).getBytes().length);
    }

    public static double getEnumEXPSpaceN(String sentinelNo) {
        return getEnumWord(sentinelNo).getBytes().length *
                Math.pow(2, getEnumWord(sentinelNo).getBytes().length);
    }

    public static double getEnumPSpace(String sentinelNo) {
        return Math.log1p(getEnumWord(sentinelNo).getBytes().length);
    }

    public static boolean getEnumCONL(String sentinelNo) {
        return getEnumLSpace(sentinelNo) <= getEnumNLSpace(sentinelNo);
    }

    public static boolean getEnumCOP(String sentinelNo) {
        return getEnumMem(sentinelNo) <= getEnumPSpace(sentinelNo);
    }

    public static boolean getEnumCOLP(String sentinelNo) {
        return getEnumCONL(sentinelNo) && getEnumCOP(sentinelNo);
    }

    public static boolean savitch(String sentinelNo) {
        return getEnumNLSpace(sentinelNo) <= getEnumNLSpace2(sentinelNo);
    }

    public static String getEnumWordUpper(String sentinelNo) {
        return getEnumWord(sentinelNo).toUpperCase();
    }

    public static String getEnumWordLower(String sentinelNo) {
        return getEnumWord(sentinelNo).toLowerCase();
    }

    public static int getEnumHashCode(String sentinelNo) {
        return getEnumWord(sentinelNo).hashCode();
    }

    public static char getEnumChar(String sentinelNo, int index) {
        return Character.toChars(getEnumWord(sentinelNo).indexOf(index))[0];

    }
}
