package lcenum;



/**
 *
 * @author appiah
 */
public class SentinelModelType {

    public static final int enumOne = 1;
    public static final int enumTwo = 2;
    public static final int enumThree = 3;
    public static final int enumFour = 4;
    public static final int enumFive = 5;
    public static final int enumSix = 6;
}
