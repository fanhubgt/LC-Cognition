package socialclass;
// #[regen=yes,id=DCE.24EEB8FB-86AF-9809-BE41-A8C3FD950179]
// </editor-fold> 
import lcenum.SentinelUtil;

public enum SentinelEnumThree {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.2BCB3C4E-D62F-6BC6-5770-F80BC9223D26]
    // </editor-fold> 
    We_2,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.80630759-2D3B-BC53-8C34-32465E4D1B25]
    // </editor-fold> 
    Live_4,
    In_2,
    A_1,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.BC5118F9-6896-D2BB-7253-9766EEDB7CF0]
    // </editor-fold> 
    House_5;

    public static String getHouse_5() {
        return "House_5";
    }

    public static String getWe_2() {
        return "We_2";
    }

    public static String getLive_4() {
        return "Live_4";
    }

    public static String getIn_2() {
        return "In_2";
    }

    public static String getA_1() {
        return "A_1";
    }

    public static String getSentence() {
        return new String(
                SentinelUtil.getEnumWord(getWe_2()) + " " +
                SentinelUtil.getEnumWord(getLive_4()) + " " +
                SentinelUtil.getEnumWord(getIn_2()) + " " +
                SentinelUtil.getEnumWord(getA_1()) + " " +
                SentinelUtil.getEnumWord(getHouse_5()));
    }

    public static int[] getSizes() {
        int sizes[] = {
            SentinelUtil.getEnumSize(getWe_2()),
            SentinelUtil.getEnumSize(getLive_4()),
            SentinelUtil.getEnumSize(getIn_2()),
            SentinelUtil.getEnumSize(getA_1()),
            SentinelUtil.getEnumSize(getHouse_5())
        };

        return sizes;
    }

    @Override
    public String toString() {
        return getSentence();
    }
    
    
}

