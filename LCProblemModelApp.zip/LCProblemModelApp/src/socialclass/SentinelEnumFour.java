package socialclass;
// #[regen=yes,id=DCE.A297BD57-67A3-9D5F-F618-346D2BFF4119]
// </editor-fold> 
import lcenum.SentinelUtil;

public enum SentinelEnumFour {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.B38ECF00-5F23-9618-3E8C-CF70D7915DA4]
    // </editor-fold> 
    Business_8,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.0A846478-284E-3A13-4C9D-49037292E23A]
    // </editor-fold> 
    Family_6,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.F7663D1C-3D62-8B5A-6B6F-CB3512029508]
    // </editor-fold> 
    Are_3,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.81B85EF9-0F3C-26FD-1126-9D5CE4CB78C3]
    // </editor-fold> 
    We_2;

    public static String getFamily_6() {
        return "Family_6";
    }

    public static String getWe_2() {
        return "We_2";
    }

    public static String getAre_3() {
        return "Are_3";
    }

    public static String getBusiness_8() {
        return "Business_8";
    }

   

    public static String getSentence() {
        return new String(
                SentinelUtil.getEnumWord(getWe_2()) + " " +
                SentinelUtil.getEnumWord(getAre_3()) + " " +
                SentinelUtil.getEnumWord(getFamily_6()) + " " +
                SentinelUtil.getEnumWord(getBusiness_8()) 
                );
    }

    public static int[] getSizes() {
        int sizes[] = {
            SentinelUtil.getEnumSize(getWe_2()),
            SentinelUtil.getEnumSize(getAre_3()),
            SentinelUtil.getEnumSize(getFamily_6()),
            SentinelUtil.getEnumSize(getBusiness_8())
        };

        return sizes;

    }

    @Override
    public String toString() {
        return getSentence();
    }
    
    
    }
        
        


