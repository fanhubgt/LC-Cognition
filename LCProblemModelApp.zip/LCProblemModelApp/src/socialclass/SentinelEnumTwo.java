package socialclass;


import lcenum.SentinelUtil;


// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.5CED6A28-AC29-D876-A6B7-DC89FBBE50A6]
// </editor-fold> 
public enum SentinelEnumTwo {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.A9D4B7A3-CC29-D254-5BAA-F12D7528B034]
    // </editor-fold> 
    We_2,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.6A4A3809-98E8-95D4-99EB-5471E1F1741B]
    // </editor-fold> 
    Are_3,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.3BE589CE-8729-2A17-FFA8-85DE24F72FCE]
    // </editor-fold> 
    Close_4;

    public static String getWe_2() {
        return "We_2";
    }

    public static String getAre_3() {
        return "Are_3";
    }

    public static String getClose_5() {
        return "Close_5";
    }
    
  public static String getSentence() {
        return new String(
                SentinelUtil.getEnumWord(getWe_2()) + " " +
                SentinelUtil.getEnumWord(getAre_3()) + " " +
                SentinelUtil.getEnumWord(getClose_5())
                );
    }

    public static int[] getSizes() {
        int sizes[] = {
        SentinelUtil.getEnumSize(getWe_2()), 
        SentinelUtil.getEnumSize(getAre_3()), 
        SentinelUtil.getEnumSize(getClose_5())
        };
        
        return sizes;
        
    }

    @Override
    public String toString() {
        return getSentence();
    }
    
    
}

