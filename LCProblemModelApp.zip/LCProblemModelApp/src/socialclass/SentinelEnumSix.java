package socialclass;

import lcenum.SentinelUtil;


// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.81A107BF-B62F-1C6C-DCED-E8E42CAEAE2F]
// </editor-fold> 
public enum SentinelEnumSix {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.D4790134-CB59-E4C0-3FC2-60ACB58BA83D]
    // </editor-fold> 
    We_2,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.D1A2B22F-F935-A14B-C21A-317C7FDC6009]
    // </editor-fold> 
    Have_4,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.BEF9CD20-8040-A02F-6F3D-19CB3A1953C0]
    // </editor-fold> 
    Family_6,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.824E0645-2D47-6AD9-A0FA-28CE09805F34]
    // </editor-fold> 
    Computer_8,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.8BA86AF3-1546-A6EC-6BFE-15D24A022020]
    // </editor-fold> 
    In_2,
    A_1,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.DB0CBF4C-CF1B-FFA6-11FB-2509EF688B64]
    // </editor-fold> 
    Home_4;

    public static String getWe_2() {
        return "We_2";
    }

    public static String getHave_4() {
        return "Have_4";
    }

    public static String getFamily_6() {
        return "Family_6";
    }

    public static String getComputer_8() {
        return "Computer_8";
    }

    public static String getIn_2() {
        return "In_2";
    }

    public static String getA_1() {
        return "A_1";
    }

    public static String getHome_4() {
        return "Home_4";
    }

    public static String getGoes_4() {
        return "Goes_4";
    }

    public static String getSentence() {
        return new String(
                SentinelUtil.getEnumWord(getWe_2()) + " " +
                SentinelUtil.getEnumWord(getHave_4()) + " " +
                SentinelUtil.getEnumWord(getFamily_6()) + " " +
                SentinelUtil.getEnumWord(getComputer_8()) + " " +
                SentinelUtil.getEnumWord(getIn_2()) + " " +
                SentinelUtil.getEnumWord(getA_1()) + " " +
                SentinelUtil.getEnumWord(getHome_4()));
    }

    public static int[] getSizes() {
        int sizes[] = {
            SentinelUtil.getEnumSize(getWe_2()),
            SentinelUtil.getEnumSize(getHave_4()),
            SentinelUtil.getEnumSize(getFamily_6()),
            SentinelUtil.getEnumSize(getComputer_8()),
            SentinelUtil.getEnumSize(getIn_2()),
            SentinelUtil.getEnumSize(getA_1()),
            SentinelUtil.getEnumSize(getHome_4())
        };

        return sizes;

    }

    @Override
    public String toString() {
        return getSentence();
    }
    
    
}

