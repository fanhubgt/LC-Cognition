/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package socialclass;

import java.util.List;

/**
 *
 * @author appiah
 */
public abstract class ProblemSolver {

    public abstract List<Character> printLetters(int sentinelNo);
}
