package socialclass;
// #[regen=yes,id=DCE.771DDE67-823A-E516-040F-5A2019FC9F04]
// </editor-fold> 
import lcenum.SentinelUtil;

public enum SentinelEnumFive {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.2AE5997D-E95A-0582-CBD1-874E633CADF5]
    // </editor-fold> 
    Has_3,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.2C572482-A1E1-0E1B-CE82-99CB835CE738]
    // </editor-fold> 
    Family_6,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.89B2F161-4894-21A5-3A85-901BAB1B2977]
    // </editor-fold> 
    Set_3,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.7C8FFF2D-05BE-3A69-D6DB-CF4C2455648A]
    // </editor-fold> 
    In_2,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.3736E81C-EDB5-6737-2132-507CBA612E7A]
    // </editor-fold> 
    Home_4;

    public static String getIt_2() {
        return "It_2";
    }

    public static String getHas_2() {
        return "Has_3";
    }

    public static String getFamily_6() {
        return "Family_6";
    }

    public static String getSet_3() {
        return "Set_3";
    }

    public static String getIn_2() {
        return "In_2";
    }

    public static String getHome_4() {
        return "Home_4";
    }

    public static String getSentence() {
        return new String(
                SentinelUtil.getEnumWord(getIt_2()) + " " +
                SentinelUtil.getEnumWord(getHas_2()) + " " +
                SentinelUtil.getEnumWord(getFamily_6()) + " " +
                SentinelUtil.getEnumWord(getSet_3()) + " " +
                SentinelUtil.getEnumWord(getIn_2()) + " " +
                SentinelUtil.getEnumWord(getHome_4()));
    }

    public static int[] getSizes() {
        int sizes[] = {
            SentinelUtil.getEnumSize(getIt_2()),
            SentinelUtil.getEnumSize(getHas_2()),
            SentinelUtil.getEnumSize(getFamily_6()),
            SentinelUtil.getEnumSize(getSet_3()),
            SentinelUtil.getEnumSize(getIn_2()),
            SentinelUtil.getEnumSize(getHome_4())
        };

        return sizes;

    }

    @Override
    public String toString() {
        return getSentence();
    }
    
    
}

