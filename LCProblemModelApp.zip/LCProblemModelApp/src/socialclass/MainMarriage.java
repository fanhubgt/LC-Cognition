package socialclass;

import lcenum.SentinelModelType;
import natural.*;
import java.io.IOException;
import java.util.Scanner;
import static java.lang.System.out;
import static java.lang.System.in;
import java.util.logging.Level;
import java.util.logging.Logger;
import lcenum.SentinelUtil;

/**
 *
 * @author appiah
 */
public class MainMarriage {

    private static SocialProblemSolver marrProblem = new SocialProblemSolver();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        byte[] menu = new byte[1];//size=99 (2 digits, 10^2-1values) for integers.

        while (true) {
            out.println("\nSelect an item from menu(0: Menu Items)>>>");
            int value = 0;
            try {
                int v = in.read(menu);
                String s = new String(menu);
                value = Integer.valueOf(s);
            } catch (IOException ex) {
                Logger.getLogger(MainMarriage.class.getName()).log(Level.SEVERE, null, ex);
            } catch (NumberFormatException e) {
                int v = in.read(menu);
                String s = new String(menu);
                value = Integer.valueOf(s);
            }
            out.println("\n");

            switch (value) {
                case 0:
                    out.println("\nLCProgram Study Menu\nExplicit Count Methods\n==========================\n");
                    out.println("     Problem Size");
                    out.println("     Sentences");
                    out.println("     Word Tokens");
                    out.println("     Alpha Sizes");
                    out.println("     Partition Sets");
                    out.println("     Addition Principle");
                    out.println("     Substract Principle");
                    out.println("     Multiplication Principle");
                    out.println("     Count Principle");
                    out.println("     Characteristics Sequence");
                    out.println("     Permutation and Combination\n==========================\n");
                    out.println("\nSelect any one of the numbers to show computation\n#####################\n");
                    out.println("1     Sentinel Enum One");
                    out.println("2     Sentinel Enum One");
                    out.println("3     Sentinel Enum One");
                    out.println("4     Sentinel Enum One");
                    out.println("5     Sentinel Enum One");
                    out.println("6     Sentinel Enum One");
                    out.println("7     Permutation and Combination");
                case SentinelModelType.enumOne:
                    out.println("Sentinel Enum One\n##################\n");
                    showComputations(value);
                    continue;
                case SentinelModelType.enumTwo:
                    out.println("Sentinel Enum Two\n##################\n");
                    showComputations(value);
                    continue;
                case SentinelModelType.enumThree:
                    out.println("Sentinel Enum Three\n####################\n");
                    showComputations(value);
                    continue;
                case SentinelModelType.enumFour:
                    out.println("Sentinel Enum Four\n##################\n");
                    showComputations(value);
                    continue;
                case SentinelModelType.enumFive:
                    out.println("Sentinel Enum Five\n##################\n");
                    showComputations(value);
                    continue;
                case SentinelModelType.enumSix:
                    out.println("Sentinel Enum Six\n##################\n");
                    showComputations(value);
                    continue;
                case 7:
                    int n = 0,
                     r = 0;
                    byte[] pc = new byte[3];
                    try {
                        out.println("Permutation and Combination\n###################\n");
                        out.println("Enter value for n and r:Format[n,r]>>>>");
                        int v = in.read(pc);
                        String s = new String(pc);
                        String[] nr = s.split(",");
                        n = Integer.valueOf(nr[0]);
                        r = Integer.valueOf(nr[1]);
                    } catch (IOException ex) {
                        Logger.getLogger(MainMarriage.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (NumberFormatException e) {
                        int v = in.read(pc);
                        String s = new String(pc);
                        String[] nr = s.split(",");
                        n = Integer.valueOf(nr[0]);
                        r = Integer.valueOf(nr[1]);
                    }
                    out.println("PERMUTATION:=" + marrProblem.rpermute(n, r));
                    out.println("rCOMBINANT:=" + marrProblem.rcombinant(n, r));

                    out.println("\n");
                    continue;
                case 8:

                    out.println("SENTENCE LETTERS\n####################\n");
                    out.println("Enter the sentence number for family problem(Format: 1-6)>>>");
                    Scanner scanner = new Scanner(System.in);
                    int sentinelN0 = scanner.nextInt();
                    out.println("LETTERS:=" + marrProblem.getLetters(marrProblem.getSentence(sentinelN0)));
                    continue;
            }
        }
    }

    private static void showComputations(int type) throws IOException {
        out.println("PROBLEM POSITION:=" + marrProblem.getPosition(type));

        out.println("SENTENCE:=" + marrProblem.getSentence(type));
        out.println("WORD TOKENS:= " + marrProblem.getWordTokens(type));
        out.println("ALPHA SIZES:=" + marrProblem.size(type));
        out.println("PARTITION:=" + marrProblem.partition(type));
        out.println("ADDITION:=" + marrProblem.add(type));
        out.println("SUBTRACT:=" + marrProblem.subtract(type));
        out.println("MULTIPLICATION:=" + marrProblem.multiply(type));
        out.println("COUNT:=" + marrProblem.count(type));
        out.println("INTEGER CHARACTERISTICS SEQUENCE:=" + SentinelUtil.getArrayList(SentinelUtil.getCharSequenceInt(marrProblem.getSentence(type))));
        out.println("CHARACTERISTICS SEQUENCE:=" + SentinelUtil.getArrayList(SentinelUtil.getCharSequenceBin(marrProblem.getSentence(type))));
        out.println("\nEQUALITY PRINCIPLE COMPUTATION\n###############################\nEnter a sentinel enum-model type:(values:1-6)>>");
        byte[] pc = new byte[1];
        int model = 1;
        try {
            int v = in.read(pc);
            String s = new String(pc);
            model = Integer.valueOf(s);
        } catch (IOException ex) {
            Logger.getLogger(MainMarriage.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception e) {
            int v = in.read(pc);
            String s = new String(pc);
            model = Integer.valueOf(s);
        }
        out.println("EQUALITY PRINCIPLE:=" + marrProblem.getEqualityPrinciples(type, model));
        out.println("COUNT EQUALITY PRINCIPLE:=" + marrProblem.getCountEqualityPrinciple(type, model));
        out.println("\nORDER COMPUTATION\n###################\nEnter the sentinel value in a sentence(Format: 1-8)>>> ");
        int sentinelN0 = 1;
        try {
            int v = in.read(pc);
            String s = new String(pc);
            sentinelN0 = Integer.valueOf(s);
        } catch (IOException ex) {
            Logger.getLogger(MainMarriage.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception e) {
            int v = in.read(pc);
            String s = new String(pc);
            sentinelN0 = Integer.valueOf(s);
        }
        out.println("ORDER:=" + marrProblem.order(type, sentinelN0));
    }
    
}
