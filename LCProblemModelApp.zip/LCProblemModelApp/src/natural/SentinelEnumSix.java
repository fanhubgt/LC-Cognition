package natural;
// #[regen=yes,id=DCE.81A107BF-B62F-1C6C-DCED-E8E42CAEAE2F]
// </editor-fold>

import lcenum.SentinelUtil;

public enum SentinelEnumSix {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.D4790134-CB59-E4C0-3FC2-60ACB58BA83D]
    // </editor-fold> 
    The_3,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.D1A2B22F-F935-A14B-C21A-317C7FDC6009]
    // </editor-fold> 
    Moon_4,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.824E0645-2D47-6AD9-A0FA-28CE09805F34]
    // </editor-fold> 
    And_3,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.BEF9CD20-8040-A02F-6F3D-19CB3A1953C0]
    // </editor-fold> 
    Sun_3,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.8BA86AF3-1546-A6EC-6BFE-15D24A022020]
    // </editor-fold> 
    Goes_4,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.DB0CBF4C-CF1B-FFA6-11FB-2509EF688B64]
    // </editor-fold> 
    UpTo_4,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.9ECE8010-8218-2CC8-D1C6-48F308A6824D]
    // </editor-fold> 
    the_3, //already declared variable solved with lowercase.

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.A41CD639-82F2-55BD-8806-27C646D90A07]
    // </editor-fold> 
    Sky_3;

    public static String getAnd_3() {
        return "And_3";
    }

    public static String getUpTo_4() {
        return "UpTo_4";
    }

    public static String getThe_3() {
        return "The_3";
    }

    public static String getSun_3() {
        return "Sun_3";
    }

    public static String getSky_3() {
        return "Sky_3";
    }

    public static String getMoon_4() {
        return "Moon_4";
    }

    public static String getGoes_4() {
        return "Goes_4";
    }
  public static String getSentence() {
        return new String(
                SentinelUtil.getEnumWord(getThe_3()) + " " +
                SentinelUtil.getEnumWord(getSun_3()) + " " +
                SentinelUtil.getEnumWord(getAnd_3()) + " " +
                SentinelUtil.getEnumWord(getMoon_4()) + " " +
                SentinelUtil.getEnumWord(getGoes_4()) + " " +
                SentinelUtil.getEnumWord(getUpTo_4())+ " " +
                SentinelUtil.getEnumWord(getThe_3()) + " " +
                SentinelUtil.getEnumWord(getSky_3())
                );
    }

    public static int[] getSizes() {
        int sizes[] = {
        SentinelUtil.getEnumSize(getThe_3()), 
        SentinelUtil.getEnumSize(getSun_3()), 
        SentinelUtil.getEnumSize(getAnd_3()),
        SentinelUtil.getEnumSize(getMoon_4()),
        SentinelUtil.getEnumSize(getGoes_4()),
        SentinelUtil.getEnumSize(getUpTo_4()),
        SentinelUtil.getEnumSize(getThe_3()),
        SentinelUtil.getEnumSize(getSky_3()) 
        };
        
        return sizes;
        
    }
    

}

