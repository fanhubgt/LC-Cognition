package natural;
// #[regen=yes,id=DCE.A297BD57-67A3-9D5F-F618-346D2BFF4119]
// </editor-fold>

import lcenum.SentinelUtil;

public enum SentinelEnumFour {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.B38ECF00-5F23-9618-3E8C-CF70D7915DA4]
    // </editor-fold> 
    The_3,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.0A846478-284E-3A13-4C9D-49037292E23A]
    // </editor-fold> 
    Sun_3,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.F7663D1C-3D62-8B5A-6B6F-CB3512029508]
    // </editor-fold> 
    Is_2,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.81B85EF9-0F3C-26FD-1126-9D5CE4CB78C3]
    // </editor-fold> 
    Go_2,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.825A635F-A26F-4AB0-7A28-48B11CF8B5F7]
    // </editor-fold> 
    Away_4,
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.F4F89DD2-4615-796B-8B19-8EA4067B8F9F]
    // </editor-fold> 
    Thing_5;

    public static String getAway_4() {
        return "Away_4";
    }

    public static String getGo_2() {
        return "Go_2";
    }

    public static String getIs_2() {
        return "Is_2";
    }

    public static String getSun_3() {
        return "Sun_3";
    }

    public static String getThe_3() {
        return "The_3";
    }

    public static String getThing_5() {
        return "Thing_5";
    }

    public static String getSentence() {
        return new String(
                SentinelUtil.getEnumWord(getThe_3()) + " " +
                SentinelUtil.getEnumWord(getSun_3()) + " " +
                SentinelUtil.getEnumWord(getIs_2()) + " " +
                SentinelUtil.getEnumWord(getGo_2()) + " " +
                SentinelUtil.getEnumWord(getAway_4()) + " " +
                SentinelUtil.getEnumWord(getThing_5()));
    }

    public static int[] getSizes() {
        int sizes[] = {
        SentinelUtil.getEnumSize(getThe_3()), 
        SentinelUtil.getEnumSize(getSun_3()), 
        SentinelUtil.getEnumSize(getIs_2()),
        SentinelUtil.getEnumSize(getGo_2()),
        SentinelUtil.getEnumSize(getAway_4()),
        SentinelUtil.getEnumSize(getThing_5())
        };
        
        return sizes;
        
    }
    
    
    }
        
        


