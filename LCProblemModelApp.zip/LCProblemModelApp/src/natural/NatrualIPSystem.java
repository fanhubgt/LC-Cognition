/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package natural;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import lcenum.InteractiveProofSystem;
import lcenum.SentinelModelType;
import static java.lang.System.in;

/**
 *
 * @author appiah
 */
public class NatrualIPSystem implements InteractiveProofSystem {

    Enumeration e;
   
    public NatrualIPSystem() {
    }

    public void prover(String sentence, int type) {
        verifier(sentence.trim(), type);
    }

    public void verifier(String vr, int type) {
        switch (type) {
            case SentinelModelType.enumOne:
                if (checkTokens(type, vr)) {
                    System.out.println("VERIFIER: String of sentence is proven.");
                } else {
                    System.out.println("VERIFIER: String of sentence is not provable.");
                }
                break;
            case SentinelModelType.enumTwo:
                if (checkTokens(type, vr)) {
                    System.out.println("VERIFIER: String of sentence is proven.");
                } else {
                    System.out.println("VERIFIER: String of sentence is not provable.");
                }
                break;
            case SentinelModelType.enumThree:
                if (checkTokens(type, vr)) {
                    System.out.println("VERIFIER: String of sentence is proven.");
                } else {
                    System.out.println("VERIFIER: String of sentence is not provable.");
                }
                break;
            case SentinelModelType.enumFour:
                if (checkTokens(type, vr)) {
                    System.out.println("VERIFIER: String of sentence is proven.");
                } else {
                    System.out.println("VERIFIER: String of sentence is not provable.");
                }
                break;
            case SentinelModelType.enumFive:
                if (checkTokens(type, vr)) {
                    System.out.println("VERIFIER: String of sentence is proven.");
                } else {
                    System.out.println("VERIFIER: String of sentence is not provable.");
                }
                break;
            case SentinelModelType.enumSix:
                if (checkTokens(type, vr)) {
                    System.out.println("VERIFIER: String of sentence is proven.");
                } else {
                    System.out.println("VERIFIER: String of sentence is not provable.");
                }
                break;
        }
    }

    public static boolean checkTokens(int type, String sentence) {
        String[] tokens = sentence.split(" ");
        String[] typeTokens = null;
        List<Boolean> ctbool = new ArrayList<Boolean>();
        switch (type) {
            case SentinelModelType.enumOne:
                typeTokens = SentinelEnumOne.getSentence().split(" ");break;
            case SentinelModelType.enumTwo:
                typeTokens = SentinelEnumTwo.getSentence().split(" ");break;
            case SentinelModelType.enumThree:
                typeTokens = SentinelEnumThree.getSentence().split(" ");break;
            case SentinelModelType.enumFour:
                typeTokens = SentinelEnumFour.getSentence().split(" ");break;
            case SentinelModelType.enumFive:
                typeTokens = SentinelEnumFive.getSentence().split(" ");break;
            case SentinelModelType.enumSix:
                typeTokens = SentinelEnumSix.getSentence().split(" ");break;
        }

        for (int i = 0; i < tokens.length; i++) {
            if (typeTokens[i].contentEquals(tokens[i])) {
                ctbool.add(true);
                System.out.println("Check token:" + typeTokens[i]);
            }else
                System.out.println("Check token Unequal:" + typeTokens[i]);
         
        }
        boolean all = false;
        if (ctbool.size() > 0) {
            all = ctbool.get(0);
            for (int j = 1; j < ctbool.size(); j++) {
                all &= ctbool.get(j);
            }
        }
        return all;

    }
    
}
