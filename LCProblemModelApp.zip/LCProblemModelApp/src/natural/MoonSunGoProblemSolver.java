package natural;


import lcenum.SentinelModelType;
import lcenum.SentinelUtil;
import java.util.ArrayList;
import java.util.List;


// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
import socialclass.ProblemSolver;
// </editor-fold> 
public class MoonSunGoProblemSolver extends ProblemSolver{

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.800B65C1-8D24-3B98-52C2-31810F69BFDF]
    // </editor-fold> 
    private SentinelEnumOne seo;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.3682EDE2-4417-2000-CAA5-FF6170CC671A]
    // </editor-fold> 
    private SentinelEnumTwo set;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.78843A13-79D5-E95D-24E2-F57176FE6AF1]
    // </editor-fold> 
    private SentinelEnumThree seth;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.5FA63FFB-B3AF-54F9-3163-BBF8178BE70E]
    // </editor-fold> 
    private SentinelEnumFour sef;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.1CDD0A50-0C21-3FCD-8E73-DAD76E25A31F]
    // </editor-fold> 
    private SentinelEnumFive sefi;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.5FCBDEC5-8A9C-E2D6-0BEB-48B9296F006B]
    // </editor-fold> 
    private SentinelEnumSix ses;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.D075A175-BEFB-BFAF-4DD6-326C12671B73]
    // </editor-fold> 
    public SentinelEnumOne getSeo() {
        return seo;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.0C9CDD02-F0BD-14D9-16B6-12B69EA12AB2]
    // </editor-fold> 
    public SentinelEnumTwo getSet() {
        return set;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.21B8F7F9-3A5F-C2DB-A25C-5B922506CA45]
    // </editor-fold> 
    public SentinelEnumThree getSeth() {
        return seth;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.3E30780D-675D-273F-3149-49A4F5A17B14]
    // </editor-fold> }
    public SentinelEnumFour getSef() {
        return sef;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.76216DBA-8C22-12CA-61FD-3AC8620737CA]
    // </editor-fold> 
    public SentinelEnumFive getSefi() {
        return sefi;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.7149E50E-C747-AC8C-E5AB-85A352505FEB]
    // </editor-fold> 
    public SentinelEnumSix getSes() {
        return ses;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.AE536C10-2DD6-5DCF-A9DB-9E28C18EF0C7]
    // </editor-fold> 
    public List<Integer> partition(int type) {
        return size(type);
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.1E113F57-60D2-89CC-D30B-3499FB02A561]
    // </editor-fold> 
    public int count(int type) {
        switch (type) {
            case SentinelModelType.enumOne:
                return addArray(SentinelEnumOne.getSizes());
            case SentinelModelType.enumTwo:
                return addArray(SentinelEnumTwo.getSizes());
            case SentinelModelType.enumThree:
                return addArray(SentinelEnumThree.getSizes());
            case SentinelModelType.enumFour:
                return addArray(SentinelEnumFour.getSizes());
            case SentinelModelType.enumFive:
                return addArray(SentinelEnumFive.getSizes());
            case SentinelModelType.enumSix:
                return addArray(SentinelEnumSix.getSizes());
        }
        return 0;
    }

    private int addArray(int[] arrValues) {
        int sum = 0;
        for (int i = 0; i < arrValues.length; i++) {
            sum += arrValues[i];
        }
        return sum;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.A6E67B91-9A2B-0061-727E-F4DDE2BBFE1A]
    // </editor-fold> 
    public int add(int type) {
        switch (type) {
            case SentinelModelType.enumOne:
                return addArray(SentinelEnumOne.getSizes());
            case SentinelModelType.enumTwo:
                return addArray(SentinelEnumTwo.getSizes());
            case SentinelModelType.enumThree:
                return addArray(SentinelEnumThree.getSizes());
            case SentinelModelType.enumFour:
                return addArray(SentinelEnumFour.getSizes());
            case SentinelModelType.enumFive:
                return addArray(SentinelEnumFive.getSizes());
            case SentinelModelType.enumSix:
                return addArray(SentinelEnumSix.getSizes());
        }
        return 0;
    }

    private int substractArray(int[] arrValues) {
        int substract = arrValues[0];
        for (int i = 1; i < arrValues.length; i++) {
            substract -= arrValues[i];
        }
        return substract;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.81CE115E-2056-9071-EBC3-D8CFFBB08131]
    // </editor-fold> 
    public int subtract(int type) {
        switch (type) {
            case SentinelModelType.enumOne:
                return substractArray(SentinelEnumOne.getSizes());
            case SentinelModelType.enumTwo:
                return substractArray(SentinelEnumTwo.getSizes());
            case SentinelModelType.enumThree:
                return substractArray(SentinelEnumThree.getSizes());
            case SentinelModelType.enumFour:
                return substractArray(SentinelEnumFour.getSizes());
            case SentinelModelType.enumFive:
                return substractArray(SentinelEnumFive.getSizes());
            case SentinelModelType.enumSix:
                return substractArray(SentinelEnumSix.getSizes());
        }
        return 0;
    }

    private int multiplyArray(int[] arrValues) {
        int mul = 1;
        for (int i = 0; i < arrValues.length; i++) {
            mul *= arrValues[i];
        }
        return mul;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.C2295648-5480-6CB3-2B0C-E28A9854A595]
    // </editor-fold> 
    public int multiply(int type) {
        switch (type) {
            case SentinelModelType.enumOne:
                return multiplyArray(SentinelEnumOne.getSizes());
            case SentinelModelType.enumTwo:
                return multiplyArray(SentinelEnumTwo.getSizes());
            case SentinelModelType.enumThree:
                return multiplyArray(SentinelEnumThree.getSizes());
            case SentinelModelType.enumFour:
                return multiplyArray(SentinelEnumFour.getSizes());
            case SentinelModelType.enumFive:
                return multiplyArray(SentinelEnumFive.getSizes());
            case SentinelModelType.enumSix:
                return multiplyArray(SentinelEnumSix.getSizes());
        }
        return 0;
    }

    public long rcombinant(int r, int n) {
        long rfact = 1;
        for (int i = 1; i <= r; i++) {
            rfact *= i;
        }
        return (rpermute(n, r) / rfact);
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.07E26709-D0D3-D26F-B2BA-56AB8FF4B05C]
    // </editor-fold> 
    public List<Integer> size(int type) {
        switch (type) {
            case SentinelModelType.enumOne:
                return sizeList(SentinelEnumOne.getSizes());
            case SentinelModelType.enumTwo:
                return sizeList(SentinelEnumTwo.getSizes());
            case SentinelModelType.enumThree:
                return sizeList(SentinelEnumThree.getSizes());
            case SentinelModelType.enumFour:
                return sizeList(SentinelEnumFour.getSizes());
            case SentinelModelType.enumFive:
                return sizeList(SentinelEnumFive.getSizes());
            case SentinelModelType.enumSix:
                return sizeList(SentinelEnumSix.getSizes());
        }
        return null;
    }

    private List<Integer> sizeList(int[] arrValues) {
        List<Integer> sizes = new ArrayList<Integer>();
        for (int i = 0; i < arrValues.length; i++) {
            sizes.add(arrValues[i]);
        }
        return sizes;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.A9165394-E599-F554-4B2A-46A422C903A7]
    // </editor-fold> 
    public List<String> getWordTokens(int type) {
        switch (type) {
            case SentinelModelType.enumOne:
                return getWordList(SentinelEnumOne.getSentence());
            case SentinelModelType.enumTwo:
                return getWordList(SentinelEnumTwo.getSentence());
            case SentinelModelType.enumThree:
                return getWordList(SentinelEnumThree.getSentence());
            case SentinelModelType.enumFour:
                return getWordList(SentinelEnumFour.getSentence());
            case SentinelModelType.enumFive:
                return getWordList(SentinelEnumFive.getSentence());
            case SentinelModelType.enumSix:
                return getWordList(SentinelEnumSix.getSentence());
        }
        return null;
    }

    private List<String> getWordList(String sentence) {
        String[] tokens = sentence.split(" ");
        List<String> tokenList = new ArrayList<String>();
        for (int t = 0; t < tokens.length; t++) {
            tokenList.add(tokens[t]);
        }
        return tokenList;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.742C09A8-8919-EA49-C8E5-7FB770CADF23]
    // </editor-fold> 
    public List<Integer> MPOrder(int type) {
        return null;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.F4DBA4C5-9927-D4B0-7ACA-081E28E6D9A9]
    // </editor-fold> 
    public List<Integer> MPSetOrder(int type) {
        return null;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.53156717-1DB8-3BC3-DF2E-9D2545B64EEB]
    // </editor-fold> 
    public List<Integer> RMPSetOrder(int type) {
        return null;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.4BB765F2-979A-92AA-F763-234A135CBC22]
    // </editor-fold> 
    public List<Integer> LMPSetOrder(int type) {
        return null;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.2B190F9A-0FAF-A41A-EAF0-D8F9563B283C]
    // </editor-fold> 
    public int getPosition(int type) {
        switch (type) {
            case SentinelModelType.enumOne:
                return SentinelModelType.enumOne;
            case SentinelModelType.enumTwo:
                return SentinelModelType.enumTwo;
            case SentinelModelType.enumThree:
                return SentinelModelType.enumThree;
            case SentinelModelType.enumFour:
                return SentinelModelType.enumFour;
            case SentinelModelType.enumFive:
                return SentinelModelType.enumFive;
            case SentinelModelType.enumSix:
                return SentinelModelType.enumSix;
        }
        return 0;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.C3FC676F-DCDD-CCA0-305B-9350A7A2FF39]
    // </editor-fold> 
    public List<Integer> getEqualityPrinciples(int type1, int type2) {
        List<Integer> type1vals = size(type1);
        List<Integer> type2vals = size(type2);

        Integer[] sv1 = type1vals.toArray(new Integer[0]);
        Integer[] sv2 = type2vals.toArray(new Integer[0]);
        List<Integer> sum = new ArrayList<Integer>();

        int index1 = sv1.length;
        int index2 = sv2.length;


        if (index1 < index2) {
            for (int i = 0; i <
                    index1; i++) {
                sum.add(new Integer(sv1[i] + sv2[i]));
            }
            int d = index2 - index1;
            for (int i = 0; i <
                    d; i++) {
                sum.add(sv2[index1 + i]);
            }

            return sum;
        } else if (index1 > index2) {

            for (int i = 0; i <
                    index2; i++) {
                sum.add(sv1[i] + sv2[i]);
            }

            int d = index1 - index2;
            for (int i = 0; i <
                    d; i++) {
                sum.add(sv1[index2 + i]);
            }

            return sum;
        } else if (index1 == index2) {

            for (int i = 0; i <
                    index1 - 1; i++) {
                sum.add(sv1[i] + sv2[i]);
            }
        }
        return sum;

    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.90FE3078-E55C-AE8A-1438-2E257AED9E8A]
    // </editor-fold> 
    public int getCountEqualityPrinciple(int type1, int type2) {
        return count(type1) + count(type2);
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.49DC7ECE-B8EF-E1EC-86BC-F080100F5D78]
    // </editor-fold> 
    public long rpermute(int n, int r) {
        long p = 1;
        for (int k = 1; k < r; k++) {
            p = (p * (n + 1 - k));
        }
        return p;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.1B66AB02-608F-1874-6801-24C0AC9683DA]
    // </editor-fold> 
    private long orderLimit(int n) {
        long result = 1;
        for (int k = 1; k <= n; k++) {
            result *= k;
        }
        return result;

    }

    public long order(int type, int sentinelNo) {
        switch (type) {
            case SentinelModelType.enumOne:
                return orderLimit(SentinelEnumOne.getSizes()[sentinelNo-1]);
            case SentinelModelType.enumTwo:
                return orderLimit(SentinelEnumTwo.getSizes()[sentinelNo-1]);
            case SentinelModelType.enumThree:
                return orderLimit(SentinelEnumThree.getSizes()[sentinelNo-1]);
            case SentinelModelType.enumFour:
                return orderLimit(SentinelEnumFour.getSizes()[sentinelNo-1]);
            case SentinelModelType.enumFive:
                return orderLimit(SentinelEnumFive.getSizes()[sentinelNo-1]);
            case SentinelModelType.enumSix:
                return orderLimit(SentinelEnumSix.getSizes()[sentinelNo-1]);
        }
        return 0;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.14D7C64A-20C5-AE78-707C-D0E16F3238ED]
    // </editor-fold> 
    public int getProblemSize() {
        return 6;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.FFE135F1-778C-92A3-0C1A-CFD2045CBD63]
    // </editor-fold> 
    public String getSentence(int type) {
        switch (type) {
            case SentinelModelType.enumOne:
                return SentinelEnumOne.getSentence();
            case SentinelModelType.enumTwo:
                return SentinelEnumTwo.getSentence();
            case SentinelModelType.enumThree:
                return SentinelEnumThree.getSentence();
            case SentinelModelType.enumFour:
                return SentinelEnumFour.getSentence();
            case SentinelModelType.enumFive:
                return SentinelEnumFive.getSentence();
            case SentinelModelType.enumSix:
                return SentinelEnumSix.getSentence();
        }
        return null;
    }

    public void AppiahTest() {
    
    }
    
       @Override
    public List<Character> printLetters(int sentinelNo) {
        switch (sentinelNo) {
            case SentinelModelType.enumOne:
                return getLetters(SentinelEnumOne.getSentence());
            case SentinelModelType.enumTwo:
                return getLetters(SentinelEnumTwo.getSentence());
            case SentinelModelType.enumThree:
                return getLetters(SentinelEnumThree.getSentence());
            case SentinelModelType.enumFour:
                return getLetters(SentinelEnumFour.getSentence());
            case SentinelModelType.enumFive:
                return getLetters(SentinelEnumFive.getSentence());
            case SentinelModelType.enumSix:
                return getLetters(SentinelEnumSix.getSentence());
        }
        return null;
    }

    public List<Character> getLetters(String sentence) {

        List<Character> list = new ArrayList<Character>();
        char[] letters = SentinelUtil.getEnumLetters(sentence);

        for (int i = 0; i < letters.length; i++) {
            list.add(new Character(letters[i]));
        }

        return list;
    }
}

