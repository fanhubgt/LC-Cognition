package natural;
// #[regen=yes,id=DCE.5CED6A28-AC29-D876-A6B7-DC89FBBE50A6]
// </editor-fold> 

import lcenum.SentinelUtil;

public enum SentinelEnumTwo {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.A9D4B7A3-CC29-D254-5BAA-F12D7528B034]
    // </editor-fold> 
    Go_2,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.6A4A3809-98E8-95D4-99EB-5471E1F1741B]
    // </editor-fold> 
    Away_4,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.3BE589CE-8729-2A17-FFA8-85DE24F72FCE]
    // </editor-fold> 
    Moon_4;

    public static String getGo_2() {
        return "Go_2";
    }

    public static String getAway_4() {
        return "Away_4";
    }

    public static String getMoon_4() {
        return "Moon_4";
    }
  public static String getSentence() {
        return new String(
                SentinelUtil.getEnumWord(getGo_2()) + " " +
                SentinelUtil.getEnumWord(getAway_4()) + " " +
                SentinelUtil.getEnumWord(getMoon_4())
                );
    }

    public static int[] getSizes() {
        int sizes[] = {
        SentinelUtil.getEnumSize(getGo_2()), 
        SentinelUtil.getEnumSize(getAway_4()), 
        SentinelUtil.getEnumSize(getMoon_4())
        };
        
        return sizes;
        
    }
    
     
}

