package natural;
// #[regen=yes,id=DCE.24EEB8FB-86AF-9809-BE41-A8C3FD950179]
// </editor-fold> 

import lcenum.SentinelUtil;

public enum SentinelEnumThree {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.2BCB3C4E-D62F-6BC6-5770-F80BC9223D26]
    // </editor-fold> 
    Go_2,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.80630759-2D3B-BC53-8C34-32465E4D1B25]
    // </editor-fold> 
    Away_4,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.BC5118F9-6896-D2BB-7253-9766EEDB7CF0]
    // </editor-fold> 
    Moon_sun_8;

    public static String getMoon_sun_8() {
        return "Moon-sun_8";
    }

    public static String getGo_2() {
        return "Go_2";
    }

    public static String getAway_4() {
        return "Away_4";
    }
    
      public static String getSentence() {
        return new String(
                SentinelUtil.getEnumWord(getGo_2()) + " " +
                SentinelUtil.getEnumWord(getAway_4()) + " " +
                SentinelUtil.getEnumWord(getMoon_sun_8()) 
                );
    }

    public static int[] getSizes() {
        int sizes[] = {
        SentinelUtil.getEnumSize(getGo_2()), 
        SentinelUtil.getEnumSize(getAway_4()), 
        SentinelUtil.getEnumSize(getMoon_sun_8())
        };
        
        return sizes;
    }
    

}

