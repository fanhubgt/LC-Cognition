package familyclass;

import lcenum.SentinelModelType;
import natural.*;
import java.io.IOException;
import static java.lang.System.out;
import static java.lang.System.in;
import java.util.logging.Level;
import java.util.logging.Logger;
import lcenum.SentinelUtil;

/**
 *
 * @author appiah
 */
public class MainFam {

    private static FamilyProblemSolver goProblem = new FamilyProblemSolver();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        byte[] menu = new byte[1];//size=99 (2 digits, 10^2-1values) for integers.

        while (true) {
            out.println("\nSelect an item from menu(0: Menu Items)>>>");
            int value = 0;
            try {
                int v = in.read(menu);
                String s = new String(menu);
                value = Integer.valueOf(s);
            } catch (IOException ex) {
                Logger.getLogger(MainFam.class.getName()).log(Level.SEVERE, null, ex);
            } catch (NumberFormatException e) {
                int v = in.read(menu);
                String s = new String(menu);
                value = Integer.valueOf(s);
            }
            out.println("\n");

            switch (value) {
                case 0:
                    out.println("\nLCProgram Study Menu\nExplicit Count Methods\n==========================\n");
                    out.println("     Problem Size");
                    out.println("     Sentences");
                    out.println("     Word Tokens");
                    out.println("     Alpha Sizes");
                    out.println("     Partition Sets");
                    out.println("     Addition Principle");
                    out.println("     Substract Principle");
                    out.println("     Multiplication Principle");
                    out.println("     Count Principle");
                    out.println("     Print Letters");
                    out.println("     Characteristics Sequence");
                    out.println("     Permutation and Combination\n==========================\n");
                    out.println("\nSelect any one of the numbers to show computation\n#####################\n");
                    out.println("1     Sentinel Enum One");
                    out.println("2     Sentinel Enum One");
                    out.println("3     Sentinel Enum One");
                    out.println("4     Sentinel Enum One");
                    out.println("5     Sentinel Enum One");
                    out.println("6     Sentinel Enum One");
                    out.println("7     Permutation and Combination");

                case SentinelModelType.enumOne:
                    out.println("Sentinel Enum One\n##################\n");
                    showComputations(value);
                    continue;
                case SentinelModelType.enumTwo:
                    out.println("Sentinel Enum Two\n##################\n");
                    showComputations(value);
                    continue;
                case SentinelModelType.enumThree:
                    out.println("Sentinel Enum Three\n####################\n");
                    showComputations(value);
                    continue;
                case SentinelModelType.enumFour:
                    out.println("Sentinel Enum Four\n##################\n");
                    showComputations(value);
                    continue;
                case SentinelModelType.enumFive:
                    out.println("Sentinel Enum Five\n##################\n");
                    showComputations(value);
                    continue;
                case SentinelModelType.enumSix:
                    out.println("Sentinel Enum Six\n##################\n");
                    showComputations(value);
                    continue;
                case 7:
                    int n = 0,
                     r = 0;
                    byte[] pc = new byte[3];
                    try {
                        out.println("Permutation and Combination\n###################\n");
                        out.println("Enter value for n and r:Format[n,r]>>>>");
                        int v = in.read(pc);
                        String s = new String(pc);
                        String[] nr = s.split(",");
                        n = Integer.valueOf(nr[0]);
                        r = Integer.valueOf(nr[1]);
                    } catch (IOException ex) {
                        Logger.getLogger(MainFam.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (NumberFormatException e) {
                        int v = in.read(pc);
                        String s = new String(pc);
                        String[] nr = s.split(",");
                        n = Integer.valueOf(nr[0]);
                        r = Integer.valueOf(nr[1]);
                    }
                    out.println("PERMUTATION:=" + goProblem.rpermute(n, r));
                    out.println("rCOMBINANT:=" + goProblem.rcombinant(n, r));

                    out.println("\n");
                    continue;
            }
        }
    }

    private static void showComputations(int type) throws IOException {
        out.println("PROBLEM POSITION:=" + goProblem.getPosition(type));

        out.println("SENTENCE:=" + goProblem.getSentence(type));
        out.println("WORD TOKENS:= " + goProblem.getWordTokens(type));
        out.println("ALPHA SIZES:=" + goProblem.size(type));
        out.println("PARTITION:=" + goProblem.partition(type));
        out.println("ADDITION:=" + goProblem.add(type));
        out.println("SUBTRACT:=" + goProblem.subtract(type));
        out.println("MULTIPLICATION:=" + goProblem.multiply(type));
        out.println("COUNT:=" + goProblem.count(type));
        out.println("INTEGER CHARACTERISTICS SEQUENCE:=" + SentinelUtil.getArrayList(SentinelUtil.getCharSequenceInt(goProblem.getSentence(type))));
        out.println("CHARACTERISTICS SEQUENCE:=" + SentinelUtil.getArrayList(SentinelUtil.getCharSequenceBin(goProblem.getSentence(type))));
        out.println("\nEQUALITY PRINCIPLE COMPUTATION\n###############################\nEnter a sentinel enum-model type:(values:1-6)>>");
        byte[] pc = new byte[1];
        int model = 1;
        try {
            int v = in.read(pc);
            String s = new String(pc);
            model = Integer.valueOf(s);
        } catch (IOException ex) {
            Logger.getLogger(MainFam.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception e) {
            int v = in.read(pc);
            String s = new String(pc);
            model = Integer.valueOf(s);
        }
        out.println("EQUALITY PRINCIPLE:=" + goProblem.getEqualityPrinciples(type, model));
        out.println("COUNT EQUALITY PRINCIPLE:=" + goProblem.getCountEqualityPrinciple(type, model));
        out.println("\nORDER COMPUTATION\n###################\nEnter the sentinel value in a sentence(Format: 1-8)>>> ");
        int sentinelN0 = 1;
        try {
            int v = in.read(pc);
            String s = new String(pc);
            sentinelN0 = Integer.valueOf(s);
        } catch (IOException ex) {
            Logger.getLogger(MainFam.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception e) {
            int v = in.read(pc);
            String s = new String(pc);
            sentinelN0 = Integer.valueOf(s);
        }
        out.println("ORDER:=" + goProblem.order(type, sentinelN0));
        out.println("SENTENCE LETTERS\n####################\n");

        out.println("LETTERS:=" + goProblem.getLetters(goProblem.getSentence(type)));

        String verifys = null;
        switch (type) {
            case SentinelModelType.enumOne:
                verifys = SentinelEnumOne.getSentence();
                break;
            case SentinelModelType.enumTwo:
                verifys = SentinelEnumTwo.getSentence();
                break;
            case SentinelModelType.enumThree:
                verifys = SentinelEnumThree.getSentence();
                break;
            case SentinelModelType.enumFour:
                verifys = SentinelEnumFour.getSentence();
                break;
            case SentinelModelType.enumFive:
                verifys = SentinelEnumFive.getSentence();
                break;
            case SentinelModelType.enumSix:
                verifys = SentinelEnumSix.getSentence();
                break;
        }
        out.println("\nINTERACTIVE PROOF SYSTEM\n##############################");
        out.println("\nPROVER: The string of sentence " + type + " >>>" + verifys);

        FamilyIPSystem system = new FamilyIPSystem();
        system.prover(verifys.trim(), type);
    }
    
}
