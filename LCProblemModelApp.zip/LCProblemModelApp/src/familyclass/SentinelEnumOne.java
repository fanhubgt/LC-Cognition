package familyclass;


import lcenum.SentinelUtil;


// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.4790B2B0-895B-6553-6C98-0CE46AF6148F]
// </editor-fold> 
public  enum SentinelEnumOne {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.EE84A6AB-F9C7-C5F4-2647-4A0214B2BFC8]
    // </editor-fold> 
    At_2,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.0F17D8A9-889A-0E5A-D9EB-3179CEAA9CED]
    // </editor-fold> 
    Home_4;

    public static String getAt_2() {
        return "At_2";
    }

    public static String getHome_4() {
        return "Home_4";
    }
  public static String getSentence() {
        return new String(
                SentinelUtil.getEnumWord(getAt_2()) + " " +
                SentinelUtil.getEnumWord(getHome_4()) 
                );
    }

    public static int[] getSizes() {
        int sizes[] = {
        SentinelUtil.getEnumSize(getAt_2()), 
        SentinelUtil.getEnumSize(getHome_4())
        };
        
        return sizes;
        
    }
    
}

